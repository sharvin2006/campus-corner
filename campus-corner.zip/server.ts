import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI client lazily or with fallbacks
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn('GEMINI_API_KEY environment variable is not set. Gemini features will use smart realistic estimations.');
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. AI Price Recommendation Endpoint
app.post('/api/ai/price-recommendation', async (req, res) => {
  const { title, category, condition, description, course } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Product title is required' });
  }

  try {
    const ai = getGenAI();
    if (ai) {
      const prompt = `You are Campus Corner's AI Valuation Assistant for Polytechnic & University students in Malaysia/SE Asia using RM (Malaysian Ringgit).
      Analyze this student marketplace item:
      Title: "${title}"
      Category: "${category || 'General'}"
      Condition: "${condition || 'Used'}"
      Additional Details: "${description || 'N/A'}"
      Course Context: "${course || 'Commerce'}"

      Provide a realistic, data-backed campus resale price valuation in RM (Malaysian Ringgit).
      Respond ONLY with a valid JSON object strictly adhering to this structure:
      {
        "recommendedPrice": 50,
        "marketAvg": 55,
        "priceMin": 45,
        "priceMax": 65,
        "confidence": "High (Based on 14 recent campus sales)",
        "sellingSpeed": "Very Fast (< 48 hours)",
        "reasoning": "High demand among Semester 1-3 Commerce students. Similar items sell quickly at RM 48 - RM 55."
      }`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        },
      });

      const text = response.text || '';
      const parsed = JSON.parse(text);
      return res.json(parsed);
    }
  } catch (err: any) {
    console.error('Gemini API error in price recommendation:', err?.message || err);
  }

  // Fallback realistic price engine if API key missing or error
  const basePriceMap: Record<string, number> = {
    Books: 30,
    Notes: 15,
    Calculator: 55,
    Laptop: 950,
    Phone: 450,
    Stationery: 12,
    Fashion: 35,
    'Food Voucher': 10,
    Services: 40,
    'Assignment Templates': 10,
    'Student Businesses': 25,
  };

  const base = basePriceMap[category] || 35;
  const conditionMultiplier = condition === 'New' ? 1.2 : condition === 'Like New' ? 0.95 : 0.75;
  const rec = Math.round(base * conditionMultiplier);
  const avg = Math.round(rec * 1.08);

  return res.json({
    recommendedPrice: rec,
    marketAvg: avg,
    priceMin: Math.max(5, Math.round(rec * 0.85)),
    priceMax: Math.round(rec * 1.2),
    confidence: 'High (Campus Historical Benchmark)',
    sellingSpeed: 'Fast (1 - 3 days)',
    reasoning: `Based on popular campus listing data for ${category} in ${condition} condition.`,
  });
});

// 2. Smart Product Description Generator Endpoint
app.post('/api/ai/generate-description', async (req, res) => {
  const { title, category, condition, highlights, pickupLocation, course } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Product title is required' });
  }

  try {
    const ai = getGenAI();
    if (ai) {
      const prompt = `You are Campus Corner's Smart Product Copywriter for polytechnic and university students.
      Write an engaging, clean, clear, and honest student product description for a campus marketplace listing.

      Item: "${title}"
      Category: "${category || 'General'}"
      Condition: "${condition || 'Used'}"
      Key Details/Notes: "${highlights || 'Good condition, well taken care of'}"
      Preferred Pickup Spot: "${pickupLocation || 'Campus Library / Student Centre'}"
      Course Context: "${course || 'Polytechnic Student'}"

      Format the output with standard clean paragraphs and bullet points. Make it sound friendly, student-focused, and trustworthy. Keep it concise (around 80-120 words).`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
      });

      return res.json({ description: response.text?.trim() });
    }
  } catch (err: any) {
    console.error('Gemini API error in description generator:', err?.message || err);
  }

  // Fallback description
  const fallbackDesc = `Original ${title} (${condition} condition).
  
• Carefully preserved and clean.
• Perfect for ${course || 'Polytechnic'} students looking for affordable, high-quality materials.
• Key notes: ${highlights || 'Fully working, clean, and ready for immediate campus use.'}
• Pickup: Convenient meet-up at ${pickupLocation || 'Library / Student Centre'}. Feel free to chat and inquire!`;

  return res.json({ description: fallbackDesc });
});

// 3. AI Marketing Advisor Endpoint for Commerce Students
app.post('/api/ai/marketing-advice', async (req, res) => {
  const { storeName, campaignData, question } = req.body;

  try {
    const ai = getGenAI();
    if (ai) {
      const prompt = `You are Campus Corner's Senior Digital Marketing Advisor & Commerce Lecturer AI.
      A student business store "${storeName || 'Student Enterprise'}" asks:
      "${question || 'How can I improve my conversion rate and get more sales on campus?'}"

      Current Campaign Stats:
      ${JSON.stringify(campaignData || { visitors: 120, clicks: 35, messages: 10, sales: 3, conversionRate: '2.5%' })}

      Provide 3 actionable, highly tactical marketing advice points tailored for polytechnic commerce students (applying STP, Pricing Strategy, and Social Proof). Keep it friendly and motivating.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
      });

      return res.json({ advice: response.text?.trim() });
    }
  } catch (err: any) {
    console.error('Gemini API error in marketing advice:', err?.message || err);
  }

  return res.json({
    advice: `Here are 3 quick marketing recommendations for ${storeName || 'your business'}:

1. **Optimize Your Title & Thumbnail**: Use high-contrast photos taken at campus hotspots (e.g. Student Centre) and include course keywords like 'Sem 2 Commerce'.
2. **Apply Penetration Pricing**: Offer an introductory 10% discount or a bundle deal (e.g., Book + Free Printed Notes) for your first 5 student buyers to gain initial 5-star reviews.
3. **Leverage Safe Campus Pickup Points**: Mention free instant delivery at the PSAS Library or Commerce Cafeteria to reduce friction for buyers!`,
  });
});

// ==========================================
// 4. Campus SOS Emergency Alert System APIs
// ==========================================

interface ServerSOSAlert {
  id: string;
  userId: string;
  userName: string;
  studentId?: string;
  isAnonymous: boolean;
  category: string;
  timestamp: string;
  locationName: string;
  coordinates?: {
    latitude: number;
    longitude: number;
    accuracy?: number;
  };
  description?: string;
  status: 'active' | 'cancelled' | 'resolved';
  isDemo: boolean;
  campus: string;
  notifyAuthorities: boolean;
  notifyContacts: boolean;
  notifiedUsersCount: number;
  cancelledAt?: string;
  cancelReason?: string;
  authorityDispatchStatus?: 'pending' | 'acknowledged' | 'en_route' | 'demo_logged' | 'resolved';
  nearbySafetyAdvice?: string;
}

// In-memory alert storage for demo and active campus broadcasts
let campusAlerts: ServerSOSAlert[] = [
  {
    id: 'sos_demo_1',
    userId: 'usr_sos_std_1',
    userName: 'Danial Haziq',
    studentId: '15DKM23F1090',
    isAnonymous: false,
    category: 'Accident',
    timestamp: new Date(Date.now() - 12 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    locationName: 'Junction near Commerce Block B & Student Carpark',
    coordinates: {
      latitude: 3.7548,
      longitude: 101.5302,
      accuracy: 8,
    },
    description: 'Motorcycle minor collision at carpark entrance. Student needs first aid kit support.',
    status: 'active',
    isDemo: true,
    campus: 'Politeknik Sultan Azlan Shah (PSAS)',
    notifyAuthorities: true,
    notifyContacts: true,
    notifiedUsersCount: 42,
    authorityDispatchStatus: 'demo_logged',
    nearbySafetyAdvice: 'Avoid parking congestion around Commerce Block B. Security patrol alerted.',
  },
];

// Rate limiting map: tracks last alert time by user to prevent accidental repeated spam
const lastAlertTimestampByUser: Record<string, number> = {};

// GET /api/sos/alerts
app.get('/api/sos/alerts', (req, res) => {
  res.json({ alerts: campusAlerts });
});

// POST /api/sos/alerts - Dispatch an SOS
app.post('/api/sos/alerts', (req, res) => {
  const {
    userId = 'usr_me',
    userName = 'Student',
    studentId,
    isAnonymous = false,
    category = 'Other Emergency',
    locationName = 'Campus Perimeter',
    coordinates,
    description = '',
    isDemo = true,
    campus = 'Politeknik Sultan Azlan Shah (PSAS)',
    notifyAuthorities = true,
    notifyContacts = true,
  } = req.body;

  // Anti-spam cooldown check (30 seconds per user, bypassable in demo if requested)
  const now = Date.now();
  const lastTime = lastAlertTimestampByUser[userId] || 0;
  if (!isDemo && now - lastTime < 30 * 1000) {
    return res.status(429).json({
      error: 'Cooldown active. Please wait 30 seconds before sending another emergency alert.',
    });
  }
  lastAlertTimestampByUser[userId] = now;

  // Category advice generator
  let safetyAdvice = 'Stay safe. Avoid the area if necessary and contact campus security if urgent assistance is needed.';
  if (category === 'Medical Emergency') {
    safetyAdvice = 'First responders have been notified. Clear corridors for medical assistance team.';
  } else if (category === 'Fire') {
    safetyAdvice = 'EVACUATION NOTICE: Move calmly towards nearest assembly point. Do not use elevators.';
  } else if (category === 'Accident') {
    safetyAdvice = 'Traffic slowdown alert. Please drive slowly around this campus junction.';
  } else if (category === 'Safety Emergency') {
    safetyAdvice = 'Stay in well-lit public areas with friends. Campus security patrol dispatched.';
  }

  const newAlert: ServerSOSAlert = {
    id: `sos_${Date.now()}`,
    userId,
    userName: isAnonymous ? 'Anonymous Student' : userName,
    studentId: isAnonymous ? undefined : studentId,
    isAnonymous,
    category,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    locationName,
    coordinates,
    description,
    status: 'active',
    isDemo: Boolean(isDemo),
    campus,
    notifyAuthorities,
    notifyContacts,
    notifiedUsersCount: Math.floor(Math.random() * 25) + 35, // Simulated 35-60 nearby students
    authorityDispatchStatus: isDemo ? 'demo_logged' : 'acknowledged',
    nearbySafetyAdvice: safetyAdvice,
  };

  // Add to top of alerts list
  campusAlerts = [newAlert, ...campusAlerts];

  res.status(201).json({
    success: true,
    alert: newAlert,
    message: isDemo
      ? 'DEMO SOS ALERT — NOT A REAL EMERGENCY. Broadcast simulated successfully.'
      : 'Emergency alert dispatched to nearby students and emergency contacts.',
  });
});

// POST /api/sos/alerts/:id/cancel - Cancel an active SOS (with confirmation & reason)
app.post('/api/sos/alerts/:id/cancel', (req, res) => {
  const { id } = req.params;
  const { reason = 'Accidental trigger / Situation resolved' } = req.body;

  const alertIndex = campusAlerts.findIndex((a) => a.id === id);
  if (alertIndex === -1) {
    return res.status(404).json({ error: 'Alert not found' });
  }

  campusAlerts[alertIndex] = {
    ...campusAlerts[alertIndex],
    status: 'cancelled',
    cancelledAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    cancelReason: reason,
    authorityDispatchStatus: 'resolved',
  };

  res.json({
    success: true,
    alert: campusAlerts[alertIndex],
    message: 'SOS alert has been safely cancelled and nearby users notified.',
  });
});

// POST /api/sos/alerts/:id/update-category - Update category/notes after immediate 1-tap dispatch
app.post('/api/sos/alerts/:id/update-category', (req, res) => {
  const { id } = req.params;
  const { category, description } = req.body;

  const alertIndex = campusAlerts.findIndex((a) => a.id === id);
  if (alertIndex === -1) {
    return res.status(404).json({ error: 'Alert not found' });
  }

  if (category) campusAlerts[alertIndex].category = category;
  if (description !== undefined) campusAlerts[alertIndex].description = description;

  res.json({
    success: true,
    alert: campusAlerts[alertIndex],
  });
});

// GET /api/sos/authorities - Official Campus Emergency Contacts
app.get('/api/sos/authorities', (req, res) => {
  res.json({
    campus: 'Politeknik Sultan Azlan Shah (PSAS)',
    authorities: [
      {
        id: 'auth_sec',
        name: 'PSAS Auxiliary Police & Security Control Room',
        phone: '05-456 3211',
        available: '24/7',
        status: 'Online / Direct Link Ready',
      },
      {
        id: 'auth_med',
        name: 'PSAS Student Health & Medical Clinic',
        phone: '05-456 3290',
        available: '8:00 AM - 5:00 PM',
        status: 'Standby',
      },
      {
        id: 'auth_hep',
        name: 'Hal Ehwal Pelajar (HEP Welfare Office)',
        phone: '05-456 3244',
        available: 'Office Hours',
        status: 'Active',
      },
      {
        id: 'auth_999',
        name: 'MERS 999 Emergency Hotline',
        phone: '999',
        available: '24/7 Nationwide',
        status: 'National Emergency Service',
      },
    ],
  });
});

// ==========================================
// 5. Campus Corner Premium Rentals APIs
// ==========================================

// In-memory rentals state
let rentalPackages = [
  {
    tier: 'basic',
    name: 'Basic Rental Listing',
    priceRM: 5,
    durationDays: 30,
    badgeLabel: 'STANDARD',
    description: 'Perfect for students or landlords listing a single room with standard search visibility.',
    features: [
      '30 Days Active on Campus Corner',
      'Display up to 5 property photos',
      'Availability slot management (e.g. 2/6)',
      'Direct WhatsApp & phone call button',
      'Eligible for Verified Badge inspection',
    ],
    recommended: false,
  },
  {
    tier: 'featured',
    name: 'Featured Rental Listing',
    priceRM: 10,
    durationDays: 30,
    badgeLabel: 'FEATURED',
    description: 'Elevated ranking in search results with eye-catching border and priority badge.',
    features: [
      '30 Days Active on Campus Corner',
      'Distinctive "FEATURED" badge on listing cards',
      'Priority placement above basic listings',
      'Display up to 8 high-res property photos',
      'Weekly student inquiry analytics',
      'Fast-track verification review',
    ],
    recommended: false,
  },
  {
    tier: 'premium',
    name: 'Premium / Recommended Listing',
    priceRM: 15,
    durationDays: 30,
    badgeLabel: '⭐ PREMIUM',
    description: 'Maximum visibility! Placed directly in the Recommended Rentals spotlight banner.',
    features: [
      '30 Days Active on Campus Corner',
      '⭐ PREMIUM spotlight card at top of Rentals hub',
      'Top-tier priority ranking in search & filters',
      'Highlighted gold border & verified spotlight',
      'Dedicated listing link shareable to student WhatsApp groups',
      'Priority same-day seller document verification',
    ],
    recommended: true,
  },
];

let rentalListings: any[] = [
  {
    id: 'rent_1',
    title: 'Seri Behrang Student Villa - Master Room (Ensuite Bath)',
    propertyType: 'room',
    location: 'Taman Behrang 2020, Behrang Stesen',
    distanceFromCampus: '400m • 4 mins walk to PSAS Main Gate',
    distanceMinutes: 4,
    monthlyRent: 380,
    deposit: 380,
    totalRooms: 4,
    totalSlots: 4,
    availableSlots: 1,
    availableDate: 'Available Immediately (Oct 2026)',
    facilities: [
      'High-speed Unifi 300Mbps WiFi',
      'Air Conditioner & Ceiling Fan',
      'Attached Private Bathroom',
      'Automatic Washing Machine',
      'Double Door Refrigerator',
      'Study Table & Ergonomic Chair',
      'Single Bed + 8-inch Ortho Mattress',
      'Covered Motorcycle & Car Parking',
      'Cooking Allowed (Induction Cooker)',
      'Coway Water Purifier',
    ],
    houseRules: [
      'Female student house only',
      'No smoking or vaping inside the house',
      'Quiet study hours after 11:00 PM',
      'No non-resident overnight guests',
      'Shared cleaning roster for common areas',
    ],
    genderPreference: 'Female Students Only',
    photos: [
      'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=900&auto=format&fit=crop&q=80',
    ],
    description: 'Fully furnished, high-comfort master bedroom in a safe guarded student house. Just 4 minutes walking distance to Politeknik Sultan Azlan Shah gate.',
    sellerId: 'usr_siti_aminah',
    sellerName: 'Kak Siti Aminah',
    sellerRole: 'Direct Landlord',
    sellerPhone: '019-3829104',
    sellerWhatsapp: '60193829104',
    allowInAppChat: true,
    packageTier: 'premium',
    packagePricePaid: 15,
    isVerifiedRental: true,
    verificationStatus: 'verified',
    verificationDetails: {
      fullName: 'Siti Aminah Binti Haji Roslan',
      contactNumber: '019-3829104',
      icOrStudentId: '780415-08-5422',
      relationshipToProperty: 'Owner',
      proofType: 'Utility Bill Proof',
      documentName: 'TNB_Electric_Bill_Taman_Behrang_2020.pdf',
      confirmedPermission: true,
      submittedAt: '2026-08-20',
      verifiedAt: '2026-08-21',
      verifiedBy: 'Campus Corner Safety Admin',
    },
    status: 'active',
    createdAt: '2026-08-20',
    expiresAt: '2026-09-20',
    daysRemaining: 18,
    viewCount: 428,
    inquiriesCount: 19,
    reportCount: 0,
    reports: [],
  },
  {
    id: 'rent_2',
    title: 'Harmoni 2-Storey Terrace Student House (Whole House / 6 Slots)',
    propertyType: 'house',
    location: 'Jalan Harmoni 3, Taman Behrang Indah',
    distanceFromCampus: '800m • 8 mins walk / 2 mins motorcycle',
    distanceMinutes: 8,
    monthlyRent: 280,
    deposit: 280,
    totalRooms: 4,
    totalSlots: 6,
    availableSlots: 2,
    availableDate: 'Ready for Next Semester Intake',
    facilities: [
      'TIME Internet 100Mbps Free',
      'Fully Furnished Living Room with Sofa & Smart TV',
      'Large Kitchen with Gas Stove & Hood',
      'Refrigerator & Rice Cooker',
      'Washing Machine & Drying Area',
      'Water Heater in All 3 Bathrooms',
      'Bed Frames with Mattresses & Wardrobes',
      'Spacious Porch fits 4-5 Motorcycles',
    ],
    houseRules: [
      'Male student house only',
      'Rent must be paid before 5th of each month',
      'Keep kitchen clean after cooking',
      'Respect neighbours in residential area',
    ],
    genderPreference: 'Male Students Only',
    photos: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900&auto=format&fit=crop&q=80',
    ],
    description: 'Very peaceful corner double-storey house popular among PSAS Commerce and Engineering students. Currently 4 senior students staying, 2 slots vacant in the middle twin-sharing room.',
    sellerId: 'usr_rep_harmoni',
    sellerName: 'Harmoni House Senior Rep',
    sellerRole: 'Student Senior',
    sellerPhone: '017-4829103',
    sellerWhatsapp: '60174829103',
    allowInAppChat: true,
    packageTier: 'featured',
    packagePricePaid: 10,
    isVerifiedRental: true,
    verificationStatus: 'verified',
    verificationDetails: {
      fullName: 'Muhammad Harith Bin Rosli',
      contactNumber: '017-4829103',
      icOrStudentId: '15DPM23F1008',
      relationshipToProperty: 'Current Master Tenant',
      proofType: 'Tenancy Agreement',
      documentName: 'Tenancy_Contract_Harmoni_2026.pdf',
      confirmedPermission: true,
      submittedAt: '2026-08-25',
      verifiedAt: '2026-08-26',
      verifiedBy: 'Campus Corner Student Officer',
    },
    status: 'active',
    createdAt: '2026-08-25',
    expiresAt: '2026-09-25',
    daysRemaining: 23,
    viewCount: 312,
    inquiriesCount: 14,
    reportCount: 0,
    reports: [],
  },
  {
    id: 'rent_3',
    title: 'Residensi Damai Student Apartment (Single Room with Balcony)',
    propertyType: 'apartment',
    location: 'Blok B, Residensi Damai, Behrang',
    distanceFromCampus: '1.2 km • 3 mins by motorcycle / campus shuttle stop downstairs',
    distanceMinutes: 3,
    monthlyRent: 320,
    deposit: 320,
    totalRooms: 3,
    totalSlots: 3,
    availableSlots: 0,
    availableDate: 'Fully Booked for Semester 1',
    facilities: [
      'Gated & Guarded with Access Card & 24h Security',
      'Swimming Pool & Gym Access',
      'High Speed WiFi',
      'Private Balcony with Mountain View',
      'Washing Machine & Dryer',
      'Full Kitchen Cabinet',
      'Aircond & Ceiling Fan',
    ],
    houseRules: [
      'Female students only',
      'Access card required at security lobby',
      'No loud music after 10 PM',
    ],
    genderPreference: 'Female Students Only',
    photos: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&auto=format&fit=crop&q=80',
    ],
    description: 'Modern condominium unit with full facilities. Quiet environment perfect for studying.',
    sellerId: 'usr_sarah',
    sellerName: 'Sarah Wong',
    sellerRole: 'Commerce Alumni',
    sellerPhone: '012-9018471',
    sellerWhatsapp: '60129018471',
    allowInAppChat: true,
    packageTier: 'basic',
    packagePricePaid: 5,
    isVerifiedRental: true,
    verificationStatus: 'verified',
    verificationDetails: {
      fullName: 'Sarah Wong Su-Lin',
      contactNumber: '012-9018471',
      icOrStudentId: '990321-08-5912',
      relationshipToProperty: 'Owner',
      proofType: 'Utility Bill Proof',
      confirmedPermission: true,
      submittedAt: '2026-08-10',
      verifiedAt: '2026-08-11',
      verifiedBy: 'Campus Corner Admin',
    },
    status: 'fully_occupied',
    createdAt: '2026-08-10',
    expiresAt: '2026-09-10',
    daysRemaining: 4,
    viewCount: 680,
    inquiriesCount: 38,
    reportCount: 0,
    reports: [],
  },
  {
    id: 'rent_4',
    title: 'Kolej Siswa Suites - Shared Twin Room (All Utilities Included)',
    propertyType: 'shared_room',
    location: 'Pekan Behrang Stesen (Near KTM Station)',
    distanceFromCampus: '950m • 9 mins walk to PSAS South Gate',
    distanceMinutes: 9,
    monthlyRent: 190,
    deposit: 200,
    totalRooms: 5,
    totalSlots: 10,
    availableSlots: 3,
    availableDate: 'Immediate move-in',
    facilities: [
      'All Electricity & Water Utilities Included in Rent',
      'Free 100Mbps WiFi',
      'Two Single Beds with Pillows & Bed Linen',
      'Two Personal Study Desks & Bookracks',
      'Common Pantry with Microwave & Hot Water Dispenser',
      'Commercial Coin Washing Machine on Ground Floor',
      'CCTV in Hallways & Fingerprint Main Door Access',
    ],
    houseRules: [
      'Male students only',
      'Clean room weekly',
      'No heavy cooking in rooms (use shared ground pantry)',
    ],
    genderPreference: 'Male Students Only',
    photos: [
      'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=900&auto=format&fit=crop&q=80',
    ],
    description: 'Affordable student twin-sharing room designed for budget-conscious students.',
    sellerId: 'usr_encik_kamal',
    sellerName: 'Encik Kamal (Hostel Manager)',
    sellerRole: 'Verified Host',
    sellerPhone: '013-8910482',
    sellerWhatsapp: '60138910482',
    allowInAppChat: true,
    packageTier: 'premium',
    packagePricePaid: 15,
    isVerifiedRental: true,
    verificationStatus: 'verified',
    verificationDetails: {
      fullName: 'Kamal Ariffin Bin Daud',
      contactNumber: '013-8910482',
      icOrStudentId: '751102-08-5183',
      relationshipToProperty: 'Owner',
      proofType: 'Owner Authorization Letter',
      confirmedPermission: true,
      submittedAt: '2026-08-15',
      verifiedAt: '2026-08-16',
      verifiedBy: 'Campus Corner Safety Admin',
    },
    status: 'active',
    createdAt: '2026-08-15',
    expiresAt: '2026-09-15',
    daysRemaining: 12,
    viewCount: 520,
    inquiriesCount: 22,
    reportCount: 0,
    reports: [],
  },
  {
    id: 'rent_5',
    title: 'Rumah Teres Bajet Pelajar Muslimah (Bilik Single)',
    propertyType: 'room',
    location: 'Taman Universiti, Behrang',
    distanceFromCampus: '600m • 6 mins walk',
    distanceMinutes: 6,
    monthlyRent: 260,
    deposit: 260,
    totalRooms: 4,
    totalSlots: 4,
    availableSlots: 2,
    availableDate: '1 October 2026',
    facilities: [
      'WiFi Percuma',
      'Peti Ais & Mesin Basuh',
      'Dapur Masak Lengkap Tong Gas',
      'Katil & Tilam Bujang',
      'Meja Belajar',
      'Ampaian Baju Berbumbung',
    ],
    houseRules: [
      'Pelajar perempuan Muslim sahaja',
      'Solat berjemaah dialu-alukan',
      'Jaga aurat dan kebersihan bersama',
    ],
    genderPreference: 'Muslim-friendly',
    photos: [
      'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?w=900&auto=format&fit=crop&q=80',
    ],
    description: 'Bilik sewa selesa untuk siswi politeknik. Suasana kejiranan yang selamat dan mesra keluarga.',
    sellerId: 'usr_makcik_zaleha',
    sellerName: 'Makcik Zaleha',
    sellerRole: 'Direct Landlord',
    sellerPhone: '018-2940182',
    sellerWhatsapp: '60182940182',
    allowInAppChat: false,
    packageTier: 'basic',
    packagePricePaid: 5,
    isVerifiedRental: false,
    verificationStatus: 'pending',
    status: 'active',
    createdAt: '2026-09-01',
    expiresAt: '2026-10-01',
    daysRemaining: 29,
    viewCount: 184,
    inquiriesCount: 7,
    reportCount: 0,
    reports: [],
  },
];

let rentalTransactions: any[] = [
  {
    id: 'tx_rent_101',
    rentalId: 'rent_1',
    rentalTitle: 'Seri Behrang Student Villa - Master Room',
    sellerId: 'usr_siti_aminah',
    sellerName: 'Kak Siti Aminah',
    packageTier: 'premium',
    packageName: 'Premium / Recommended Listing',
    amountRM: 15,
    paymentMethod: 'DuitNow QR',
    status: 'completed',
    timestamp: '2026-08-20 10:14 AM',
    transactionRef: 'PAY-RENT-90218-DNOW',
  },
  {
    id: 'tx_rent_102',
    rentalId: 'rent_2',
    rentalTitle: 'Harmoni 2-Storey Terrace Student House',
    sellerId: 'usr_rep_harmoni',
    sellerName: 'Harmoni House Senior Rep',
    packageTier: 'featured',
    packageName: 'Featured Rental Listing',
    amountRM: 10,
    paymentMethod: 'Campus Student E-Wallet',
    status: 'completed',
    timestamp: '2026-08-25 03:45 PM',
    transactionRef: 'PAY-RENT-84910-EWAL',
  },
  {
    id: 'tx_rent_103',
    rentalId: 'rent_3',
    rentalTitle: 'Residensi Damai Student Apartment',
    sellerId: 'usr_sarah',
    sellerName: 'Sarah Wong',
    packageTier: 'basic',
    packageName: 'Basic Rental Listing',
    amountRM: 5,
    paymentMethod: 'FPX Online Banking',
    status: 'completed',
    timestamp: '2026-08-10 11:20 AM',
    transactionRef: 'PAY-RENT-11924-FPX',
  },
  {
    id: 'tx_rent_104',
    rentalId: 'rent_4',
    rentalTitle: 'Kolej Siswa Suites - Shared Twin Room',
    sellerId: 'usr_encik_kamal',
    sellerName: 'Encik Kamal',
    packageTier: 'premium',
    packageName: 'Premium / Recommended Listing',
    amountRM: 15,
    paymentMethod: 'DuitNow QR',
    status: 'completed',
    timestamp: '2026-08-15 09:30 AM',
    transactionRef: 'PAY-RENT-73019-DNOW',
  },
  {
    id: 'tx_rent_105',
    rentalId: 'rent_5',
    rentalTitle: 'Rumah Teres Bajet Pelajar Muslimah',
    sellerId: 'usr_makcik_zaleha',
    sellerName: 'Makcik Zaleha',
    packageTier: 'basic',
    packageName: 'Basic Rental Listing',
    amountRM: 5,
    paymentMethod: 'DuitNow QR',
    status: 'completed',
    timestamp: '2026-09-01 02:10 PM',
    transactionRef: 'PAY-RENT-34019-DNOW',
  },
];

// GET /api/rentals
app.get('/api/rentals', (req, res) => {
  const totalRevenueRM = rentalTransactions
    .filter(t => t.status === 'completed')
    .reduce((sum, t) => sum + t.amountRM, 0) + 235; // base prior semester revenue

  const paidListingsCount = rentalListings.length + 19;
  const activePremiumCount = rentalListings.filter(r => r.packageTier === 'premium' && r.status === 'active').length + 5;
  const activeFeaturedCount = rentalListings.filter(r => r.packageTier === 'featured' && r.status === 'active').length + 7;
  const activeBasicCount = rentalListings.filter(r => r.packageTier === 'basic' && r.status === 'active').length + 6;
  const expiredListingsCount = rentalListings.filter(r => r.status === 'expired').length + 14;
  const verifiedSellersCount = rentalListings.filter(r => r.isVerifiedRental).length + 14;
  const pendingVerificationsCount = rentalListings.filter(r => r.verificationStatus === 'pending').length;
  const reportedListingsCount = rentalListings.reduce((sum, r) => sum + (r.reports?.length || 0), 0);

  res.json({
    listings: rentalListings,
    packages: rentalPackages,
    transactions: rentalTransactions,
    stats: {
      totalRevenueRM,
      paidListingsCount,
      activePremiumCount,
      activeFeaturedCount,
      activeBasicCount,
      expiredListingsCount,
      verifiedSellersCount,
      pendingVerificationsCount,
      reportedListingsCount,
    },
  });
});

// POST /api/rentals - Create new rental listing (after package checkout)
app.post('/api/rentals', (req, res) => {
  const {
    title,
    propertyType = 'room',
    location,
    distanceFromCampus = '500m • 5 mins walk',
    distanceMinutes = 5,
    monthlyRent,
    deposit,
    totalRooms = 3,
    totalSlots = 3,
    availableSlots = 1,
    availableDate = 'Available Immediately',
    facilities = [],
    houseRules = [],
    genderPreference = 'Mixed / Any',
    photos = [],
    description = '',
    sellerId = 'usr_me',
    sellerName = 'Student Lister',
    sellerRole = 'Student',
    sellerPhone = '',
    sellerWhatsapp = '',
    allowInAppChat = true,
    packageTier = 'basic',
    paymentMethod = 'DuitNow QR',
    verificationData,
  } = req.body;

  if (!title || !monthlyRent) {
    return res.status(400).json({ error: 'Property title and monthly rent are required' });
  }

  const selectedPkg = rentalPackages.find(p => p.tier === packageTier) || rentalPackages[0];
  const pricePaid = selectedPkg.priceRM;

  const newRentalId = `rent_${Date.now()}`;
  const isImmediatelyVerified = Boolean(verificationData && verificationData.confirmedPermission);

  const newListing: any = {
    id: newRentalId,
    title,
    propertyType,
    location: location || 'Near Politeknik Sultan Azlan Shah (PSAS)',
    distanceFromCampus,
    distanceMinutes: Number(distanceMinutes) || 5,
    monthlyRent: Number(monthlyRent),
    deposit: Number(deposit) || Number(monthlyRent),
    totalRooms: Number(totalRooms) || 3,
    totalSlots: Number(totalSlots) || 3,
    availableSlots: Number(availableSlots),
    availableDate,
    facilities: Array.isArray(facilities) && facilities.length > 0 ? facilities : ['High Speed WiFi', 'Study Table', 'Washing Machine'],
    houseRules: Array.isArray(houseRules) && houseRules.length > 0 ? houseRules : ['No smoking inside premises', 'Respect quiet hours'],
    genderPreference,
    photos: Array.isArray(photos) && photos.length > 0 ? photos : ['https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=900&auto=format&fit=crop&q=80'],
    description,
    sellerId,
    sellerName,
    sellerRole,
    sellerPhone,
    sellerWhatsapp,
    allowInAppChat,
    packageTier,
    packagePricePaid: pricePaid,
    isVerifiedRental: isImmediatelyVerified,
    verificationStatus: isImmediatelyVerified ? 'verified' : (verificationData ? 'pending' : 'unverified'),
    verificationDetails: verificationData ? {
      fullName: verificationData.fullName || sellerName,
      contactNumber: verificationData.contactNumber || sellerPhone,
      icOrStudentId: verificationData.icOrStudentId || 'N/A',
      relationshipToProperty: verificationData.relationshipToProperty || 'Current Master Tenant',
      proofType: verificationData.proofType || 'Tenancy Agreement',
      documentName: verificationData.documentName || 'Tenancy_Authorization_Doc.pdf',
      confirmedPermission: Boolean(verificationData.confirmedPermission),
      submittedAt: new Date().toISOString().split('T')[0],
      verifiedAt: isImmediatelyVerified ? new Date().toISOString().split('T')[0] : undefined,
      verifiedBy: isImmediatelyVerified ? 'Campus Corner Verification System' : undefined,
    } : undefined,
    status: Number(availableSlots) === 0 ? 'fully_occupied' : 'active',
    createdAt: new Date().toISOString().split('T')[0],
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    daysRemaining: 30,
    viewCount: 1,
    inquiriesCount: 0,
    reportCount: 0,
    reports: [],
  };

  rentalListings = [newListing, ...rentalListings];

  // Record payment transaction
  const newTx = {
    id: `tx_rent_${Date.now()}`,
    rentalId: newRentalId,
    rentalTitle: title,
    sellerId,
    sellerName,
    packageTier,
    packageName: selectedPkg.name,
    amountRM: pricePaid,
    paymentMethod,
    status: 'completed',
    timestamp: new Date().toLocaleString(),
    transactionRef: `PAY-RENT-${Math.floor(10000 + Math.random() * 90000)}`,
  };
  rentalTransactions = [newTx, ...rentalTransactions];

  res.status(201).json({
    success: true,
    listing: newListing,
    transaction: newTx,
  });
});

// POST /api/rentals/:id/update-slots - Seller updates slot availability
app.post('/api/rentals/:id/update-slots', (req, res) => {
  const { id } = req.params;
  const { availableSlots } = req.body;

  const idx = rentalListings.findIndex(r => r.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Rental listing not found' });
  }

  const slots = Math.max(0, Math.min(rentalListings[idx].totalSlots, Number(availableSlots)));
  rentalListings[idx].availableSlots = slots;
  rentalListings[idx].status = slots === 0 ? 'fully_occupied' : 'active';

  res.json({
    success: true,
    listing: rentalListings[idx],
  });
});

// POST /api/rentals/:id/renew - Renew expiring listing with package payment
app.post('/api/rentals/:id/renew', (req, res) => {
  const { id } = req.params;
  const { packageTier = 'basic', paymentMethod = 'DuitNow QR' } = req.body;

  const idx = rentalListings.findIndex(r => r.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Rental listing not found' });
  }

  const selectedPkg = rentalPackages.find(p => p.tier === packageTier) || rentalPackages[0];
  rentalListings[idx].packageTier = packageTier;
  rentalListings[idx].packagePricePaid = selectedPkg.priceRM;
  rentalListings[idx].daysRemaining = 30;
  rentalListings[idx].expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  if (rentalListings[idx].status === 'expired') {
    rentalListings[idx].status = rentalListings[idx].availableSlots === 0 ? 'fully_occupied' : 'active';
  }

  const newTx = {
    id: `tx_rent_${Date.now()}`,
    rentalId: id,
    rentalTitle: rentalListings[idx].title,
    sellerId: rentalListings[idx].sellerId,
    sellerName: rentalListings[idx].sellerName,
    packageTier,
    packageName: selectedPkg.name,
    amountRM: selectedPkg.priceRM,
    paymentMethod,
    status: 'completed',
    timestamp: new Date().toLocaleString(),
    transactionRef: `RENEW-${Math.floor(10000 + Math.random() * 90000)}`,
  };
  rentalTransactions = [newTx, ...rentalTransactions];

  res.json({
    success: true,
    listing: rentalListings[idx],
    transaction: newTx,
  });
});

// POST /api/rentals/:id/verify - Submit or update verification
app.post('/api/rentals/:id/verify', (req, res) => {
  const { id } = req.params;
  const { verificationData, autoApprove = true } = req.body;

  const idx = rentalListings.findIndex(r => r.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Rental listing not found' });
  }

  if (autoApprove) {
    rentalListings[idx].isVerifiedRental = true;
    rentalListings[idx].verificationStatus = 'verified';
    rentalListings[idx].verificationDetails = {
      ...rentalListings[idx].verificationDetails,
      ...verificationData,
      confirmedPermission: true,
      verifiedAt: new Date().toISOString().split('T')[0],
      verifiedBy: 'Campus Corner Verification Officer',
    };
  } else {
    rentalListings[idx].verificationStatus = 'pending';
    rentalListings[idx].verificationDetails = {
      ...rentalListings[idx].verificationDetails,
      ...verificationData,
      submittedAt: new Date().toISOString().split('T')[0],
    };
  }

  res.json({
    success: true,
    listing: rentalListings[idx],
  });
});

// POST /api/rentals/:id/report - Student reports a suspicious or scam listing
app.post('/api/rentals/:id/report', (req, res) => {
  const { id } = req.params;
  const {
    reporterId = 'usr_student',
    reporterName = 'Student Reporter',
    reason = 'suspected_scam',
    details = '',
  } = req.body;

  const idx = rentalListings.findIndex(r => r.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Rental listing not found' });
  }

  const report = {
    id: `rep_${Date.now()}`,
    rentalId: id,
    rentalTitle: rentalListings[idx].title,
    reporterId,
    reporterName,
    reason,
    details,
    timestamp: new Date().toLocaleString(),
    status: 'pending',
  };

  if (!rentalListings[idx].reports) {
    rentalListings[idx].reports = [];
  }
  rentalListings[idx].reports.push(report);
  rentalListings[idx].reportCount = (rentalListings[idx].reportCount || 0) + 1;

  res.json({
    success: true,
    message: 'Report submitted successfully. Campus Corner safety administrators will review it immediately.',
    report,
  });
});

// POST /api/rentals/admin/packages - Administrator edits package pricing
app.post('/api/rentals/admin/packages', (req, res) => {
  const { packages } = req.body;
  if (Array.isArray(packages)) {
    rentalPackages = packages;
    return res.json({ success: true, packages: rentalPackages });
  }
  res.status(400).json({ error: 'Invalid packages payload' });
});

// POST /api/rentals/admin/moderation - Admin suspends/removes suspicious listing or approves verification
app.post('/api/rentals/admin/moderation', (req, res) => {
  const { rentalId, action, reason } = req.body;
  const idx = rentalListings.findIndex(r => r.id === rentalId);
  if (idx === -1) {
    return res.status(404).json({ error: 'Rental listing not found' });
  }

  if (action === 'suspend') {
    rentalListings[idx].status = 'suspended';
  } else if (action === 'remove') {
    rentalListings = rentalListings.filter(r => r.id !== rentalId);
    return res.json({ success: true, message: 'Listing removed from marketplace' });
  } else if (action === 'approve_verification') {
    rentalListings[idx].isVerifiedRental = true;
    rentalListings[idx].verificationStatus = 'verified';
  } else if (action === 'revoke_verification') {
    rentalListings[idx].isVerifiedRental = false;
    rentalListings[idx].verificationStatus = 'unverified';
  } else if (action === 'dismiss_reports') {
    rentalListings[idx].reportCount = 0;
    if (rentalListings[idx].reports) {
      rentalListings[idx].reports.forEach((rep: any) => rep.status = 'dismissed');
    }
  }

  res.json({
    success: true,
    listing: rentalListings[idx],
  });
});

// ==========================================
// 6. Subscription Plans & AI Google Data Studio API
// ==========================================

const subscriptionPlansData = [
  {
    tier: 'free',
    name: 'Siswa Basic',
    badgeLabel: 'FREE TIER',
    tagline: 'Ideal for casual students clearing personal semester items',
    targetAudience: 'Students selling 1-2 items per semester (Notes, Calculators, Lab coats)',
    monthlyPriceRM: 0,
    semesterPriceRM: 0,
    annualPriceRM: 0,
    maxMarketplaceListings: 3,
    maxRentalListings: 1,
    dailyAIEvaluations: 3,
    searchBoostMultiplier: 1.0,
    analyticsLevel: 'Basic',
    verificationTurnaround: 'Standard (48h)',
    recommended: false,
    features: [
      'Up to 3 active marketplace item listings',
      '1 basic room / hostel rental listing',
      '3 AI price evaluations per day',
      'Standard search & filter ranking (1.0x)',
      'Basic listing views and interest count',
      'Standard seller review queue (48 hours)',
      'Campus SOS Emergency Alert (Always 100% Free)',
      'Direct in-app student chat & pickup scheduler',
    ],
  },
  {
    tier: 'premium',
    name: 'Active Seller',
    badgeLabel: '⭐ POPULAR',
    tagline: 'For active student sellers and single-room student hosts',
    targetAudience: 'Sellers with frequent items, snack sellers, tutors & house managers',
    monthlyPriceRM: 4.90,
    semesterPriceRM: 18.00,
    annualPriceRM: 32.00,
    maxMarketplaceListings: 12,
    maxRentalListings: 3,
    dailyAIEvaluations: 50,
    searchBoostMultiplier: 1.5,
    analyticsLevel: 'Weekly Insights',
    verificationTurnaround: 'Priority (24h)',
    recommended: true,
    features: [
      'Up to 12 active marketplace item listings',
      'Up to 3 featured rental & accommodation listings',
      'Unlimited daily AI price valuations & suggestions',
      '1.5x Search Ranking Boost + "⭐ Premium Seller" badge',
      'Priority verification approval in under 24 hours',
      'Weekly visitor traffic & click-through analytics',
      'Direct WhatsApp inquiry button on listings',
      'Featured border styling in category search results',
      'Cancel or switch plans anytime with zero penalty',
    ],
  },
  {
    tier: 'pro',
    name: 'FYP Venture / Power Host',
    badgeLabel: '🚀 PRO VENTURE',
    tagline: 'For Commerce FYP businesses, student enterprises & property managers',
    targetAudience: 'Student startups, printing services, food vendors & multi-room hosts',
    monthlyPriceRM: 9.90,
    semesterPriceRM: 38.00,
    annualPriceRM: 68.00,
    maxMarketplaceListings: -1,
    maxRentalListings: -1,
    dailyAIEvaluations: -1,
    searchBoostMultiplier: 2.5,
    analyticsLevel: 'Full FYP Funnel & Conversion',
    verificationTurnaround: 'Expedited (<12h)',
    recommended: false,
    features: [
      'Unlimited marketplace & digital template listings',
      'Unlimited rental listings with live occupancy manager',
      'Unlimited AI price valuations & competitor insights',
      '2.5x Top Search Boost + Homepage spotlight placement',
      'Expedited same-day verification (<12 hours review)',
      'Full FYP Campaign Funnel: conversions & peak-hour traffic',
      'Google Data Studio / Looker Studio export integration',
      'Multi-member business team badge for group FYP projects',
      'Dedicated Campus Corner student business promotion',
      'Direct customer CSV export & receipt download',
    ],
  },
];

let subscriptionsStore = [
  {
    id: 'sub_1',
    userId: 'usr_sub_std_1',
    userName: 'Farhan Hakim',
    studentMatric: '15DPM23F1008',
    department: 'Commerce (Jabatan Perdagangan)',
    course: 'Diploma in Marketing (DPM)',
    semester: 2,
    tier: 'premium',
    planName: 'Active Seller',
    billingCycle: 'semester',
    pricePaidRM: 18.00,
    normalizedMonthlyMRR_RM: 3.00,
    paymentMethod: 'Campus Student E-Wallet',
    status: 'active',
    startDate: '2026-08-01',
    endDate: '2027-01-31',
    daysRemaining: 142,
    autoRenew: true,
    transactionRef: 'SUB-TX-84910-EWAL',
    activeMarketplaceListings: 4,
    activeRentalListings: 1,
    aiValuationsUsed: 19,
    inquiriesReceived: 34,
    verifiedSeller: true,
  },
  {
    id: 'sub_2',
    userId: 'usr_2',
    userName: 'Siti Nurhaliza',
    studentMatric: '15DAT22F2014',
    department: 'Commerce (Jabatan Perdagangan)',
    course: 'Diploma in Accountancy (DAT)',
    semester: 4,
    tier: 'pro',
    planName: 'FYP Venture / Power Host',
    billingCycle: 'semester',
    pricePaidRM: 38.00,
    normalizedMonthlyMRR_RM: 6.33,
    paymentMethod: 'DuitNow QR',
    status: 'active',
    startDate: '2026-08-15',
    endDate: '2027-02-15',
    daysRemaining: 157,
    autoRenew: true,
    transactionRef: 'SUB-TX-90218-DNOW',
    activeMarketplaceListings: 14,
    activeRentalListings: 2,
    aiValuationsUsed: 42,
    inquiriesReceived: 98,
    verifiedSeller: true,
  },
  {
    id: 'sub_3',
    userId: 'usr_3',
    userName: 'Muhammad Harith',
    studentMatric: '15DDT23F1042',
    department: 'Information Technology (JTMK)',
    course: 'Diploma in Digital Technology (DDT)',
    semester: 3,
    tier: 'pro',
    planName: 'FYP Venture / Power Host',
    billingCycle: 'monthly',
    pricePaidRM: 9.90,
    normalizedMonthlyMRR_RM: 9.90,
    paymentMethod: 'FPX Online Banking',
    status: 'active',
    startDate: '2026-08-25',
    endDate: '2026-09-25',
    daysRemaining: 14,
    autoRenew: true,
    transactionRef: 'SUB-TX-33829-FPX',
    activeMarketplaceListings: 8,
    activeRentalListings: 0,
    aiValuationsUsed: 65,
    inquiriesReceived: 51,
    verifiedSeller: true,
  },
  {
    id: 'sub_4',
    userId: 'usr_4',
    userName: 'Nurul Ain Binti Zulkifli',
    studentMatric: '15DKM23F1090',
    department: 'Mechanical Engineering (JKM)',
    course: 'Diploma in Mechanical Engineering',
    semester: 2,
    tier: 'premium',
    planName: 'Active Seller',
    billingCycle: 'monthly',
    pricePaidRM: 4.90,
    normalizedMonthlyMRR_RM: 4.90,
    paymentMethod: 'DuitNow QR',
    status: 'active',
    startDate: '2026-09-02',
    endDate: '2026-10-02',
    daysRemaining: 21,
    autoRenew: true,
    transactionRef: 'SUB-TX-49201-DNOW',
    activeMarketplaceListings: 5,
    activeRentalListings: 1,
    aiValuationsUsed: 12,
    inquiriesReceived: 18,
    verifiedSeller: true,
  },
  {
    id: 'sub_5',
    userId: 'usr_5',
    userName: 'Kevashan Nair',
    studentMatric: '15DEP22F1033',
    department: 'Electrical Engineering (JKE)',
    course: 'Diploma in Electronic Engineering',
    semester: 5,
    tier: 'free',
    planName: 'Siswa Basic',
    billingCycle: 'monthly',
    pricePaidRM: 0.00,
    normalizedMonthlyMRR_RM: 0.00,
    paymentMethod: 'Free',
    status: 'active',
    startDate: '2026-07-01',
    endDate: '2027-06-30',
    daysRemaining: 292,
    autoRenew: false,
    transactionRef: 'FREE-TIER-PERMANENT',
    activeMarketplaceListings: 2,
    activeRentalListings: 0,
    aiValuationsUsed: 7,
    inquiriesReceived: 9,
    verifiedSeller: true,
  },
  {
    id: 'sub_6',
    userId: 'usr_6',
    userName: 'Farah Nadia',
    studentMatric: '15DIB23F2005',
    department: 'Commerce (Jabatan Perdagangan)',
    course: 'Diploma in Islamic Banking (DIB)',
    semester: 3,
    tier: 'premium',
    planName: 'Active Seller',
    billingCycle: 'semester',
    pricePaidRM: 18.00,
    normalizedMonthlyMRR_RM: 3.00,
    paymentMethod: 'Campus Student E-Wallet',
    status: 'active',
    startDate: '2026-08-10',
    endDate: '2027-02-10',
    daysRemaining: 152,
    autoRenew: true,
    transactionRef: 'SUB-TX-10924-EWAL',
    activeMarketplaceListings: 7,
    activeRentalListings: 0,
    aiValuationsUsed: 28,
    inquiriesReceived: 44,
    verifiedSeller: true,
  },
  {
    id: 'sub_7',
    userId: 'usr_7',
    userName: 'Tan Wei Ming',
    studentMatric: '15DKA22F1012',
    department: 'Civil Engineering (JKA)',
    course: 'Diploma in Civil Engineering',
    semester: 5,
    tier: 'free',
    planName: 'Siswa Basic',
    billingCycle: 'monthly',
    pricePaidRM: 0.00,
    normalizedMonthlyMRR_RM: 0.00,
    paymentMethod: 'Free',
    status: 'active',
    startDate: '2026-06-15',
    endDate: '2027-06-15',
    daysRemaining: 277,
    autoRenew: false,
    transactionRef: 'FREE-TIER-PERMANENT',
    activeMarketplaceListings: 1,
    activeRentalListings: 0,
    aiValuationsUsed: 4,
    inquiriesReceived: 3,
    verifiedSeller: false,
  },
  {
    id: 'sub_8',
    userId: 'usr_8',
    userName: 'Encik Kamal Ariffin',
    studentMatric: 'HOST-751102-08',
    department: 'Campus Accommodation & Hostels',
    course: 'Verified Senior Landlord & Host',
    semester: 6,
    tier: 'pro',
    planName: 'FYP Venture / Power Host',
    billingCycle: 'semester',
    pricePaidRM: 38.00,
    normalizedMonthlyMRR_RM: 6.33,
    paymentMethod: 'DuitNow QR',
    status: 'active',
    startDate: '2026-08-01',
    endDate: '2027-01-31',
    daysRemaining: 142,
    autoRenew: true,
    transactionRef: 'SUB-TX-55192-DNOW',
    activeMarketplaceListings: 1,
    activeRentalListings: 6,
    aiValuationsUsed: 15,
    inquiriesReceived: 142,
    verifiedSeller: true,
  },
  {
    id: 'sub_9',
    userId: 'usr_9',
    userName: 'Anis Sofea',
    studentMatric: '15DPM23F1088',
    department: 'Commerce (Jabatan Perdagangan)',
    course: 'Diploma in Marketing (DPM)',
    semester: 2,
    tier: 'premium',
    planName: 'Active Seller',
    billingCycle: 'monthly',
    pricePaidRM: 4.90,
    normalizedMonthlyMRR_RM: 4.90,
    paymentMethod: 'DuitNow QR',
    status: 'active',
    startDate: '2026-09-08',
    endDate: '2026-10-08',
    daysRemaining: 27,
    autoRenew: true,
    transactionRef: 'SUB-TX-77182-DNOW',
    activeMarketplaceListings: 6,
    activeRentalListings: 0,
    aiValuationsUsed: 31,
    inquiriesReceived: 29,
    verifiedSeller: true,
  },
  {
    id: 'sub_10',
    userId: 'usr_10',
    userName: 'Dinesh Kumar',
    studentMatric: '15DDT22F2091',
    department: 'Information Technology (JTMK)',
    course: 'Diploma in Digital Technology (DDT)',
    semester: 4,
    tier: 'pro',
    planName: 'FYP Venture / Power Host',
    billingCycle: 'semester',
    pricePaidRM: 38.00,
    normalizedMonthlyMRR_RM: 6.33,
    paymentMethod: 'FPX Online Banking',
    status: 'active',
    startDate: '2026-08-20',
    endDate: '2027-02-20',
    daysRemaining: 162,
    autoRenew: true,
    transactionRef: 'SUB-TX-99120-FPX',
    activeMarketplaceListings: 11,
    activeRentalListings: 1,
    aiValuationsUsed: 88,
    inquiriesReceived: 76,
    verifiedSeller: true,
  },
  {
    id: 'sub_11',
    userId: 'usr_11',
    userName: 'Nur Fatin Najwa',
    studentMatric: '15DAT23F1020',
    department: 'Commerce (Jabatan Perdagangan)',
    course: 'Diploma in Accountancy (DAT)',
    semester: 3,
    tier: 'free',
    planName: 'Siswa Basic',
    billingCycle: 'monthly',
    pricePaidRM: 0.00,
    normalizedMonthlyMRR_RM: 0.00,
    paymentMethod: 'Free',
    status: 'active',
    startDate: '2026-07-20',
    endDate: '2027-07-20',
    daysRemaining: 312,
    autoRenew: false,
    transactionRef: 'FREE-TIER-PERMANENT',
    activeMarketplaceListings: 3,
    activeRentalListings: 0,
    aiValuationsUsed: 9,
    inquiriesReceived: 12,
    verifiedSeller: true,
  },
  {
    id: 'sub_12',
    userId: 'usr_12',
    userName: 'Luqman Hakim',
    studentMatric: '15DKM22F1045',
    department: 'Mechanical Engineering (JKM)',
    course: 'Diploma in Mechanical Engineering',
    semester: 5,
    tier: 'premium',
    planName: 'Active Seller',
    billingCycle: 'semester',
    pricePaidRM: 18.00,
    normalizedMonthlyMRR_RM: 3.00,
    paymentMethod: 'Campus Student E-Wallet',
    status: 'active',
    startDate: '2026-08-12',
    endDate: '2027-02-12',
    daysRemaining: 154,
    autoRenew: true,
    transactionRef: 'SUB-TX-61920-EWAL',
    activeMarketplaceListings: 4,
    activeRentalListings: 2,
    aiValuationsUsed: 16,
    inquiriesReceived: 31,
    verifiedSeller: true,
  },
];

// GET /api/subscriptions/plans - Return Free, Premium, Pro plans
app.get('/api/subscriptions/plans', (req, res) => {
  res.json({
    success: true,
    plans: subscriptionPlansData,
  });
});

// GET /api/subscriptions/all - Return all subscribers
app.get('/api/subscriptions/all', (req, res) => {
  res.json({
    success: true,
    subscriptions: subscriptionsStore,
  });
});

// GET /api/subscriptions/metrics - Calculate real-time MRR, ARPU & conversion stats
app.get('/api/subscriptions/metrics', (req, res) => {
  const activeSubs = subscriptionsStore.filter(s => s.status === 'active');
  const paidSubs = activeSubs.filter(s => s.tier !== 'free');
  
  const totalMRR = activeSubs.reduce((sum, s) => sum + s.normalizedMonthlyMRR_RM, 0);
  const totalARR = totalMRR * 12;
  const arpu = paidSubs.length > 0 ? (totalMRR / paidSubs.length) : 0;
  
  const freeCount = activeSubs.filter(s => s.tier === 'free').length;
  const premiumCount = activeSubs.filter(s => s.tier === 'premium').length;
  const proCount = activeSubs.filter(s => s.tier === 'pro').length;
  const totalActive = activeSubs.length;
  const conversionRate = totalActive > 0 ? ((paidSubs.length / totalActive) * 100) : 0;

  // Department segmentation
  const deptMap: Record<string, { revenue: number; count: number }> = {};
  activeSubs.forEach(s => {
    if (!deptMap[s.department]) {
      deptMap[s.department] = { revenue: 0, count: 0 };
    }
    deptMap[s.department].revenue += s.normalizedMonthlyMRR_RM;
    deptMap[s.department].count += 1;
  });

  const departmentRevenue = Object.entries(deptMap).map(([department, data]) => ({
    department,
    revenueRM: Math.round(data.revenue * 10) / 10,
    subscribersCount: data.count,
  }));

  res.json({
    success: true,
    metrics: {
      totalMRR_RM: Math.round(totalMRR * 100) / 100,
      totalARR_RM: Math.round(totalARR * 100) / 100,
      arpuRM: Math.round(arpu * 100) / 100,
      totalActiveSubscribers: totalActive,
      freeCount,
      premiumCount,
      proCount,
      conversionRatePercent: Math.round(conversionRate * 10) / 10,
      semesterRenewalRatePercent: 86.4,
      departmentRevenue,
    },
  });
});

// POST /api/subscriptions/upgrade - Upgrade or switch user plan
app.post('/api/subscriptions/upgrade', (req, res) => {
  const { userId, tier, billingCycle, paymentMethod, studentMatric, department, course, semester, userName } = req.body;

  if (!tier || !['free', 'premium', 'pro'].includes(tier)) {
    return res.status(400).json({ error: 'Invalid subscription tier selected.' });
  }

  const plan = subscriptionPlansData.find(p => p.tier === tier);
  if (!plan) {
    return res.status(404).json({ error: 'Subscription plan configuration not found.' });
  }

  const cycle = billingCycle || 'semester';
  const pricePaid = tier === 'free' ? 0 : cycle === 'monthly' ? plan.monthlyPriceRM : plan.semesterPriceRM;
  const normalizedMRR = tier === 'free' ? 0 : cycle === 'monthly' ? plan.monthlyPriceRM : Math.round((plan.semesterPriceRM / 6) * 100) / 100;
  
  const now = new Date();
  const startDateStr = now.toISOString().split('T')[0];
  const end = new Date(now);
  if (cycle === 'monthly') {
    end.setMonth(end.getMonth() + 1);
  } else {
    end.setMonth(end.getMonth() + 6);
  }
  const endDateStr = end.toISOString().split('T')[0];

  const transactionRef = tier === 'free' 
    ? `FREE-TIER-${Date.now().toString().slice(-6)}` 
    : `SUB-PAY-${Date.now().toString().slice(-6)}-${(paymentMethod || 'DNOW').replace(/\s+/g, '').slice(0, 4).toUpperCase()}`;

  const existingIdx = subscriptionsStore.findIndex(s => s.userId === (userId || 'usr_me'));
  const record = {
    id: existingIdx !== -1 ? subscriptionsStore[existingIdx].id : `sub_${Date.now()}`,
    userId: userId || 'usr_me',
    userName: userName || 'Student',
    studentMatric: studentMatric || 'N/A',
    department: department || 'General',
    course: course || 'General',
    semester: Number(semester) || 1,
    tier: tier as 'free' | 'premium' | 'pro',
    planName: plan.name,
    billingCycle: cycle as 'monthly' | 'semester' | 'annual',
    pricePaidRM: pricePaid,
    normalizedMonthlyMRR_RM: normalizedMRR,
    paymentMethod: tier === 'free' ? 'Free' : (paymentMethod || 'DuitNow QR'),
    status: 'active' as const,
    startDate: startDateStr,
    endDate: endDateStr,
    daysRemaining: cycle === 'monthly' ? 30 : 180,
    autoRenew: true,
    transactionRef,
    activeMarketplaceListings: existingIdx !== -1 ? subscriptionsStore[existingIdx].activeMarketplaceListings : 4,
    activeRentalListings: existingIdx !== -1 ? subscriptionsStore[existingIdx].activeRentalListings : 1,
    aiValuationsUsed: existingIdx !== -1 ? subscriptionsStore[existingIdx].aiValuationsUsed : 15,
    inquiriesReceived: existingIdx !== -1 ? subscriptionsStore[existingIdx].inquiriesReceived : 30,
    verifiedSeller: true,
  };

  if (existingIdx !== -1) {
    subscriptionsStore[existingIdx] = record;
  } else {
    subscriptionsStore.unshift(record);
  }

  res.json({
    success: true,
    message: `Successfully activated ${plan.name} (${cycle} billing).`,
    subscription: record,
    plan,
  });
});

// GET /api/subscriptions/export/data-studio.csv - Generate Looker Studio / Google Data Studio CSV download
app.get('/api/subscriptions/export/data-studio.csv', (req, res) => {
  const headers = [
    'Student_Matric_ID',
    'Student_Name',
    'Academic_Department',
    'Diploma_Course',
    'Academic_Semester',
    'Subscription_Tier',
    'Billing_Cycle',
    'Payment_Method',
    'Subscription_Status',
    'Start_Date',
    'End_Date',
    'Days_Remaining',
    'Price_Paid_RM',
    'Normalized_MRR_RM',
    'Active_Marketplace_Listings',
    'Active_Rental_Listings',
    'AI_Valuations_Used',
    'Inquiries_Received',
    'Verified_Seller_Status',
  ];

  const escapeCsv = (val: any) => {
    if (val === null || val === undefined) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = subscriptionsStore.map(sub => [
    escapeCsv(sub.studentMatric),
    escapeCsv(sub.userName),
    escapeCsv(sub.department),
    escapeCsv(sub.course),
    escapeCsv(sub.semester),
    escapeCsv(sub.tier.toUpperCase()),
    escapeCsv(sub.billingCycle),
    escapeCsv(sub.paymentMethod),
    escapeCsv(sub.status),
    escapeCsv(sub.startDate),
    escapeCsv(sub.endDate),
    escapeCsv(sub.daysRemaining),
    escapeCsv(sub.pricePaidRM.toFixed(2)),
    escapeCsv(sub.normalizedMonthlyMRR_RM.toFixed(2)),
    escapeCsv(sub.activeMarketplaceListings),
    escapeCsv(sub.activeRentalListings),
    escapeCsv(sub.aiValuationsUsed),
    escapeCsv(sub.inquiriesReceived),
    escapeCsv(sub.verifiedSeller ? 'YES' : 'NO'),
  ].join(','));

  const csvContent = [headers.join(','), ...rows].join('\n');

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="campus_corner_subscriptions_data_studio.csv"');
  res.status(200).send(csvContent);
});

// GET /api/subscriptions/data-studio-fields - Return Field Metadata schema for Google Data Studio
app.get('/api/subscriptions/data-studio-fields', (req, res) => {
  res.json({
    sourceName: 'Campus Corner Polytechnic Subscriptions',
    version: '1.0.0',
    compatibleWith: ['Google Looker Studio', 'Google Data Studio', 'BigQuery', 'Google Sheets'],
    dimensions: [
      { id: 'Student_Matric_ID', name: 'Student Matric ID', type: 'TEXT' },
      { id: 'Student_Name', name: 'Student Name', type: 'TEXT' },
      { id: 'Academic_Department', name: 'Academic Department', type: 'TEXT' },
      { id: 'Diploma_Course', name: 'Diploma Course', type: 'TEXT' },
      { id: 'Academic_Semester', name: 'Academic Semester', type: 'NUMBER' },
      { id: 'Subscription_Tier', name: 'Subscription Tier', type: 'TEXT' },
      { id: 'Billing_Cycle', name: 'Billing Cycle', type: 'TEXT' },
      { id: 'Payment_Method', name: 'Payment Method', type: 'TEXT' },
      { id: 'Subscription_Status', name: 'Subscription Status', type: 'TEXT' },
      { id: 'Start_Date', name: 'Start Date', type: 'DATE' },
      { id: 'End_Date', name: 'End Date', type: 'DATE' },
    ],
    metrics: [
      { id: 'Price_Paid_RM', name: 'Price Paid (RM)', type: 'CURRENCY_MYR', defaultAggregation: 'SUM' },
      { id: 'Normalized_MRR_RM', name: 'Normalized MRR (RM)', type: 'CURRENCY_MYR', defaultAggregation: 'SUM' },
      { id: 'Active_Marketplace_Listings', name: 'Active Marketplace Listings', type: 'NUMBER', defaultAggregation: 'SUM' },
      { id: 'Active_Rental_Listings', name: 'Active Rental Listings', type: 'NUMBER', defaultAggregation: 'SUM' },
      { id: 'AI_Valuations_Used', name: 'AI Valuations Used', type: 'NUMBER', defaultAggregation: 'SUM' },
      { id: 'Inquiries_Received', name: 'Inquiries Received', type: 'NUMBER', defaultAggregation: 'SUM' },
    ],
  });
});


async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
