import React, { useState } from 'react';
import { 
  AlertTriangle, 
  PhoneCall, 
  MapPin, 
  Shield, 
  ShieldAlert, 
  ShieldCheck, 
  Users, 
  Radio, 
  Clock, 
  X, 
  Plus, 
  Trash2, 
  Edit3, 
  CheckCircle2, 
  Car, 
  Flame, 
  HeartPulse, 
  HelpCircle, 
  Info, 
  Compass, 
  Building, 
  EyeOff, 
  ChevronRight, 
  Send, 
  Volume2,
  RefreshCw,
  Lock
} from 'lucide-react';
import { 
  User, 
  CampusSOSAlert, 
  EmergencyCategory, 
  EmergencyContact, 
  CampusAuthorityContact 
} from '../types';
import { CAMPUS_AUTHORITY_CONTACTS } from '../data/mockData';

interface CampusSOSViewProps {
  currentUser: User;
  alerts: CampusSOSAlert[];
  onTriggerSOSModal: () => void;
  onCancelAlert: (alertId: string, reason: string) => void;
  onUpdateAlertCategory: (alertId: string, category: EmergencyCategory, description?: string) => void;
  onUpdateEmergencyContacts: (contacts: EmergencyContact[]) => void;
  onUpdateSOSPreferences: (prefs: User['sosPreferences']) => void;
  isDemoMode: boolean;
  setIsDemoMode: (val: boolean) => void;
}

const CATEGORY_MAP: Record<EmergencyCategory, { icon: any; color: string; bg: string }> = {
  'Accident': { icon: Car, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200' },
  'Medical Emergency': { icon: HeartPulse, color: 'text-rose-600 dark:text-rose-400', bg: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200' },
  'Fire': { icon: Flame, color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-50 dark:bg-orange-950/40 border-orange-200' },
  'Safety Emergency': { icon: ShieldAlert, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-50 dark:bg-red-950/40 border-red-200' },
  'Other Emergency': { icon: HelpCircle, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200' },
};

export const CampusSOSView: React.FC<CampusSOSViewProps> = ({
  currentUser,
  alerts,
  onTriggerSOSModal,
  onCancelAlert,
  onUpdateAlertCategory,
  onUpdateEmergencyContacts,
  onUpdateSOSPreferences,
  isDemoMode,
  setIsDemoMode,
}) => {
  const [activeTab, setActiveTab] = useState<'sos_center' | 'contacts' | 'authorities' | 'safety_guide'>('sos_center');
  const [selectedAlertForMap, setSelectedAlertForMap] = useState<CampusSOSAlert | null>(null);

  // Cancel Modal State
  const [alertToCancel, setAlertToCancel] = useState<CampusSOSAlert | null>(null);
  const [cancelReason, setCancelReason] = useState<string>('Accidental trigger / Problem already resolved');

  // Contact Form State
  const [isAddingContact, setIsAddingContact] = useState<boolean>(false);
  const [newContactName, setNewContactName] = useState<string>('');
  const [newContactPhone, setNewContactPhone] = useState<string>('');
  const [newContactEmail, setNewContactEmail] = useState<string>('');
  const [newContactRelation, setNewContactRelation] = useState<EmergencyContact['relationship']>('Parent/Guardian');
  const [newContactAutoNotify, setNewContactAutoNotify] = useState<boolean>(true);

  // Check if current user has an active alert
  const myActiveAlert = alerts.find(
    (a) => a.userId === currentUser.id && a.status === 'active'
  );

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim() || !newContactPhone.trim()) return;

    const newContact: EmergencyContact = {
      id: `ec_${Date.now()}`,
      name: newContactName.trim(),
      phone: newContactPhone.trim(),
      email: newContactEmail.trim() || undefined,
      relationship: newContactRelation,
      autoNotify: newContactAutoNotify,
      isOfficialAuthority: false,
    };

    const currentList = currentUser.emergencyContacts || [];
    onUpdateEmergencyContacts([...currentList, newContact]);

    // Reset Form
    setNewContactName('');
    setNewContactPhone('');
    setNewContactEmail('');
    setIsAddingContact(false);
  };

  const handleRemoveContact = (id: string) => {
    const updated = (currentUser.emergencyContacts || []).filter((c) => c.id !== id);
    onUpdateEmergencyContacts(updated);
  };

  const handleToggleAutoNotify = (id: string) => {
    const updated = (currentUser.emergencyContacts || []).map((c) =>
      c.id === id ? { ...c, autoNotify: !c.autoNotify } : c
    );
    onUpdateEmergencyContacts(updated);
  };

  const handleConfirmCancelAlert = () => {
    if (alertToCancel) {
      onCancelAlert(alertToCancel.id, cancelReason);
      setAlertToCancel(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="campus_sos_container">
      
      {/* 1. Header Banner & Mode Selector */}
      <div className="bg-gradient-to-r from-red-950 via-slate-900 to-red-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-red-800/40 relative overflow-hidden">
        {/* Subtle background emergency pulse ring */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-red-600/90 text-white text-[11px] font-black uppercase px-3 py-1 rounded-full flex items-center gap-1.5 shadow-xs">
                <Radio className="w-3.5 h-3.5 text-white animate-ping" />
                CAMPUS SOS SYSTEM
              </span>
              <span className="bg-white/10 text-red-200 text-xs px-2.5 py-1 rounded-full font-semibold border border-white/10">
                Politeknik Sultan Azlan Shah (PSAS)
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              One-Tap Campus Emergency Alert System
            </h1>
            <p className="text-xs sm:text-sm text-red-100/90 leading-relaxed">
              Quickly notify nearby campus students, your trusted emergency contacts, and campus security responders during emergencies on and around campus grounds.
            </p>
          </div>

          {/* Demo Mode & Fast Trigger Card */}
          <div className="bg-black/40 backdrop-blur-md rounded-2xl p-4 border border-red-500/30 flex flex-col gap-3 min-w-[260px]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-200">Prototype Mode:</span>
              <button
                onClick={() => setIsDemoMode(!isDemoMode)}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                  isDemoMode
                    ? 'bg-amber-400 text-slate-950 shadow-xs'
                    : 'bg-red-600 text-white animate-pulse'
                }`}
              >
                {isDemoMode ? 'DEMO SIMULATION' : 'LIVE ALERT ACTIVE'}
              </button>
            </div>

            <p className="text-[10px] text-slate-300">
              {isDemoMode
                ? '✅ Safe for presentations. Dispatches simulated broadcasts without disturbing real 999 responders.'
                : '⚠️ Live mode will trigger real local campus broadcasts.'}
            </p>

            <button
              onClick={onTriggerSOSModal}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-black text-xs rounded-xl shadow-lg shadow-red-600/40 transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <AlertTriangle className="w-4 h-4 text-amber-300" />
              <span>SEND SOS ALERT</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. SOS Feature Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('sos_center')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'sos_center'
              ? 'bg-red-600 text-white shadow-sm font-black'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>SOS Center & Live Broadcasts</span>
          {alerts.filter(a => a.status === 'active').length > 0 && (
            <span className="bg-white text-red-600 px-1.5 py-0.2 rounded-full text-[10px] font-black">
              {alerts.filter(a => a.status === 'active').length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('contacts')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'contacts'
              ? 'bg-red-600 text-white shadow-sm font-black'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Emergency Contacts</span>
          <span className="bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 px-1.5 py-0.2 rounded-full text-[10px] font-bold">
            {currentUser.emergencyContacts?.length || 0}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('authorities')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'authorities'
              ? 'bg-red-600 text-white shadow-sm font-black'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Campus Authority Directory</span>
          <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 px-1.5 py-0.2 rounded-full text-[10px] font-bold">
            24/7
          </span>
        </button>

        <button
          onClick={() => setActiveTab('safety_guide')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeTab === 'safety_guide'
              ? 'bg-red-600 text-white shadow-sm font-black'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Info className="w-4 h-4" />
          <span>Safety Protocols & Advice</span>
        </button>
      </div>

      {/* TAB 1: SOS Center & Live Feed */}
      {activeTab === 'sos_center' && (
        <div className="space-y-6">
          
          {/* Active User Alert Status Screen (if user triggered one) */}
          {myActiveAlert && (
            <div className="bg-red-50 dark:bg-red-950/40 border-2 border-red-500 rounded-3xl p-6 shadow-xl space-y-4 animate-pulse-subtle">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-red-200 dark:border-red-800/80 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-600/30 animate-bounce">
                    <Radio className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base sm:text-lg font-black text-red-700 dark:text-red-400 uppercase">
                        SOS ALERT SENT
                      </h3>
                      {myActiveAlert.isDemo && (
                        <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                          Demo Mode
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                      &quot;Your emergency alert has been shared with the selected recipients.&quot;
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setAlertToCancel(myActiveAlert)}
                  className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-red-100 text-red-700 dark:text-red-300 font-bold text-xs rounded-xl border border-red-300 dark:border-red-700 shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
                >
                  CANCEL ALERT
                </button>
              </div>

              {/* Status Details Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-red-100 dark:border-red-900/40">
                  <span className="text-slate-500 dark:text-slate-400 block text-[10px] font-semibold">Alert Time</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1 mt-0.5">
                    <Clock className="w-3.5 h-3.5 text-red-500" />
                    {myActiveAlert.timestamp}
                  </span>
                </div>

                <div className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-red-100 dark:border-red-900/40">
                  <span className="text-slate-500 dark:text-slate-400 block text-[10px] font-semibold">Emergency Type</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1 mt-0.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                    {myActiveAlert.category}
                  </span>
                </div>

                <div className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-red-100 dark:border-red-900/40">
                  <span className="text-slate-500 dark:text-slate-400 block text-[10px] font-semibold">Location</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1 mt-0.5 truncate">
                    <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0" />
                    {myActiveAlert.locationName}
                  </span>
                </div>

                <div className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-red-100 dark:border-red-900/40">
                  <span className="text-slate-500 dark:text-slate-400 block text-[10px] font-semibold">Recipients Reached</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1 mt-0.5">
                    <Users className="w-3.5 h-3.5 text-emerald-500" />
                    {myActiveAlert.notifiedUsersCount} Nearby Users
                  </span>
                </div>
              </div>

              {/* Classify / Update Details Afterward */}
              <div className="bg-white/80 dark:bg-slate-900/80 p-3.5 rounded-2xl border border-red-100 dark:border-red-900/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="text-xs">
                  <span className="font-bold text-slate-800 dark:text-slate-200">Need to update category or details?</span>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    For fast responses, you can refine your category or description even after dispatching.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={myActiveAlert.category}
                    onChange={(e) => onUpdateAlertCategory(myActiveAlert.id, e.target.value as EmergencyCategory)}
                    className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-800 dark:text-slate-200"
                  >
                    <option value="Accident">🚗 Accident</option>
                    <option value="Medical Emergency">🏥 Medical Emergency</option>
                    <option value="Fire">🔥 Fire</option>
                    <option value="Safety Emergency">⚠️ Safety Emergency</option>
                    <option value="Other Emergency">🆘 Other Emergency</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Big One-Tap SOS Button Action Center */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left 2 Cols: Main Emergency Dispatch Station */}
            <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6 flex flex-col items-center text-center">
              
              <div className="space-y-2 max-w-md">
                <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-slate-100">
                  Instant Emergency SOS Trigger
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Pressing the button initiates a short 4-second confirmation countdown with cancel protection to avoid accidental triggers.
                </p>
              </div>

              {/* Big Red SOS Button */}
              <div className="relative my-4 flex items-center justify-center">
                {/* Outer Ambient Ripple */}
                <div className="absolute w-44 h-44 sm:w-52 sm:h-52 rounded-full bg-red-500/10 dark:bg-red-500/20 animate-ping pointer-events-none" />
                <div className="absolute w-40 h-40 sm:w-48 sm:h-48 rounded-full bg-red-600/20 dark:bg-red-600/30 animate-pulse pointer-events-none" />

                <button
                  id="main_campus_sos_big_button"
                  onClick={onTriggerSOSModal}
                  className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-gradient-to-tr from-red-600 via-red-500 to-rose-500 hover:from-red-700 hover:to-rose-600 text-white font-black shadow-2xl shadow-red-600/50 flex flex-col items-center justify-center transition-transform active:scale-90 hover:scale-105 cursor-pointer border-4 border-white dark:border-slate-900"
                >
                  <AlertTriangle className="w-8 h-8 sm:w-10 sm:h-10 mb-1 text-amber-300" />
                  <span className="text-2xl sm:text-3xl tracking-widest uppercase font-black">SOS</span>
                  <span className="text-[10px] tracking-wider uppercase opacity-90 font-bold">EMERGENCY</span>
                </button>
              </div>

              {/* Quick Categories Bar */}
              <div className="w-full pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Quick Pre-classified Emergency Categories:
                </span>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 flex items-center gap-1.5">
                    🚗 Accident
                  </span>
                  <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 flex items-center gap-1.5">
                    🏥 Medical Emergency
                  </span>
                  <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-orange-50 dark:bg-orange-950/40 text-orange-700 dark:text-orange-300 border border-orange-200 dark:border-orange-800 flex items-center gap-1.5">
                    🔥 Fire
                  </span>
                  <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 flex items-center gap-1.5">
                    ⚠️ Safety Emergency
                  </span>
                  <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 flex items-center gap-1.5">
                    🆘 Other Emergency
                  </span>
                </div>
              </div>

            </div>

            {/* Right Col: Instant Authorities Hotline & Speed Dial */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Direct Campus Hotlines</span>
                </h3>
                <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full border border-emerald-200">
                  Ready
                </span>
              </div>

              <div className="space-y-3">
                {CAMPUS_AUTHORITY_CONTACTS.slice(0, 3).map((auth) => (
                  <div
                    key={auth.id}
                    className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700 space-y-1.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-bold text-xs text-slate-800 dark:text-slate-200 truncate">
                          {auth.name}
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400">
                          {auth.location}
                        </div>
                      </div>
                      <a
                        href={`tel:${auth.phone.replace(/[^0-9]/g, '')}`}
                        className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                      >
                        <PhoneCall className="w-3 h-3" />
                        <span>Call</span>
                      </a>
                    </div>
                    <div className="text-[11px] font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      📞 {auth.phone}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setActiveTab('authorities')}
                  className="w-full py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-colors text-center cursor-pointer"
                >
                  View All Campus Authorities & Hotlines →
                </button>
              </div>
            </div>

          </div>

          {/* 3. Live Campus SOS Broadcast Feed */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Radio className="w-5 h-5 text-red-600 animate-pulse" />
                  <span>Live Campus SOS Emergency Broadcasts</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Real-time safety alerts reported by verified students on or around PSAS campus grounds.
                </p>
              </div>

              <div className="text-xs text-slate-500 flex items-center gap-1.5 font-medium">
                <Clock className="w-3.5 h-3.5" />
                <span>Auto-refreshing live channel</span>
              </div>
            </div>

            {alerts.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                <ShieldCheck className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-80" />
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">All Clear on Campus</p>
                <p className="text-xs text-slate-500">No active emergency alerts reported at this moment.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {alerts.map((alert) => {
                  const catConfig = CATEGORY_MAP[alert.category] || CATEGORY_MAP['Other Emergency'];
                  const Icon = catConfig.icon;
                  const isActive = alert.status === 'active';

                  return (
                    <div
                      key={alert.id}
                      className={`p-5 rounded-2xl border transition-all space-y-3 ${
                        isActive
                          ? 'bg-white dark:bg-slate-900 border-red-300 dark:border-red-800 shadow-md ring-1 ring-red-500/20'
                          : 'bg-slate-50/70 dark:bg-slate-850 border-slate-200 dark:border-slate-800 opacity-75'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2.5">
                          <div className={`p-2 rounded-xl border ${catConfig.bg}`}>
                            <Icon className={`w-5 h-5 ${catConfig.color}`} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-xs text-slate-900 dark:text-slate-100">
                                {alert.category}
                              </span>
                              {alert.isDemo && (
                                <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase">
                                  Demo
                                </span>
                              )}
                              {isActive ? (
                                <span className="bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 text-[10px] font-bold px-2 py-0.2 rounded-full">
                                  ACTIVE
                                </span>
                              ) : (
                                <span className="bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold px-2 py-0.2 rounded-full">
                                  RESOLVED / CANCELLED
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3" />
                              <span>{alert.timestamp}</span>
                              <span>•</span>
                              <span>{alert.isAnonymous ? 'Anonymous Student' : alert.userName}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Location Landmark */}
                      <div className="bg-slate-50 dark:bg-slate-800 p-2.5 rounded-xl text-xs flex items-center gap-2 text-slate-800 dark:text-slate-200">
                        <MapPin className="w-4 h-4 text-red-500 shrink-0" />
                        <span className="font-bold truncate">{alert.locationName}</span>
                      </div>

                      {/* Description if present */}
                      {alert.description && (
                        <p className="text-xs text-slate-600 dark:text-slate-300 bg-red-50/50 dark:bg-red-950/20 p-2 rounded-lg border border-red-100 dark:border-red-900/30">
                          &quot;{alert.description}&quot;
                        </p>
                      )}

                      {/* Safety Advice Mandatory Notice */}
                      <div className="text-[11px] text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 p-2.5 rounded-xl border border-amber-200 dark:border-amber-900/60 leading-relaxed">
                        ⚠️ <strong>Safety Instructions:</strong> &quot;Stay safe. Avoid the area if necessary and contact the appropriate emergency service or campus authority.&quot;
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-between pt-1 gap-2">
                        <button
                          onClick={() => setSelectedAlertForMap(alert)}
                          className="flex-1 py-1.5 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5"
                        >
                          <MapPin className="w-3.5 h-3.5 text-red-500" />
                          <span>VIEW LOCATION PINPOINT</span>
                        </button>

                        {alert.userId === currentUser.id && isActive && (
                          <button
                            onClick={() => setAlertToCancel(alert)}
                            className="py-1.5 px-3 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold rounded-xl border border-red-200 transition-colors cursor-pointer"
                          >
                            Cancel Alert
                          </button>
                        )}
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      )}

      {/* TAB 2: Emergency Contacts Manager */}
      {activeTab === 'contacts' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
              <div>
                <h2 className="text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Users className="w-5 h-5 text-red-600" />
                  <span>Trusted Emergency Contacts</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Add parents, friends, roommates, and security hotlines. Auto-notification only occurs when enabled by you.
                </p>
              </div>

              <button
                onClick={() => setIsAddingContact(!isAddingContact)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add Emergency Contact</span>
              </button>
            </div>

            {/* Privacy Rule Notice */}
            <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-2xl p-4 text-xs text-blue-800 dark:text-blue-200 flex items-start gap-3">
              <Lock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-sm">Privacy & Authorization Guard</span>
                <p className="mt-0.5 text-blue-700 dark:text-blue-300">
                  Campus Corner strictly protects student privacy. Emergency information is NEVER automatically shared with contacts unless you explicitly check the &quot;Auto-Notify on SOS&quot; permission toggle.
                </p>
              </div>
            </div>

            {/* Add Contact Form Drawer */}
            {isAddingContact && (
              <form onSubmit={handleAddContact} className="bg-slate-50 dark:bg-slate-800/80 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4 animate-fade-in text-xs">
                <div className="font-bold text-slate-800 dark:text-slate-200 text-sm">
                  Add New Emergency Contact
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">Contact Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Rosli Bin Abdullah"
                      value={newContactName}
                      onChange={(e) => setNewContactName(e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl text-xs"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">Relationship *</label>
                    <select
                      value={newContactRelation}
                      onChange={(e) => setNewContactRelation(e.target.value as any)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl text-xs"
                    >
                      <option value="Parent/Guardian">Parent/Guardian</option>
                      <option value="Friend">Friend / Classmate</option>
                      <option value="Roommate">Roommate (Kamsis)</option>
                      <option value="Campus Security">Campus Security</option>
                      <option value="Other">Other Trusted Contact</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g., 019-3829104"
                      value={newContactPhone}
                      onChange={(e) => setNewContactPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl text-xs"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-semibold text-slate-700 dark:text-slate-300">Optional Email</label>
                    <input
                      type="email"
                      placeholder="e.g., parent@gmail.com"
                      value={newContactEmail}
                      onChange={(e) => setNewContactEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-xl text-xs"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="autoNotifyCheckbox"
                    checked={newContactAutoNotify}
                    onChange={(e) => setNewContactAutoNotify(e.target.checked)}
                    className="w-4 h-4 text-red-600 rounded cursor-pointer"
                  />
                  <label htmlFor="autoNotifyCheckbox" className="font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                    Authorize auto-dispatch notification when I press Campus SOS
                  </label>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl cursor-pointer"
                  >
                    Save Contact
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingContact(false)}
                    className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            {/* Contacts List */}
            <div className="space-y-3">
              {(!currentUser.emergencyContacts || currentUser.emergencyContacts.length === 0) ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No emergency contacts saved yet. Tap &quot;Add Emergency Contact&quot; above.
                </div>
              ) : (
                currentUser.emergencyContacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="p-4 bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                          {contact.name}
                        </span>
                        <span className="bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                          {contact.relationship}
                        </span>
                        {contact.isOfficialAuthority && (
                          <span className="bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold px-2 py-0.5 rounded-full">
                            Official Authority
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-3">
                        <span>📞 {contact.phone}</span>
                        {contact.email && <span>✉️ {contact.email}</span>}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => handleToggleAutoNotify(contact.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                          contact.autoNotify
                            ? 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-950/40 dark:text-red-300'
                            : 'bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400'
                        }`}
                      >
                        {contact.autoNotify ? '✅ Auto-Notify Enabled' : '⏸️ Notification Muted'}
                      </button>

                      <a
                        href={`tel:${contact.phone.replace(/[^0-9]/g, '')}`}
                        className="p-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl transition-colors"
                        title="Direct Call"
                      >
                        <PhoneCall className="w-4 h-4" />
                      </a>

                      <button
                        onClick={() => handleRemoveContact(contact.id)}
                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
                        title="Delete Contact"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

          </div>
        </div>
      )}

      {/* TAB 3: Campus Authority Directory */}
      {activeTab === 'authorities' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
            
            <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Shield className="w-5 h-5 text-indigo-600" />
                <span>Official Campus Emergency Authorities</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Politeknik Sultan Azlan Shah (PSAS) official emergency units, security dispatch, and student welfare links.
              </p>
            </div>

            {/* Authority Integration Notice */}
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-4 text-xs text-amber-900 dark:text-amber-200 space-y-1">
              <div className="font-bold flex items-center gap-1.5 text-sm">
                <Info className="w-4 h-4 text-amber-600" />
                <span>Campus Authority API & Dispatch Readiness</span>
              </div>
              <p className="text-amber-800 dark:text-amber-300">
                This prototype includes verified campus authority hotlines and standardized emergency dispatch schemas ready for direct integration with PSAS Auxiliary Police (Unit Keselamatan) and Student Health Clinic systems.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {CAMPUS_AUTHORITY_CONTACTS.map((auth) => (
                <div
                  key={auth.id}
                  className="p-5 bg-slate-50 dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
                        {auth.name}
                      </div>
                      <div className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
                        {auth.department}
                      </div>
                    </div>
                    {auth.isHotline && (
                      <span className="bg-red-100 text-red-700 text-[10px] font-black px-2 py-0.5 rounded-full">
                        24/7 HOTLINE
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    {auth.description}
                  </p>

                  <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl text-xs space-y-1 border border-slate-200/80 dark:border-slate-800">
                    <div className="flex items-center justify-between text-slate-600 dark:text-slate-400">
                      <span>📍 Location:</span>
                      <span className="font-medium text-slate-800 dark:text-slate-200">{auth.location}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-600 dark:text-slate-400">
                      <span>⏱️ Operating:</span>
                      <span className="font-medium text-slate-800 dark:text-slate-200">{auth.availableHours}</span>
                    </div>
                  </div>

                  <div className="pt-1 flex items-center justify-between">
                    <span className="font-mono font-bold text-sm text-indigo-700 dark:text-indigo-400">
                      📞 {auth.phone}
                    </span>

                    <a
                      href={`tel:${auth.phone.replace(/[^0-9]/g, '')}`}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-transform active:scale-95 flex items-center gap-1.5"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>Call Now</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>
      )}

      {/* TAB 4: Safety Protocols & Response Guide */}
      {activeTab === 'safety_guide' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
            
            <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
              <h2 className="text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Info className="w-5 h-5 text-indigo-600" />
                <span>Campus Safety Protocols & Emergency Guides</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Important rules for student safety, first aid steps, and safe behavior during campus incidents.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-amber-50/70 dark:bg-amber-950/30 rounded-2xl border border-amber-200 dark:border-amber-800 space-y-2">
                <div className="font-bold text-sm text-amber-900 dark:text-amber-300 flex items-center gap-2">
                  <Car className="w-4 h-4" />
                  <span>Traffic & Carpark Accident Protocol</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                  <li>Check for injuries immediately and do not move victims with suspected spinal injury.</li>
                  <li>Place hazard signs or alert approaching motorcycles near blind corners.</li>
                  <li>Call PSAS Security Post (05-456 3211) for immediate traffic cordoning.</li>
                </ul>
              </div>

              <div className="p-4 bg-rose-50/70 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-800 space-y-2">
                <div className="font-bold text-sm text-rose-900 dark:text-rose-300 flex items-center gap-2">
                  <HeartPulse className="w-4 h-4" />
                  <span>Medical Emergency & First Aid</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                  <li>In case of fainting/heat stroke, move victim to well-ventilated shade.</li>
                  <li>Notify Student Health Centre (05-456 3290) for emergency stretcher dispatch.</li>
                  <li>For critical life-threatening conditions, dial 999 immediately.</li>
                </ul>
              </div>

              <div className="p-4 bg-orange-50/70 dark:bg-orange-950/30 rounded-2xl border border-orange-200 dark:border-orange-800 space-y-2">
                <div className="font-bold text-sm text-orange-900 dark:text-orange-300 flex items-center gap-2">
                  <Flame className="w-4 h-4" />
                  <span>Fire & Evacuation Protocol</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                  <li>Sound the nearest manual fire alarm break-glass button.</li>
                  <li>Evacuate calmly using designated staircases; NEVER use lifts during fire.</li>
                  <li>Assemble at designated Padang Kawad / Main Field Assembly Point.</li>
                </ul>
              </div>

              <div className="p-4 bg-red-50/70 dark:bg-red-950/30 rounded-2xl border border-red-200 dark:border-red-800 space-y-2">
                <div className="font-bold text-sm text-red-900 dark:text-red-300 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4" />
                  <span>General Campus Safety & Protection</span>
                </div>
                <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                  <li>Avoid walking alone in unlit campus pathways late at night.</li>
                  <li>Never approach aggressive or armed individuals; seek shelter in locked staff rooms.</li>
                  <li>Always trigger Campus SOS early when sensing genuine personal danger.</li>
                </ul>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Cancel Alert Confirmation Modal */}
      {alertToCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center gap-3 text-amber-600">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Cancel Active SOS Alert?
              </h3>
            </div>

            <p className="text-slate-600 dark:text-slate-300">
              Are you sure you want to cancel this emergency alert? Nearby students and contacts will be notified that the situation is safe.
            </p>

            <div className="space-y-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">Reason for Cancellation:</label>
              <select
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-black font-semibold"
              >
                <option value="Accidental trigger / False alarm">Accidental trigger / False alarm</option>
                <option value="Situation resolved safely">Situation resolved safely</option>
                <option value="Campus security already arrived">Campus security already arrived</option>
                <option value="Demo test completed">Demo test completed</option>
              </select>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleConfirmCancelAlert}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl cursor-pointer"
              >
                CONFIRM CANCEL ALERT
              </button>
              <button
                type="button"
                onClick={() => setAlertToCancel(null)}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer"
              >
                Keep Alert Active
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Map Pinpoint Modal */}
      {selectedAlertForMap && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  Incident Location & Campus Map
                </h3>
              </div>
              <button
                onClick={() => setSelectedAlertForMap(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Simulated Campus Interactive Map Visual */}
            <div className="h-52 bg-gradient-to-br from-slate-800 to-indigo-950 rounded-2xl relative overflow-hidden border border-slate-700 flex items-center justify-center text-white">
              {/* Campus Grid lines */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:24px_24px]" />

              <div className="relative z-10 flex flex-col items-center gap-2 text-center p-4">
                <div className="w-12 h-12 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-600/50 animate-bounce">
                  <MapPin className="w-6 h-6" />
                </div>
                <div className="font-extrabold text-sm text-white">
                  {selectedAlertForMap.locationName}
                </div>
                <div className="text-[11px] text-red-200">
                  Category: {selectedAlertForMap.category} • Reported {selectedAlertForMap.timestamp}
                </div>
                {selectedAlertForMap.coordinates && (
                  <div className="text-[10px] font-mono text-slate-300 bg-black/40 px-2 py-0.5 rounded-full">
                    GPS: {selectedAlertForMap.coordinates.latitude.toFixed(4)}° N, {selectedAlertForMap.coordinates.longitude.toFixed(4)}° E
                  </div>
                )}
              </div>
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-300">
              ⚠️ <strong>Safe Responder Note:</strong> &quot;Stay safe. Avoid the area if necessary and contact the appropriate emergency service or campus authority.&quot;
            </div>

            <button
              onClick={() => setSelectedAlertForMap(null)}
              className="w-full py-2.5 bg-slate-900 dark:bg-slate-800 text-white font-bold rounded-xl cursor-pointer"
            >
              Close Map
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
