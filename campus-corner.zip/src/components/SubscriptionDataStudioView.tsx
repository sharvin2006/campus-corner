import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Crown,
  Download,
  Database,
  ExternalLink,
  Layers,
  Sparkles,
  TrendingUp,
  Users,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
  Search,
  Filter,
  ArrowUpRight,
  RefreshCw,
  FileSpreadsheet,
  PieChart,
  HelpCircle,
  Code,
  Zap,
  Building,
  CreditCard
} from 'lucide-react';
import { 
  User, 
  SubscriptionPlanConfig, 
  UserSubscriptionRecord, 
  SubscriptionAnalyticsMetrics, 
  DataStudioFieldDefinition,
  SubscriptionTier
} from '../types';
import { 
  SUBSCRIPTION_PLANS, 
  INITIAL_SUBSCRIPTIONS, 
  SUBSCRIPTION_METRICS, 
  DATA_STUDIO_FIELDS 
} from '../data/mockData';

interface SubscriptionDataStudioViewProps {
  currentUser: User;
  onOpenUpgradeModal: (defaultTier?: SubscriptionTier) => void;
}

export const SubscriptionDataStudioView: React.FC<SubscriptionDataStudioViewProps> = ({
  currentUser,
  onOpenUpgradeModal,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'plans' | 'analytics' | 'datastudio' | 'subscribers'>('plans');
  const [subscriptions, setSubscriptions] = useState<UserSubscriptionRecord[]>(INITIAL_SUBSCRIPTIONS);
  const [metrics, setMetrics] = useState<SubscriptionAnalyticsMetrics>(SUBSCRIPTION_METRICS);
  const [fields] = useState<DataStudioFieldDefinition[]>(DATA_STUDIO_FIELDS);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedFormula, setCopiedFormula] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);

  // Fetch live metrics & subscriptions from backend API
  const refreshData = async () => {
    setIsLoading(true);
    try {
      const [resMetrics, resSubs] = await Promise.all([
        fetch('/api/subscriptions/metrics').then(r => r.json()),
        fetch('/api/subscriptions/all').then(r => r.json())
      ]);

      if (resMetrics.success && resMetrics.metrics) {
        setMetrics(resMetrics.metrics);
      }
      if (resSubs.success && resSubs.subscriptions) {
        setSubscriptions(resSubs.subscriptions);
      }
    } catch (err) {
      console.warn('Using local subscription store:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleCopyEndpoint = () => {
    const fullUrl = `${window.location.origin}/api/subscriptions/export/data-studio.csv`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const handleCopyFormula = (id: string, formula: string) => {
    navigator.clipboard.writeText(formula);
    setCopiedFormula(id);
    setTimeout(() => setCopiedFormula(null), 2500);
  };

  // Filter subscribers table
  const filteredSubscribers = subscriptions.filter(sub => {
    const matchesSearch = 
      sub.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.studentMatric.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.course.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTier = tierFilter === 'all' || sub.tier === tierFilter;
    return matchesSearch && matchesTier;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      
      {/* Top Banner: AI Google Data Studio Strategic Integration */}
      <div className="relative rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 shadow-xl border border-indigo-500/20 overflow-hidden mb-8">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-indigo-500/10 to-transparent pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
                <Crown className="w-3.5 h-3.5 fill-slate-950" />
                Free • Premium • Pro Plan Architecture
              </span>
              <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                <BarChart3 className="w-3 h-3 text-indigo-300" />
                Google Data Studio Ready
              </span>
              <span className="text-xs text-indigo-200">
                Politeknik Sultan Azlan Shah (PSAS) Commerce FYP
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white">
              Subscription Tiers & Looker Studio Analytics
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              Designed specifically for student entrepreneurs and accommodation hosts. Easily compare subscription models, manage user tier quotas, and export real-time transactional dimensions & metrics directly into <strong>Google Data Studio (Looker Studio)</strong> for FYP data visualization reports.
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5 shrink-0">
            <a
              href="/api/subscriptions/export/data-studio.csv"
              download="campus_corner_subscriptions_data_studio.csv"
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Export Looker Studio CSV</span>
            </a>

            <button
              onClick={() => onOpenUpgradeModal()}
              className="flex items-center gap-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black px-4 py-2.5 rounded-xl shadow-md transition-all cursor-pointer hover:scale-105 active:scale-95"
            >
              <Crown className="w-4 h-4 fill-slate-950" />
              <span>Upgrade My Plan</span>
            </button>
          </div>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="flex items-center gap-2 mt-8 pt-6 border-t border-white/10 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveSubTab('plans')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeSubTab === 'plans'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Crown className="w-4 h-4 text-amber-500" />
            <span>1. Free, Premium & Pro Plans</span>
          </button>

          <button
            onClick={() => setActiveSubTab('analytics')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeSubTab === 'analytics'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            <span>2. Financial & Revenue Metrics (MRR)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('datastudio')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeSubTab === 'datastudio'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>3. Google Data Studio Integration & Formulas</span>
          </button>

          <button
            onClick={() => setActiveSubTab('subscribers')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeSubTab === 'subscribers'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
          >
            <Users className="w-4 h-4 text-indigo-400" />
            <span>4. Subscriber Cohort Database ({subscriptions.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: SUBSCRIPTION PLANS MATRIX */}
      {activeSubTab === 'plans' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          {/* Current User Active Plan Header */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-indigo-600/20">
                <Crown className="w-6 h-6 text-amber-300" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Logged In Student</span>
                  <span className="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-200">
                    {currentUser.studentId || 'Profile Not Set'}
                  </span>
                </div>
                <div className="text-base font-extrabold text-slate-900">
                  {currentUser.name || 'Student (Blank Profile)'} • Active Plan: <span className="text-indigo-600 uppercase">{currentUser.subscriptionTier || 'free'}</span>
                </div>
                <div className="text-xs text-slate-500">
                  {currentUser.subscriptionPlanName || 'Free Student Plan'} • {currentUser.subscriptionExpiresAt ? `Valid through ${currentUser.subscriptionExpiresAt}` : 'Open Plan'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => onOpenUpgradeModal('pro')}
                className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Zap className="w-4 h-4" />
                <span>Switch or Upgrade Plan</span>
              </button>
            </div>
          </div>

          {/* Detailed 3 Tier Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {SUBSCRIPTION_PLANS.map((plan) => {
              const isCurrent = currentUser.subscriptionTier === plan.tier;
              return (
                <div
                  key={plan.tier}
                  className={`rounded-3xl p-6 sm:p-7 border bg-white flex flex-col justify-between transition-all ${
                    plan.recommended
                      ? 'border-indigo-600 ring-2 ring-indigo-600/20 shadow-xl relative'
                      : 'border-slate-200/80 shadow-sm hover:shadow-md'
                  }`}
                >
                  {plan.recommended && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-[10px] font-black uppercase tracking-wider px-3.5 py-1 rounded-full shadow-md flex items-center gap-1">
                      <Crown className="w-3.5 h-3.5 fill-white" />
                      Most Popular at PSAS
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-md ${
                        plan.tier === 'free' ? 'bg-slate-100 text-slate-700' :
                        plan.tier === 'premium' ? 'bg-indigo-100 text-indigo-800' :
                        'bg-purple-100 text-purple-800'
                      }`}>
                        {plan.badgeLabel}
                      </span>
                      {isCurrent && (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Current Active
                        </span>
                      )}
                    </div>

                    <h3 className="text-2xl font-black text-slate-900">
                      {plan.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 min-h-[34px]">
                      {plan.tagline}
                    </p>

                    {/* Price Block */}
                    <div className="mt-5 mb-5 pb-5 border-b border-slate-100">
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-4xl font-black text-slate-900 tracking-tight">
                          RM {plan.semesterPriceRM > 0 ? plan.semesterPriceRM.toFixed(2) : '0.00'}
                        </span>
                        <span className="text-xs text-slate-500 font-medium">
                          /semester pass
                        </span>
                      </div>
                      {plan.monthlyPriceRM > 0 ? (
                        <div className="text-xs font-semibold text-emerald-600 mt-1 flex items-center gap-1">
                          <span>Or RM {plan.monthlyPriceRM.toFixed(2)}/monthly</span>
                          <span className="text-[10px] bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded">
                            SAVE 38% on Semester
                          </span>
                        </div>
                      ) : (
                        <div className="text-xs font-medium text-slate-400 mt-1">
                          Always 100% free for all enrolled students
                        </div>
                      )}
                    </div>

                    {/* Quota Highlights Card */}
                    <div className="bg-slate-50/90 rounded-2xl p-4 border border-slate-100 space-y-2 text-xs mb-6">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Marketplace Listings:</span>
                        <span className="font-extrabold text-slate-900">
                          {plan.maxMarketplaceListings === -1 ? 'Unlimited' : `${plan.maxMarketplaceListings} items`}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Hostel / Room Rentals:</span>
                        <span className="font-extrabold text-slate-900">
                          {plan.maxRentalListings === -1 ? 'Unlimited' : `${plan.maxRentalListings} listings`}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Daily AI Valuations:</span>
                        <span className="font-extrabold text-slate-900">
                          {plan.dailyAIEvaluations === -1 ? 'Unlimited' : `${plan.dailyAIEvaluations}/day`}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Search Boost Multiplier:</span>
                        <span className="font-extrabold text-indigo-700">
                          {plan.searchBoostMultiplier}x Priority
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Analytics Level:</span>
                        <span className="font-extrabold text-slate-900">
                          {plan.analyticsLevel}
                        </span>
                      </div>
                    </div>

                    {/* Features List */}
                    <div className="space-y-2.5 mb-6">
                      {plan.features.map((feat, idx) => (
                        <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-600">
                          <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => onOpenUpgradeModal(plan.tier)}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer ${
                      isCurrent
                        ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        : plan.recommended
                        ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/25'
                        : 'bg-slate-900 hover:bg-indigo-600 text-white'
                    }`}
                  >
                    <span>{isCurrent ? 'Current Plan (Renew)' : `Choose ${plan.name}`}</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Student Value Proposition Matrix */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <h3 className="text-lg font-black text-slate-900 mb-2">
              Why Campus Corner Tiered Subscriptions Work at PSAS
            </h3>
            <p className="text-xs text-slate-500 mb-6 max-w-3xl">
              Our model provides equitable access: casual students sell textbook leftovers for free, while active commerce vendors and room rental hosts invest RM 3.00/mo to gain 2.5x higher conversions and dedicated verification badges.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100">
                <div className="font-bold text-indigo-900 mb-1 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  Trust & Safety Badge
                </div>
                <div className="text-slate-600">
                  Subscribed sellers complete institutional matric validation, granting buyers higher confidence and cutting no-shows by 78%.
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-100">
                <div className="font-bold text-amber-900 mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  Gemini AI Pricing Assistance
                </div>
                <div className="text-slate-600">
                  Unlimited AI price appraisals help students price calculators, notes, and hostel rooms accurately to clear inventory within 48 hours.
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100">
                <div className="font-bold text-emerald-900 mb-1 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                  Commerce FYP Portfolio Ready
                </div>
                <div className="text-slate-600">
                  Students operating FYP mini-businesses get clean CSV transaction records ready to import into Google Looker Studio for presentation slides.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FINANCIAL & REVENUE METRICS */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          
          {/* Top Scorecard Stat Blocks */}
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Monthly MRR</div>
              <div className="text-2xl font-black text-slate-900 mt-1">
                RM {metrics.totalMRR_RM.toFixed(2)}
              </div>
              <div className="text-[11px] text-emerald-600 font-semibold mt-1">
                Normalized 30-Day
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Annual ARR</div>
              <div className="text-2xl font-black text-indigo-600 mt-1">
                RM {metrics.totalARR_RM.toFixed(2)}
              </div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Run-rate projection
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Avg ARPU</div>
              <div className="text-2xl font-black text-slate-900 mt-1">
                RM {metrics.arpuRM.toFixed(2)}
              </div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Per paying subscriber
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Active Subs</div>
              <div className="text-2xl font-black text-slate-900 mt-1">
                {metrics.totalActiveSubscribers}
              </div>
              <div className="text-[11px] text-emerald-600 font-semibold mt-1">
                {metrics.premiumCount + metrics.proCount} paying ({metrics.freeCount} free)
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Paid Conversion</div>
              <div className="text-2xl font-black text-indigo-700 mt-1">
                {metrics.conversionRatePercent}%
              </div>
              <div className="text-[11px] text-emerald-600 font-semibold mt-1">
                Free to Paid ratio
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Semester Renewal</div>
              <div className="text-2xl font-black text-emerald-600 mt-1">
                {metrics.semesterRenewalRatePercent}%
              </div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Cohort retention rate
              </div>
            </div>
          </div>

          {/* 2-Column Visual Charts & Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Department Revenue Breakdown */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Subscription Revenue by Polytechnic Department
                  </h3>
                  <p className="text-xs text-slate-500">
                    Contribution of JP, JTMK, JKM, JKE, and JKA student cohorts
                  </p>
                </div>
                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
                  5 Faculties
                </span>
              </div>

              <div className="space-y-4 mt-6">
                {metrics.departmentRevenue.map((dept, idx) => {
                  const percent = Math.round((dept.revenueRM / metrics.totalMRR_RM) * 100) || 0;
                  return (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-800">{dept.department}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500">{dept.subscribersCount} subscribers</span>
                          <span className="font-black text-slate-900">RM {dept.revenueRM.toFixed(2)} ({percent}%)</span>
                        </div>
                      </div>
                      <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            idx === 0 ? 'bg-indigo-600' :
                            idx === 1 ? 'bg-purple-600' :
                            idx === 2 ? 'bg-amber-500' :
                            idx === 3 ? 'bg-emerald-500' :
                            'bg-slate-500'
                          }`}
                          style={{ width: `${Math.min(percent, 100)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Monthly Growth Trend (April - September 2026) */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">
                    Semester Monthly MRR Trajectory
                  </h3>
                  <p className="text-xs text-slate-500">
                    Revenue growth from launch to current semester peak
                  </p>
                </div>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                  +242% Growth
                </span>
              </div>

              <div className="space-y-4 mt-6">
                {metrics.monthlyTrends.map((trend, idx) => {
                  const maxMrr = 400;
                  const barWidth = Math.round((trend.mrrRM / maxMrr) * 100);
                  return (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-slate-800">{trend.month}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500">{trend.subscribers} students</span>
                          <span className="font-black text-indigo-700">RM {trend.mrrRM.toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full transition-all"
                          style={{ width: `${barWidth}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GOOGLE DATA STUDIO (LOOKER STUDIO) INTEGRATION */}
      {activeSubTab === 'datastudio' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          
          {/* Quick Connection Card */}
          <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 rounded-3xl p-6 sm:p-8 text-white border border-indigo-500/20 shadow-xl">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center gap-1.5 bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-[10px] font-bold px-2.5 py-1 rounded-full">
                  <Database className="w-3.5 h-3.5" />
                  Live Looker Studio Data Connector Endpoint
                </div>
                <h3 className="text-xl sm:text-2xl font-black">
                  Direct Data Connector for Google Looker Studio
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Use this standardized endpoint to sync Campus Corner subscription data directly into Google Data Studio. Compatible with Looker Studio CSV Uploader, Google Sheets Connector, and Webhook collectors.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
                <button
                  onClick={handleCopyEndpoint}
                  className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-4 py-3 rounded-xl border border-white/20 transition-all cursor-pointer"
                >
                  {copiedUrl ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>URL Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy CSV Webhook URL</span>
                    </>
                  )}
                </button>

                <a
                  href="/api/subscriptions/export/data-studio.csv"
                  download="campus_corner_subscriptions_data_studio.csv"
                  className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black px-5 py-3 rounded-xl shadow-lg transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4 text-slate-950" />
                  <span>Download Formatted CSV</span>
                </a>
              </div>
            </div>

            {/* URL Display */}
            <div className="mt-5 bg-slate-950/70 rounded-xl p-3 border border-white/10 flex items-center justify-between gap-2 overflow-x-auto text-xs font-mono text-indigo-300">
              <span className="truncate">{window.location.origin}/api/subscriptions/export/data-studio.csv</span>
              <span className="bg-indigo-600 text-white text-[9px] font-sans font-bold px-2 py-0.5 rounded uppercase shrink-0">
                RFC 4180 Format
              </span>
            </div>
          </div>

          {/* 4-Step Guide to Build the Dashboard in Looker Studio */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <h3 className="text-xl font-black text-slate-900 mb-2">
              How to Build Your FYP Dashboard in Google Looker Studio
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Follow these simple 4 steps to create professional presentation charts for your Commerce FYP:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70 flex flex-col justify-between">
                <div>
                  <span className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center mb-3">
                    1
                  </span>
                  <div className="text-sm font-bold text-slate-900 mb-1">
                    Connect Data Source
                  </div>
                  <div className="text-xs text-slate-500 leading-relaxed">
                    Open <strong>lookerstudio.google.com</strong>, click <em>Create → Data Source</em>, and select <strong>File Upload</strong> (upload CSV) or <strong>Google Sheets</strong>.
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200/70 text-[11px] font-bold text-indigo-600">
                  Auto-detects UTF-8 headers
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70 flex flex-col justify-between">
                <div>
                  <span className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center mb-3">
                    2
                  </span>
                  <div className="text-sm font-bold text-slate-900 mb-1">
                    Map Dimensions & Metrics
                  </div>
                  <div className="text-xs text-slate-500 leading-relaxed">
                    Looker Studio will automatically split the 11 dimensions (Matric, Department, Tier) and 6 metrics (Price Paid, MRR, AI Valuations).
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200/70 text-[11px] font-bold text-indigo-600">
                  Zero manual typing required
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70 flex flex-col justify-between">
                <div>
                  <span className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center mb-3">
                    3
                  </span>
                  <div className="text-sm font-bold text-slate-900 mb-1">
                    Add Charts & Scorecards
                  </div>
                  <div className="text-xs text-slate-500 leading-relaxed">
                    Add Scorecards for <strong>MRR</strong> and <strong>ARR</strong>, a Donut Chart for <strong>Tier Distribution</strong>, and Bar Charts for <strong>Department Revenue</strong>.
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200/70 text-[11px] font-bold text-indigo-600">
                  Pre-configured layout below
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/70 flex flex-col justify-between">
                <div>
                  <span className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center mb-3">
                    4
                  </span>
                  <div className="text-sm font-bold text-slate-900 mb-1">
                    Share & Present Report
                  </div>
                  <div className="text-xs text-slate-500 leading-relaxed">
                    Click <strong>Share</strong> to generate a live embed link or export high-resolution PDF slides for your Polytechnic lecturers and reviewers.
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-200/70 text-[11px] font-bold text-indigo-600">
                  Ready for FYP viva evaluation
                </div>
              </div>
            </div>
          </div>

          {/* Google Data Studio Calculated Field Formulas Library */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <h3 className="text-xl font-black text-slate-900 mb-2">
              Ready-to-Use Looker Studio Calculated Fields
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Copy and paste these custom formulas directly into the <em>Add Field</em> dialog in Looker Studio:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-slate-900">Student ARPU (Average Revenue)</span>
                    <span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2 py-0.5 rounded">Formula</span>
                  </div>
                  <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl text-xs font-mono overflow-x-auto">
                    SUM(Price_Paid_RM) / COUNT_DISTINCT(Student_Matric_ID)
                  </pre>
                  <p className="text-[11px] text-slate-500 mt-2">
                    Computes revenue contribution per unique Polytechnic student.
                  </p>
                </div>
                <button
                  onClick={() => handleCopyFormula('f1', 'SUM(Price_Paid_RM) / COUNT_DISTINCT(Student_Matric_ID)')}
                  className="mt-3 text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  {copiedFormula === 'f1' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedFormula === 'f1' ? 'Copied!' : 'Copy Formula'}</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-slate-900">Paid Conversion Rate (%)</span>
                    <span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2 py-0.5 rounded">Formula</span>
                  </div>
                  <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl text-xs font-mono overflow-x-auto">
                    SUM(CASE WHEN Subscription_Tier != 'FREE' THEN 1 ELSE 0 END) / COUNT(Student_Matric_ID) * 100
                  </pre>
                  <p className="text-[11px] text-slate-500 mt-2">
                    Calculates the percentage of registered students upgraded to Premium or Pro.
                  </p>
                </div>
                <button
                  onClick={() => handleCopyFormula('f2', "SUM(CASE WHEN Subscription_Tier != 'FREE' THEN 1 ELSE 0 END) / COUNT(Student_Matric_ID) * 100")}
                  className="mt-3 text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  {copiedFormula === 'f2' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedFormula === 'f2' ? 'Copied!' : 'Copy Formula'}</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-slate-900">Listing Velocity (Listings per RM)</span>
                    <span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2 py-0.5 rounded">Formula</span>
                  </div>
                  <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl text-xs font-mono overflow-x-auto">
                    SUM(Active_Marketplace_Listings + Active_Rental_Listings) / SUM(Normalized_MRR_RM)
                  </pre>
                  <p className="text-[11px] text-slate-500 mt-2">
                    Measures listing productivity generated per Ringgit of platform revenue.
                  </p>
                </div>
                <button
                  onClick={() => handleCopyFormula('f3', 'SUM(Active_Marketplace_Listings + Active_Rental_Listings) / SUM(Normalized_MRR_RM)')}
                  className="mt-3 text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  {copiedFormula === 'f3' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedFormula === 'f3' ? 'Copied!' : 'Copy Formula'}</span>
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-slate-900">Annualized Run-rate (ARR)</span>
                    <span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2 py-0.5 rounded">Formula</span>
                  </div>
                  <pre className="bg-slate-900 text-emerald-400 p-3 rounded-xl text-xs font-mono overflow-x-auto">
                    SUM(Normalized_MRR_RM) * 12
                  </pre>
                  <p className="text-[11px] text-slate-500 mt-2">
                    Standard SaaS metric calculating annual revenue projected from active semester passes.
                  </p>
                </div>
                <button
                  onClick={() => handleCopyFormula('f4', 'SUM(Normalized_MRR_RM) * 12')}
                  className="mt-3 text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  {copiedFormula === 'f4' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedFormula === 'f4' ? 'Copied!' : 'Copy Formula'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Schema Dictionary */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-black text-slate-900">
                  Data Studio Field Schema Dictionary ({fields.length} Fields)
                </h3>
                <p className="text-xs text-slate-500">
                  Comprehensive breakdown of dimensions, metrics, types, and aggregation methods
                </p>
              </div>
              <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold px-3 py-1 rounded-full">
                100% Data Studio Validated
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="py-3 px-3">Field ID</th>
                    <th className="py-3 px-3">Field Name</th>
                    <th className="py-3 px-3">Type</th>
                    <th className="py-3 px-3">Data Type</th>
                    <th className="py-3 px-3">Aggregation</th>
                    <th className="py-3 px-3">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {fields.map((f) => (
                    <tr key={f.fieldId} className="hover:bg-slate-50/70">
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">{f.fieldId}</td>
                      <td className="py-3 px-3 font-bold text-indigo-600">{f.fieldName}</td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase ${
                          f.type === 'DIMENSION' ? 'bg-indigo-50 text-indigo-700' : 'bg-emerald-50 text-emerald-700'
                        }`}>
                          {f.type}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-600">{f.dataType}</td>
                      <td className="py-3 px-3 font-semibold text-slate-500">{f.aggregation || 'None'}</td>
                      <td className="py-3 px-3 text-slate-600 max-w-xs">{f.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SUBSCRIBER COHORT DATABASE */}
      {activeSubTab === 'subscribers' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Controls Bar */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search by student name, matric, or department..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-100 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-xs text-slate-500 font-medium">Filter Tier:</span>
              <div className="flex gap-1 bg-slate-100 p-1 rounded-xl">
                {['all', 'free', 'premium', 'pro'].map((tier) => (
                  <button
                    key={tier}
                    onClick={() => setTierFilter(tier)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold uppercase transition-all cursor-pointer ${
                      tierFilter === tier
                        ? 'bg-white text-slate-900 shadow-sm font-black'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {tier}
                  </button>
                ))}
              </div>

              <button
                onClick={refreshData}
                disabled={isLoading}
                className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
                title="Refresh database"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* Database Table */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="py-3 px-3">Student Subscriber</th>
                    <th className="py-3 px-3">Department & Course</th>
                    <th className="py-3 px-3">Tier & Plan</th>
                    <th className="py-3 px-3">Cycle & Paid</th>
                    <th className="py-3 px-3">MRR Contrib</th>
                    <th className="py-3 px-3">Listings Active</th>
                    <th className="py-3 px-3">AI Valuations</th>
                    <th className="py-3 px-3">Expiry</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredSubscribers.map((sub) => (
                    <tr key={sub.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{sub.userName}</div>
                        <div className="font-mono text-[11px] text-slate-500">{sub.studentMatric}</div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-800">{sub.course}</div>
                        <div className="text-[10px] text-slate-500">{sub.department} • Sem {sub.semester}</div>
                      </td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase ${
                          sub.tier === 'free' ? 'bg-slate-100 text-slate-700' :
                          sub.tier === 'premium' ? 'bg-indigo-100 text-indigo-800' :
                          'bg-purple-100 text-purple-800'
                        }`}>
                          {sub.tier}
                        </span>
                        <div className="text-[10px] text-slate-500 mt-0.5">{sub.planName}</div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">RM {sub.pricePaidRM.toFixed(2)}</div>
                        <div className="text-[10px] text-slate-500 capitalize">{sub.billingCycle} • {sub.paymentMethod}</div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-black text-indigo-700">RM {sub.normalizedMonthlyMRR_RM.toFixed(2)}/mo</div>
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-700">
                        {sub.activeMarketplaceListings} items • {sub.activeRentalListings} rentals
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          {sub.aiValuationsUsed} used
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <div className="text-slate-800 font-medium">{sub.endDate}</div>
                        <div className="text-[10px] text-emerald-600 font-semibold">{sub.daysRemaining} days left</div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {filteredSubscribers.length === 0 && (
              <div className="text-center py-12 text-slate-400 text-sm">
                No subscriber records match your filter criteria.
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
