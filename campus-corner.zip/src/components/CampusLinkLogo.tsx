import React from 'react';

interface CampusLinkLogoProps {
  variant?: 'full' | 'horizontal' | 'emblem' | 'compact' | 'portraitCard' | 'landscapeCard';
  size?: number | string;
  className?: string;
  showSubtitle?: boolean;
  estYear?: string | number;
}

/**
 * Official vector brand logo for Campus Link Technologies Sdn. Bhd.
 * Accurately rendered from Picture11.png and Screenshot 2026-09-22 101423.png.
 */
export const CampusLinkLogo: React.FC<CampusLinkLogoProps> = ({
  variant = 'full',
  size,
  className = '',
  showSubtitle = true,
  estYear = '2026',
}) => {
  // 1. EMBLEM ONLY (C + L + PIXELS + LINK)
  if (variant === 'emblem') {
    return (
      <svg
        viewBox="0 0 380 270"
        className={className}
        style={{ width: size || '100%', height: size || 'auto' }}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="clt-c-grad-emb" x1="15%" y1="5%" x2="85%" y2="95%">
            <stop offset="0%" stopColor="#2a80f6" />
            <stop offset="35%" stopColor="#1564de" />
            <stop offset="70%" stopColor="#0b42ad" />
            <stop offset="100%" stopColor="#072674" />
          </linearGradient>

          <linearGradient id="clt-link-grad-emb" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#007df0" />
            <stop offset="50%" stopColor="#009eff" />
            <stop offset="100%" stopColor="#00d5ff" />
          </linearGradient>

          <linearGradient id="clt-l-stem-emb" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#122749" />
            <stop offset="100%" stopColor="#09172c" />
          </linearGradient>

          <linearGradient id="clt-link-rim-emb" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#00a8ff" stopOpacity="0" />
          </linearGradient>

          <filter id="clt-emb-shadow" x="-15%" y="-15%" width="130%" height="130%">
            <feDropShadow dx="0" dy="5" stdDeviation="8" floodColor="#072c78" floodOpacity="0.18" />
          </filter>
        </defs>

        <g filter="url(#clt-emb-shadow)">
          {/* Outer C Arc */}
          <path
            d="M 276, 76 
               C 258, 55 234, 43 208, 43 
               C 155, 43 112, 86 112, 140 
               C 112, 194 155, 237 208, 237 
               C 238, 237 263, 223 280, 202
               L 257, 176
               C 245, 192 228, 201 208, 201
               C 175, 201 148, 174 148, 140
               C 148, 106 175, 79 208, 79
               C 226, 79 242, 87 253, 101
               Z"
            fill="url(#clt-c-grad-emb)"
          />
          {/* Outer C Terminal Bulbs */}
          <circle cx="265" cy="88" r="18" fill="url(#clt-c-grad-emb)" />
          <circle cx="268" cy="189" r="18" fill="url(#clt-c-grad-emb)" />

          {/* Inner L Vertical Stem */}
          <path
            d="M 186, 70 L 220, 70 L 220, 184 C 220, 196 210, 206 198, 206 L 186, 206 Z"
            fill="url(#clt-l-stem-emb)"
          />

          {/* L Connection Bridge curving to Link */}
          <path
            d="M 214, 164 
               C 214, 190 234, 206 256, 206 
               L 280, 206 
               C 288, 206 294, 200 294, 192 
               L 294, 180 
               C 294, 172 288, 166 280, 166 
               L 260, 166 
               C 240, 166 226, 160 214, 164 Z"
            fill="url(#clt-link-grad-emb)"
          />

          {/* Digital Pixel Matrix (Top Right Quadrant) */}
          <g id="clt-pixels">
            <rect x="302" y="52" width="13.5" height="13.5" rx="2" fill="#0096f2" />
            <rect x="320" y="52" width="13.5" height="13.5" rx="2" fill="#0b58cc" />
            <rect x="338" y="52" width="8.5" height="8.5" rx="1.5" fill="#0080ea" />
            <rect x="285" y="70" width="10.5" height="10.5" rx="1.8" fill="#00b4ff" />
            <rect x="302" y="70" width="16.5" height="16.5" rx="2.5" fill="#0944ab" />
            <rect x="323" y="70" width="13.5" height="13.5" rx="2" fill="#0096f2" />
            <rect x="272" y="91" width="7.5" height="7.5" rx="1.2" fill="#0072de" />
            <rect x="285" y="86" width="13.5" height="13.5" rx="2" fill="#07348c" />
            <rect x="305" y="92" width="9.5" height="9.5" rx="1.5" fill="#00c4ff" />
          </g>

          {/* Chain Link Oval Loop */}
          <g transform="translate(252, 128)">
            <rect x="0" y="0" width="116" height="50" rx="25" fill="url(#clt-link-grad-emb)" />
            <rect x="15" y="12" width="86" height="26" rx="13" fill="#ffffff" />
            <path
              d="M 24, 4 L 92, 4 C 104, 4 110, 10 110, 17 C 110, 10 102, 2 90, 2 L 26, 2 C 14, 2 6, 10 6, 17 C 6, 10 12, 4 24, 4 Z"
              fill="url(#clt-link-rim-emb)"
            />
            <circle cx="28" cy="25" r="8" fill="#0066d6" />
            <circle cx="28" cy="25" r="4.5" fill="#00e5ff" />
          </g>
        </g>
      </svg>
    );
  }

  // 2. HORIZONTAL LOCKUP (Emblem on Left, Typography on Right)
  if (variant === 'horizontal') {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        <div className="shrink-0" style={{ width: size || '44px', height: size || '44px' }}>
          <CampusLinkLogo variant="emblem" />
        </div>
        <div className="flex flex-col justify-center">
          <div className="flex items-center tracking-tight font-black leading-none text-sm sm:text-base">
            <span className="text-[#0c1e38] dark:text-slate-100 mr-1.5 flex items-center">
              C<span className="relative">A<span className="absolute left-[3px] top-[4px] w-0 h-0 border-l-[2px] border-l-transparent border-r-[2px] border-r-transparent border-b-[4px] border-b-[#0096f2]" /></span>MPUS
            </span>
            <span className="text-[#0080f0]">LINK</span>
          </div>
          {showSubtitle && (
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="h-[1px] w-3 bg-[#0080f0]" />
              <span className="text-[9px] font-extrabold tracking-widest text-[#0c1e38] dark:text-slate-300 uppercase">
                TECHNOLOGIES
              </span>
              <span className="h-[1px] w-3 bg-[#0080f0]" />
              <span className="text-[8px] font-bold text-[#0080f0] tracking-wider ml-0.5">
                SDN. BHD
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  // 3. COMPACT BADGE VARIANT
  if (variant === 'compact') {
    return (
      <div className={`inline-flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 shadow-2xs ${className}`}>
        <div className="w-5 h-5 shrink-0">
          <CampusLinkLogo variant="emblem" />
        </div>
        <div className="text-[11px] font-extrabold leading-tight">
          <span className="text-[#0c1e38] dark:text-white">CAMPUS </span>
          <span className="text-[#0080f0]">LINK</span>
        </div>
        <span className="text-[8px] font-bold bg-blue-50 text-[#0080f0] px-1.5 py-0.5 rounded">
          SDN BHD
        </span>
      </div>
    );
  }

  // 4. PORTRAIT CARD VARIANT (Mobile Portrait layout matching Screenshot 2026-09-22 101423.png)
  if (variant === 'portraitCard') {
    return (
      <div className={`flex flex-col items-center justify-between p-6 sm:p-8 bg-white dark:bg-slate-900 rounded-3xl border border-blue-100 dark:border-slate-800 shadow-xl text-center select-none ${className}`}>
        {/* Emblem */}
        <div className="w-36 h-28 sm:w-42 sm:h-32 flex items-center justify-center">
          <CampusLinkLogo variant="emblem" />
        </div>

        {/* Brand Lockup */}
        <div className="flex flex-col items-center mt-2 w-full">
          {/* — TECHNOLOGIES — */}
          <div className="flex items-center justify-center gap-2.5 w-full max-w-[210px] my-1">
            <div className="h-[1.5px] flex-1 bg-gradient-to-r from-transparent to-[#0080f0]" />
            <span className="text-[10.5px] font-extrabold text-[#0c1e38] dark:text-slate-200 tracking-[0.26em] uppercase">
              TECHNOLOGIES
            </span>
            <div className="h-[1.5px] flex-1 bg-gradient-to-l from-transparent to-[#0080f0]" />
          </div>

          {/* CAMPUS LINK */}
          <div className="flex items-center justify-center text-2xl sm:text-[26px] font-black tracking-tight leading-none mt-1">
            <span className="text-[#0c1e38] dark:text-slate-100">CAMPUS</span>
            <span className="text-[#0080f0] ml-2">LINK</span>
          </div>

          {/* — EST. 2026 — */}
          <div className="flex items-center justify-center gap-2.5 w-full max-w-[140px] mt-2">
            <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-[#0080f0]/50" />
            <span className="text-[9.5px] font-bold text-[#0080f0] tracking-[0.2em] uppercase">
              EST. {estYear || 2026}
            </span>
            <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-[#0080f0]/50" />
          </div>
        </div>

        {/* Slogan with Capital 'S' in Students and 'S' in Success */}
        <div className="mt-5 text-center leading-tight">
          <div className="text-lg sm:text-xl font-black tracking-tight">
            <span className="text-[#0080f0]">Made</span>{' '}
            <span className="text-[#0c1e38] dark:text-slate-100">for Students</span>
          </div>
          <div className="text-lg sm:text-xl font-black tracking-tight mt-1">
            <span className="text-[#0080f0]">Built</span>{' '}
            <span className="text-[#0c1e38] dark:text-slate-100">for Success</span>
          </div>
        </div>
      </div>
    );
  }

  // 5. LANDSCAPE CARD VARIANT (Laptop / Desktop Widescreen Layout)
  if (variant === 'landscapeCard') {
    return (
      <div className={`w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl border border-blue-100 dark:border-slate-800 shadow-xl p-8 flex flex-row items-center justify-between gap-8 select-none ${className}`}>
        {/* Left: Large Emblem */}
        <div className="w-1/2 flex flex-col items-center justify-center border-r border-slate-100 dark:border-slate-800 pr-6">
          <div className="w-56 h-44 flex items-center justify-center">
            <CampusLinkLogo variant="emblem" size={210} />
          </div>
          <div className="text-xs font-bold text-[#0080f0] tracking-widest uppercase mt-2">
            CAMPUS LINK TECHNOLOGIES SDN. BHD.
          </div>
        </div>

        {/* Right: Typography & Slogan */}
        <div className="w-1/2 flex flex-col justify-center space-y-4 pl-4">
          <div>
            <div className="flex items-center text-3xl font-black tracking-tight leading-none">
              <span className="text-[#0c1e38] dark:text-slate-100">CAMPUS</span>
              <span className="text-[#0080f0] ml-2.5">LINK</span>
            </div>

            <div className="flex items-center gap-3 mt-2 w-full max-w-[280px]">
              <div className="h-[1.5px] flex-1 bg-gradient-to-r from-transparent to-[#0080f0]" />
              <span className="text-[11px] font-extrabold text-[#0c1e38] dark:text-slate-200 tracking-[0.25em] uppercase">
                TECHNOLOGIES
              </span>
              <div className="h-[1.5px] flex-1 bg-gradient-to-l from-transparent to-[#0080f0]" />
            </div>

            <div className="flex items-center gap-2 mt-2">
              <span className="text-[10px] font-bold text-white bg-blue-600 px-2 py-0.5 rounded-full">
                EST. {estYear || 2026}
              </span>
              <span className="text-[10px] font-semibold text-slate-400">
                SDN. BHD
              </span>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="text-2xl font-black tracking-tight leading-tight">
              <span className="text-[#0080f0]">Made</span>{' '}
              <span className="text-[#0c1e38] dark:text-slate-100">for Students</span>
            </div>
            <div className="text-2xl font-black tracking-tight leading-tight mt-1">
              <span className="text-[#0080f0]">Built</span>{' '}
              <span className="text-[#0c1e38] dark:text-slate-100">for Success</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 6. FULL HERO / ICON STACK (Default, matches Picture11.png)
  return (
    <div className={`flex flex-col items-center justify-center p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm ${className}`}>
      {/* Vector Emblem */}
      <div className="w-36 h-28 sm:w-44 sm:h-34">
        <CampusLinkLogo variant="emblem" />
      </div>

      {/* Typography Block */}
      <div className="flex flex-col items-center text-center mt-1">
        <div className="flex items-center text-xl sm:text-2xl font-black tracking-wider leading-none">
          <span className="text-[#0c1e38] dark:text-slate-100">CAMPUS</span>
          <span className="text-[#0080f0] ml-2">LINK</span>
        </div>

        {/* Divider + TECHNOLOGIES */}
        <div className="flex items-center gap-2.5 mt-2 w-full max-w-[210px]">
          <div className="h-[1.5px] flex-1 bg-gradient-to-r from-transparent to-[#0080f0]" />
          <span className="text-[10.5px] font-extrabold text-[#0c1e38] dark:text-slate-200 tracking-[0.25em] uppercase">
            TECHNOLOGIES
          </span>
          <div className="h-[1.5px] flex-1 bg-gradient-to-l from-transparent to-[#0080f0]" />
        </div>

        {/* EST. 2026 or SDN. BHD */}
        <div className="flex items-center gap-2 mt-1.5">
          <span className="text-[9.5px] font-extrabold text-[#0080f0] tracking-[0.2em]">
            {estYear ? `EST. ${estYear} • SDN. BHD` : 'SDN. BHD'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default CampusLinkLogo;
