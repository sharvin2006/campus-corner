import React from 'react';
import { AlertTriangle, Radio } from 'lucide-react';

interface SOSFloatingTriggerProps {
  onTriggerSOS: () => void;
  activeAlertsCount: number;
}

export const SOSFloatingTrigger: React.FC<SOSFloatingTriggerProps> = ({
  onTriggerSOS,
  activeAlertsCount,
}) => {
  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-2 group">
      {activeAlertsCount > 0 && (
        <span className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-950/90 border border-red-500 text-white text-xs font-bold shadow-lg animate-bounce backdrop-blur-xs">
          <Radio className="w-3.5 h-3.5 text-red-400 animate-ping" />
          <span>{activeAlertsCount} Active SOS on Campus</span>
        </span>
      )}

      <button
        id="floating_sos_trigger_btn"
        onClick={onTriggerSOS}
        className="relative flex items-center justify-center gap-1.5 px-4 py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-black text-xs rounded-2xl shadow-xl shadow-red-600/40 border-2 border-white dark:border-slate-900 transition-all hover:scale-105 active:scale-95 cursor-pointer uppercase tracking-wider"
        title="Campus SOS One-Tap Emergency Alert"
      >
        <div className="w-2.5 h-2.5 rounded-full bg-white animate-ping absolute -top-1 -right-1" />
        <AlertTriangle className="w-4 h-4 text-amber-300" />
        <span>SOS</span>
      </button>
    </div>
  );
};
