import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  ShieldCheck, 
  Sparkles, 
  Phone, 
  MessageSquare, 
  Calendar, 
  AlertTriangle, 
  CheckCircle2, 
  Users, 
  BedDouble, 
  Clock, 
  Share2, 
  Flag, 
  Check, 
  ExternalLink,
  Lock,
  Home
} from 'lucide-react';
import { RentalListing, User } from '../../types';

interface RentalDetailModalProps {
  rental: RentalListing | null;
  onClose: () => void;
  currentUser: User;
  onStartChat?: (sellerId: string, sellerName: string, initialMessage?: string) => void;
  onOpenReportModal: (rental: RentalListing) => void;
}

export const RentalDetailModal: React.FC<RentalDetailModalProps> = ({
  rental,
  onClose,
  currentUser,
  onStartChat,
  onOpenReportModal,
}) => {
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!rental) return null;

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Hi ${rental.sellerName}, I found your rental listing "${rental.title}" on Campus Corner (RM${rental.monthlyRent}/month). Is a slot still available for viewing? My name is ${currentUser.name}.`
    );
    window.open(`https://wa.me/${rental.sellerWhatsapp}?text=${text}`, '_blank');
  };

  const handleCall = () => {
    window.open(`tel:${rental.sellerPhone}`);
  };

  const handleChat = () => {
    if (onStartChat) {
      onStartChat(
        rental.sellerId,
        rental.sellerName,
        `Hello ${rental.sellerName}, I'm inquiring about "${rental.title}" (RM${rental.monthlyRent}/month) listed on Campus Corner Premium Rentals.`
      );
      onClose();
    }
  };

  const isOccupied = rental.availableSlots === 0 || rental.status === 'fully_occupied';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-3xl my-6 bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        
        {/* Top Floating Action Header */}
        <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
          <button
            onClick={handleShare}
            title="Share listing link"
            className="p-2.5 rounded-full bg-white/90 dark:bg-slate-900/90 text-slate-700 dark:text-slate-200 shadow-md backdrop-blur-sm hover:scale-105 transition-transform"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
          </button>
          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-white/90 dark:bg-slate-900/90 text-slate-700 dark:text-slate-200 shadow-md backdrop-blur-sm hover:scale-105 transition-transform"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Student Safety Warning Banner at Very Top */}
        <div className="bg-amber-50 dark:bg-amber-950/60 border-b border-amber-200 dark:border-amber-800/80 px-4 py-2.5 flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
          <div className="flex items-center gap-2 font-medium">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Student Safety Rule:</strong> Never transfer money directly to a rental provider before confirming the property and rental agreement.
            </span>
          </div>
          <button
            onClick={() => onOpenReportModal(rental)}
            className="hidden sm:flex items-center gap-1 text-[11px] text-rose-600 hover:text-rose-700 font-bold whitespace-nowrap ml-3"
          >
            <Flag className="w-3 h-3" />
            Report
          </button>
        </div>

        {/* Media Carousel */}
        <div className="relative bg-slate-950 aspect-[16/9] sm:aspect-[21/9] max-h-72 w-full overflow-hidden">
          <img
            src={rental.photos[selectedPhotoIndex] || rental.photos[0]}
            alt={rental.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />

          {/* Badges Overlay */}
          <div className="absolute bottom-3 left-4 flex flex-wrap items-center gap-2 z-10">
            {rental.packageTier === 'premium' && (
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-black text-xs shadow-lg">
                <Sparkles className="w-3.5 h-3.5 fill-current" />
                ⭐ PREMIUM
              </span>
            )}
            {rental.isVerifiedRental ? (
              <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-600 text-white font-bold text-xs shadow-lg">
                <ShieldCheck className="w-3.5 h-3.5" />
                ✓ VERIFIED RENTAL
              </span>
            ) : (
              <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-800/90 text-slate-300 font-medium text-[11px] border border-slate-700">
                Unverified Listing
              </span>
            )}
            {rental.packageTier === 'featured' && (
              <span className="px-2.5 py-1 rounded-full bg-indigo-600 text-white font-bold text-xs shadow-md">
                FEATURED
              </span>
            )}
            <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-sm text-white text-xs font-semibold uppercase tracking-wider">
              {rental.propertyType.replace('_', ' ')}
            </span>
          </div>

          {/* Photo count selector if multiple */}
          {rental.photos.length > 1 && (
            <div className="absolute bottom-3 right-4 flex items-center gap-1 z-10 bg-black/60 backdrop-blur-sm px-2 py-1 rounded-full">
              {rental.photos.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedPhotoIndex(idx)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    selectedPhotoIndex === idx ? 'bg-white w-4' : 'bg-white/40'
                  }`}
                />
              ))}
            </div>
          )}
        </div>

        {/* Thumbnail Preview Strip */}
        {rental.photos.length > 1 && (
          <div className="flex gap-2 p-2 px-4 bg-slate-100 dark:bg-slate-800 overflow-x-auto">
            {rental.photos.map((photo, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedPhotoIndex(idx)}
                className={`relative w-16 h-12 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                  selectedPhotoIndex === idx ? 'border-indigo-600 scale-105' : 'border-transparent opacity-70'
                }`}
              >
                <img src={photo} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>
        )}

        {/* Body Content */}
        <div className="p-5 sm:p-6 space-y-6 max-h-[60vh] overflow-y-auto">
          
          {/* Main Title & Price Header */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="space-y-1.5 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {rental.genderPreference}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  Listing Active ({rental.daysRemaining} days left)
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100">
                {rental.title}
              </h2>
              <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
                <span>{rental.location}</span>
                <span className="text-slate-300 dark:text-slate-600">•</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                  {rental.distanceFromCampus}
                </span>
              </div>
            </div>

            {/* Price Card */}
            <div className="bg-slate-50 dark:bg-slate-800/80 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700/80 sm:text-right shrink-0">
              <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Monthly Rental
              </div>
              <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">
                RM {rental.monthlyRent}
                <span className="text-xs font-normal text-slate-500 dark:text-slate-400"> / month</span>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Deposit: <span className="font-bold text-slate-700 dark:text-slate-300">RM {rental.deposit}</span>
              </div>
            </div>
          </div>

          {/* Availability Slots Bar */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-xs text-slate-800 dark:text-slate-200">
                <Users className="w-4 h-4 text-indigo-600" />
                <span>Rental Availability Slots</span>
              </div>
              <div className="flex items-center gap-2">
                {isOccupied ? (
                  <span className="px-2.5 py-1 rounded-full bg-slate-700 text-white text-xs font-black">
                    Fully Occupied
                  </span>
                ) : (
                  <span className="px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-extrabold border border-emerald-300 dark:border-emerald-800">
                    {rental.availableSlots} / {rental.totalSlots} Slots Available
                  </span>
                )}
              </div>
            </div>

            {/* Progress bar visual */}
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all ${
                  isOccupied ? 'bg-slate-500' : 'bg-emerald-500'
                }`}
                style={{
                  width: `${rental.totalSlots > 0 ? ((rental.totalSlots - rental.availableSlots) / rental.totalSlots) * 100 : 0}%`,
                }}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>{rental.totalRooms} Rooms Total ({rental.totalSlots} Capacity)</span>
              <span className="flex items-center gap-1 font-medium">
                <Calendar className="w-3 h-3" />
                {rental.availableDate}
              </span>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
              Property Description
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
              {rental.description}
            </p>
          </div>

          {/* Facilities Provided */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
              Facilities Provided
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {rental.facilities.map((fac, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 p-2.5 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200/80 dark:border-slate-700/80 text-xs text-slate-700 dark:text-slate-300"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span className="truncate">{fac}</span>
                </div>
              ))}
            </div>
          </div>

          {/* House Rules */}
          {rental.houseRules.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-400">
                House Rules & Resident Etiquette
              </h3>
              <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 list-disc list-inside">
                {rental.houseRules.map((rule, idx) => (
                  <li key={idx}>{rule}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Verified Seller Safety Verification Section */}
          <div className="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-xs text-indigo-900 dark:text-indigo-200">
                <ShieldCheck className="w-4 h-4 text-indigo-600" />
                <span>Verified Seller Trust Check</span>
              </div>
              {rental.isVerifiedRental ? (
                <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
                  Verified Identity & Permission
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200 text-[10px] font-semibold">
                  Pending Verification
                </span>
              )}
            </div>

            {rental.isVerifiedRental && rental.verificationDetails ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700 dark:text-slate-300 bg-white/60 dark:bg-slate-900/60 p-3 rounded-xl">
                <div>
                  <span className="text-slate-400 text-[11px] block">Verified Name:</span>
                  <strong className="text-slate-900 dark:text-slate-100">{rental.verificationDetails.fullName}</strong>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px] block">Relationship:</span>
                  <span>{rental.verificationDetails.relationshipToProperty} ({rental.sellerRole})</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px] block">Proof Reviewed:</span>
                  <span>{rental.verificationDetails.proofType}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px] block">Review Date:</span>
                  <span>{rental.verificationDetails.verifiedAt || '2026-08'} (Campus Corner Admin)</span>
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-600 dark:text-slate-300 bg-white/60 dark:bg-slate-900/60 p-3 rounded-xl">
                This seller has purchased advertising access but has not yet concluded official owner authorization verification. Exercise extra caution during inspection.
              </div>
            )}

            {/* Crucial Verification Disclaimer as demanded by Prompt */}
            <div className="text-[11px] text-indigo-950/80 dark:text-indigo-300/80 italic">
              * Notice: Verification reduces risk by validating seller identity and authorization, but does NOT guarantee that every transaction is completely risk-free. Always inspect in person and review the tenancy agreement before any payment.
            </div>
          </div>

          {/* Seller Card & Action Buttons */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 text-white font-bold flex items-center justify-center text-base shadow-sm">
                {rental.sellerName.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-slate-900 dark:text-slate-100">
                    {rental.sellerName}
                  </span>
                  {rental.isVerifiedRental && (
                    <ShieldCheck className="w-4 h-4 text-emerald-600 fill-emerald-100" />
                  )}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {rental.sellerRole} • Tel: {rental.sellerPhone}
                </div>
              </div>
            </div>

            {/* Contact Actions */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleWhatsApp}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>
              
              <button
                onClick={handleCall}
                className="p-2.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 rounded-xl cursor-pointer"
                title="Phone call"
              >
                <Phone className="w-4 h-4" />
              </button>

              {rental.allowInAppChat && onStartChat && (
                <button
                  onClick={handleChat}
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>In-App Chat</span>
                </button>
              )}
            </div>
          </div>

          {/* Report Button Bottom Bar */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-100 dark:border-slate-800 text-xs">
            <span className="text-slate-400">
              Listing ID: <code className="font-mono">{rental.id}</code>
            </span>
            <button
              onClick={() => onOpenReportModal(rental)}
              className="flex items-center gap-1 text-rose-600 hover:text-rose-700 font-bold cursor-pointer"
            >
              <Flag className="w-3.5 h-3.5" />
              Report suspicious listing or incorrect info
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
