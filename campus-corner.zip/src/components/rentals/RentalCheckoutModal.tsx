import React, { useState } from 'react';
import { CampusLinkLogo } from '../CampusLinkLogo';
import { 
  X, 
  Sparkles, 
  Check, 
  CreditCard, 
  QrCode, 
  Wallet, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight,
  HelpCircle,
  Building
} from 'lucide-react';
import { RentalPackageConfig, RentalPackageTier, User } from '../../types';

interface RentalCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  packages: RentalPackageConfig[];
  selectedTier: RentalPackageTier;
  onSelectTier: (tier: RentalPackageTier) => void;
  onConfirmPayment: (tier: RentalPackageTier, paymentMethod: 'DuitNow QR' | 'FPX Online Banking' | 'Campus Student E-Wallet') => Promise<void>;
  currentUser: User;
  isRenewal?: boolean;
  rentalTitle?: string;
}

export const RentalCheckoutModal: React.FC<RentalCheckoutModalProps> = ({
  isOpen,
  onClose,
  packages,
  selectedTier,
  onSelectTier,
  onConfirmPayment,
  currentUser,
  isRenewal = false,
  rentalTitle,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'DuitNow QR' | 'FPX Online Banking' | 'Campus Student E-Wallet'>('DuitNow QR');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  if (!isOpen) return null;

  const currentPackage = packages.find(p => p.tier === selectedTier) || packages[0];

  const handlePay = async () => {
    setIsProcessing(true);
    try {
      await onConfirmPayment(selectedTier, paymentMethod);
      setPaymentSuccess(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFinish = () => {
    setPaymentSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-300/40 text-amber-300 flex items-center justify-center font-bold">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base">
                {isRenewal ? 'Renew Rental Advertising Package' : 'Select Premium Rental Package'}
              </h2>
              <p className="text-xs text-indigo-200">
                {isRenewal ? `Extending listing for "${rentalTitle || 'Your Property'}"` : 'Choose your advertising reach on Campus Corner'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Essential Business Rule Banner */}
        <div className="px-5 py-2.5 bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-800 text-[11px] text-amber-900 dark:text-amber-300 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <span>
            <strong>Transparency Notice:</strong> Payment grants access to premium advertising features and visibility on Campus Corner. Payment does <em>not</em> confer a &quot;Verified Rental&quot; badge, which requires a separate identity and property authorization review.
          </span>
        </div>

        {paymentSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900 dark:text-slate-100">
                Payment Successful!
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                Your <strong>{currentPackage.name}</strong> (RM{currentPackage.priceRM}) has been activated. Your rental advertisement is now live on Campus Corner for 30 days.
              </p>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs text-left max-w-sm mx-auto space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Package:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{currentPackage.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount Paid:</span>
                <span className="font-black text-indigo-600 dark:text-indigo-400">RM {currentPackage.priceRM}.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Duration:</span>
                <span>30 Days Active</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Method:</span>
                <span>{paymentMethod}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-200 dark:border-slate-700">
                <span className="text-slate-500">Recipient:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <CampusLinkLogo variant="compact" />
                </span>
              </div>
            </div>

            <div className="pt-3">
              <button
                onClick={handleFinish}
                className="w-full max-w-sm py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-lg cursor-pointer transition-colors"
              >
                Continue to Rentals Dashboard
              </button>
            </div>
          </div>
        ) : (
          <div className="p-5 sm:p-6 space-y-6 max-h-[70vh] overflow-y-auto">
            
            {/* Package Selection Cards */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                1. Select Advertising Tier
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {packages.map((pkg) => {
                  const isSelected = selectedTier === pkg.tier;
                  return (
                    <div
                      key={pkg.tier}
                      onClick={() => onSelectTier(pkg.tier)}
                      className={`relative p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/40 dark:bg-indigo-950/40 shadow-md scale-[1.02]'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                      }`}
                    >
                      {pkg.recommended && (
                        <span className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-[10px] shadow-sm">
                          POPULAR
                        </span>
                      )}

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            pkg.tier === 'premium'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300'
                              : pkg.tier === 'featured'
                              ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/60 dark:text-indigo-300'
                              : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                          }`}>
                            {pkg.badgeLabel}
                          </span>
                          {isSelected && (
                            <div className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </div>
                          )}
                        </div>

                        <div>
                          <div className="font-bold text-sm text-slate-900 dark:text-slate-100">{pkg.name}</div>
                          <div className="text-xl font-black text-indigo-600 dark:text-indigo-400 mt-1">
                            RM {pkg.priceRM}
                            <span className="text-xs font-normal text-slate-400"> / 30d</span>
                          </div>
                        </div>

                        <p className="text-[11px] text-slate-500 leading-tight">
                          {pkg.description}
                        </p>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1 text-[10px] text-slate-600 dark:text-slate-300">
                        {pkg.features.slice(0, 3).map((feat, idx) => (
                          <div key={idx} className="flex items-center gap-1.5">
                            <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                            <span className="truncate">{feat}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                2. Select Payment Method
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                
                {/* DuitNow QR */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('DuitNow QR')}
                  className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                    paymentMethod === 'DuitNow QR'
                      ? 'border-pink-600 bg-pink-50/50 dark:bg-pink-950/30 text-pink-950 dark:text-pink-200'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-pink-600 text-white flex items-center justify-center shrink-0">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-xs">DuitNow QR</div>
                    <div className="text-[10px] text-slate-400">Instant Scan & Pay</div>
                  </div>
                </button>

                {/* Campus Student E-Wallet */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('Campus Student E-Wallet')}
                  className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                    paymentMethod === 'Campus Student E-Wallet'
                      ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30 text-emerald-950 dark:text-emerald-200'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Wallet className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-xs">Student E-Wallet</div>
                    <div className="text-[10px] text-slate-400">Balance: RM45.00</div>
                  </div>
                </button>

                {/* FPX Online Banking */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('FPX Online Banking')}
                  className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                    paymentMethod === 'FPX Online Banking'
                      ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-950 dark:text-indigo-200'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-xs">FPX Banking</div>
                    <div className="text-[10px] text-slate-400">Maybank, CIMB, Bank Islam</div>
                  </div>
                </button>

              </div>
            </div>

            {/* DuitNow QR Interactive Simulator Box */}
            {paymentMethod === 'DuitNow QR' && (
              <div className="p-4 rounded-2xl bg-pink-50/60 dark:bg-pink-950/30 border border-pink-200 dark:border-pink-900/50 flex flex-col sm:flex-row items-center gap-4 text-xs">
                <div className="w-24 h-24 bg-white p-2 rounded-xl shadow-md border border-pink-200 shrink-0 flex items-center justify-center">
                  {/* Visual QR pattern simulated */}
                  <div className="w-full h-full border-2 border-dashed border-pink-500 rounded flex flex-col items-center justify-center text-pink-600 text-[10px] font-mono text-center font-bold">
                    <QrCode className="w-8 h-8 mx-auto mb-1" />
                    <span>RM{currentPackage.priceRM}.00</span>
                  </div>
                </div>
                <div className="space-y-1.5 text-slate-700 dark:text-slate-300 w-full">
                  <div className="font-bold text-pink-900 dark:text-pink-300">
                    Scan via Touch &apos;n Go eWallet, MAE, or any Malaysian Banking App
                  </div>
                  <div className="p-2.5 rounded-xl bg-white dark:bg-slate-800/90 border border-pink-200/80 dark:border-pink-900/60 flex items-center justify-between gap-3 shadow-2xs">
                    <div>
                      <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Official Recipient Account</div>
                      <div className="text-[12px] font-bold text-slate-900 dark:text-slate-100">Campus Link Technologies Sdn. Bhd.</div>
                      <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium">Campus Corner Rentals Division • Verified Corporate Account</div>
                    </div>
                    <div className="bg-white p-1 rounded-lg border border-slate-100 shadow-2xs shrink-0">
                      <CampusLinkLogo variant="horizontal" size={26} showSubtitle={false} />
                    </div>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Zero transaction fee for polytechnic student sellers.
                  </div>
                </div>
              </div>
            )}

            {/* Checkout Summary Footer */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <div className="text-[11px] text-slate-500">Total Payable for 30-Day Listing:</div>
                <div className="text-2xl font-black text-slate-900 dark:text-slate-100">
                  RM {currentPackage.priceRM}.00
                </div>
              </div>

              <button
                type="button"
                onClick={handlePay}
                disabled={isProcessing}
                className="w-full sm:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl shadow-lg cursor-pointer transition-transform hover:scale-[1.02] flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>{isProcessing ? 'Processing Payment...' : `Pay RM${currentPackage.priceRM} & Activate`}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
