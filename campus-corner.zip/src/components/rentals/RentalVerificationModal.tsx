import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Upload, 
  Check, 
  AlertCircle, 
  CheckCircle2, 
  FileText, 
  Info,
  Lock
} from 'lucide-react';
import { RentalListing, RentalVerificationDetails, User } from '../../types';

interface RentalVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  rental: RentalListing | null;
  currentUser: User;
  onSubmitVerification: (rentalId: string, data: RentalVerificationDetails) => Promise<void>;
}

export const RentalVerificationModal: React.FC<RentalVerificationModalProps> = ({
  isOpen,
  onClose,
  rental,
  currentUser,
  onSubmitVerification,
}) => {
  const [fullName, setFullName] = useState(currentUser.name || '');
  const [contactNumber, setContactNumber] = useState(currentUser.phone || '');
  const [icOrStudentId, setIcOrStudentId] = useState(currentUser.studentId || '');
  const [relationshipToProperty, setRelationshipToProperty] = useState<'Owner' | 'Current Master Tenant' | 'Authorized Student Agent'>('Current Master Tenant');
  const [proofType, setProofType] = useState<'Tenancy Agreement' | 'Owner Authorization Letter' | 'Utility Bill Proof' | 'Student Identity Card'>('Tenancy Agreement');
  const [documentName, setDocumentName] = useState('Tenancy_Contract_Document.pdf');
  const [notes, setNotes] = useState('');
  const [confirmedPermission, setConfirmedPermission] = useState(false);
  const [disclaimerAccepted, setDisclaimerAccepted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen || !rental) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmedPermission || !disclaimerAccepted) {
      alert('Please confirm the legal permission and risk disclaimer checkboxes to proceed.');
      return;
    }

    setIsSubmitting(true);
    try {
      const details: RentalVerificationDetails = {
        fullName,
        contactNumber,
        icOrStudentId,
        relationshipToProperty,
        proofType,
        documentName,
        notes,
        confirmedPermission,
        submittedAt: new Date().toISOString().split('T')[0],
      };
      await onSubmitVerification(rental.id, details);
      setIsSuccess(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setIsSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 bg-gradient-to-r from-emerald-800 to-teal-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-400/20 border border-emerald-300/40 text-emerald-300 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base">Verified Rental Application</h2>
              <p className="text-xs text-emerald-200">
                Safety and identity check for &quot;{rental.title}&quot;
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Fundamental Principle Banner */}
        <div className="px-5 py-2.5 bg-emerald-50 dark:bg-emerald-950/40 border-b border-emerald-200 dark:border-emerald-800/60 text-[11px] text-emerald-900 dark:text-emerald-300 flex items-start gap-2">
          <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <span>
            <strong>Verification Philosophy:</strong> Payment alone does NOT earn the &quot;Verified Rental&quot; badge. You must confirm that you are the legitimate owner or possess written authority from the landlord to advertise for students.
          </span>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900 dark:text-slate-100">
                Verified Badge Granted!
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                Your authorization documents have been approved. <strong>✓ VERIFIED RENTAL</strong> badge is now prominently displayed on your listing.
              </p>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs text-left max-w-sm mx-auto space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Verified Seller:</span>
                <span className="font-bold">{fullName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Document:</span>
                <span>{proofType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Status:</span>
                <span className="text-emerald-600 font-bold">✓ Active on Listing</span>
              </div>
            </div>

            <button
              onClick={handleClose}
              className="w-full max-w-sm py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-lg cursor-pointer transition-colors"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 text-xs max-h-[70vh] overflow-y-auto">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-200">
                  Full Legal Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Full Legal Name / Student Name"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-semibold placeholder-slate-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-200">
                  Contact Phone Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  placeholder="e.g. 017-4829103"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-semibold placeholder-slate-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-200">
                  IC or PSAS Student Matric ID <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={icOrStudentId}
                  onChange={(e) => setIcOrStudentId(e.target.value)}
                  placeholder="e.g. 15DPM23F1008 or 030512-08-1122"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-semibold placeholder-slate-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 dark:text-slate-200">
                  Relationship to Property <span className="text-rose-500">*</span>
                </label>
                <select
                  value={relationshipToProperty}
                  onChange={(e) => setRelationshipToProperty(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-semibold"
                >
                  <option value="Current Master Tenant">Current Master Tenant / House Representative</option>
                  <option value="Owner">Direct Landlord / Property Owner</option>
                  <option value="Authorized Student Agent">Authorized Student Agent / Senior</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-200">
                Supporting Verification Document <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  'Tenancy Agreement',
                  'Owner Authorization Letter',
                  'Utility Bill Proof',
                  'Student Identity Card',
                ].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setProofType(type as any)}
                    className={`p-2 rounded-xl border text-left text-[11px] transition-all cursor-pointer ${
                      proofType === type
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-950 dark:text-emerald-200 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5 mb-1 text-emerald-600" />
                    <span className="line-clamp-2">{type}</span>
                  </button>
                ))}
              </div>

              <div className="mt-2 p-3 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-800/40">
                <div className="flex items-center gap-2">
                  <Upload className="w-4 h-4 text-slate-400" />
                  <span className="font-medium text-slate-700 dark:text-slate-300 truncate">
                    {documentName}
                  </span>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300 px-2 py-0.5 rounded font-bold">
                  Simulated Ready
                </span>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-bold text-slate-700 dark:text-slate-200">
                Additional Notes for Moderation Team (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                placeholder="e.g. Master lease active until Dec 2027; replacing graduated roommate..."
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-black font-semibold placeholder-slate-500"
              />
            </div>

            {/* Mandatory Checkboxes */}
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={confirmedPermission}
                  onChange={(e) => setConfirmedPermission(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  required
                />
                <span className="text-[11px] text-slate-700 dark:text-slate-300 leading-snug">
                  <strong>Permission Guarantee:</strong> I solemnly declare and confirm that I have legitimate legal authority and permission from the property owner to advertise this student accommodation on Campus Corner.
                </span>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={disclaimerAccepted}
                  onChange={(e) => setDisclaimerAccepted(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  required
                />
                <span className="text-[11px] text-slate-700 dark:text-slate-300 leading-snug">
                  <strong>Safety Disclaimer Agreement:</strong> I acknowledge that verification reduces risk for students by checking identity and records, but does not guarantee every transaction is risk-free.
                </span>
              </label>

            </div>

            <div className="flex items-center gap-2 pt-3">
              <button
                type="submit"
                disabled={isSubmitting || !confirmedPermission || !disclaimerAccepted}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer transition-colors disabled:opacity-50"
              >
                {isSubmitting ? 'Verifying Documents...' : 'Submit Verification for Approval'}
              </button>
              <button
                type="button"
                onClick={handleClose}
                className="py-3 px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
