import React, { useState } from 'react';
import { 
  AlertTriangle, 
  X, 
  ShieldAlert, 
  CheckCircle2, 
  FileWarning, 
  Info 
} from 'lucide-react';
import { RentalListing, RentalReportReason } from '../../types';

interface RentalReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  rental: RentalListing | null;
  onSubmitReport: (rentalId: string, reason: RentalReportReason, details: string) => Promise<void>;
}

export const RentalReportModal: React.FC<RentalReportModalProps> = ({
  isOpen,
  onClose,
  rental,
  onSubmitReport,
}) => {
  const [reason, setReason] = useState<RentalReportReason>('suspected_scam');
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen || !rental) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onSubmitReport(rental.id, reason, details);
      setSubmitted(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setSubmitted(false);
    setDetails('');
    setReason('suspected_scam');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-rose-50 dark:bg-rose-950/40 border-b border-rose-100 dark:border-rose-900/50">
          <div className="flex items-center gap-2 text-rose-700 dark:text-rose-400">
            <ShieldAlert className="w-5 h-5" />
            <h3 className="font-bold text-sm">Report Rental Listing</h3>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 dark:text-slate-100 text-base">Report Submitted</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Thank you for protecting fellow students. Our Campus Corner Safety Moderation team has received your report regarding <strong>{rental.title}</strong> and will investigate within 24 hours.
              </p>
            </div>
            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-800 text-[11px] text-amber-800 dark:text-amber-300 flex items-start gap-2 text-left">
              <Info className="w-4 h-4 shrink-0 mt-0.5" />
              <span>Reminder: Never transfer deposit funds or booking fees prior to in-person inspection and verifying tenancy contracts.</span>
            </div>
            <button
              onClick={handleClose}
              className="w-full py-2.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-bold rounded-xl text-xs hover:bg-slate-800"
            >
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
              <div className="text-[11px] text-slate-400">Target Listing:</div>
              <div className="font-bold text-slate-800 dark:text-slate-100 truncate">{rental.title}</div>
              <div className="text-[11px] text-slate-500">{rental.location} • RM{rental.monthlyRent}/mo</div>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-200">
                Reason for Reporting <span className="text-rose-500">*</span>
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value as RentalReportReason)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-rose-500"
                required
              >
                <option value="suspected_scam">Suspected Scam / Asking for online money transfer</option>
                <option value="fake_property">Fake Property / Does not exist in location</option>
                <option value="incorrect_info">Incorrect Information / Wrong price or facilities</option>
                <option value="misleading_listing">Unreasonable or Misleading Listing</option>
                <option value="inappropriate_content">Inappropriate Content or Harassment</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-200">
                Additional Details / Evidence
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                rows={3}
                placeholder="Describe what happened or why you believe this listing is suspicious..."
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-rose-500"
                required
              />
            </div>

            <div className="p-3 bg-rose-50/80 dark:bg-rose-950/30 rounded-xl border border-rose-200 dark:border-rose-900/40 text-[11px] text-rose-800 dark:text-rose-300 flex items-start gap-2">
              <FileWarning className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>
                False reporting of genuine student listings is prohibited under PSAS Student Conduct Rules.
              </span>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl cursor-pointer transition-colors disabled:opacity-50"
              >
                {isSubmitting ? 'Submitting Report...' : 'Submit Report for Review'}
              </button>
              <button
                type="button"
                onClick={handleClose}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
