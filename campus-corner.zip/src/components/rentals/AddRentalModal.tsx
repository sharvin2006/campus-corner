import React, { useState } from 'react';
import { 
  X, 
  Home, 
  Sparkles, 
  ShieldCheck, 
  Check, 
  ArrowRight, 
  ArrowLeft, 
  Upload, 
  Image as ImageIcon, 
  AlertCircle,
  Plus,
  Trash2,
  QrCode,
  CreditCard,
  Wallet,
  CheckCircle2
} from 'lucide-react';
import { 
  RentalListing, 
  RentalPackageConfig, 
  RentalPackageTier, 
  RentalPropertyType, 
  RentalVerificationDetails, 
  User 
} from '../../types';

interface AddRentalModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  packages: RentalPackageConfig[];
  onCreateRental: (rentalData: any) => Promise<void>;
}

const COMMON_FACILITIES = [
  'High-speed WiFi',
  'Air Conditioning',
  'Ceiling Fan',
  'Washing Machine',
  'Refrigerator',
  'Study Desk & Chair',
  'Single Bed & Mattress',
  'Attached Private Bathroom',
  'Water Heater',
  'Cooking Allowed (Stove)',
  'Covered Motorcycle Parking',
  'Car Parking Lot',
  'Drinking Water Purifier',
  'Gated & Guarded Security',
];

const SAMPLE_PHOTO_PRESETS = [
  'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=900&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=900&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=900&auto=format&fit=crop&q=80',
];

export const AddRentalModal: React.FC<AddRentalModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  packages,
  onCreateRental,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form state
  const [title, setTitle] = useState('');
  const [propertyType, setPropertyType] = useState<RentalPropertyType>('room');
  const [location, setLocation] = useState('Taman Behrang 2020, Behrang Stesen');
  const [distanceMinutes, setDistanceMinutes] = useState(5);
  const [monthlyRent, setMonthlyRent] = useState<number | ''>(350);
  const [deposit, setDeposit] = useState<number | ''>(350);
  const [totalRooms, setTotalRooms] = useState<number>(4);
  const [totalSlots, setTotalSlots] = useState<number>(4);
  const [availableSlots, setAvailableSlots] = useState<number>(2);
  const [availableDate, setAvailableDate] = useState('Immediate Move-in');
  const [genderPreference, setGenderPreference] = useState<'Female Students Only' | 'Male Students Only' | 'Mixed / Any' | 'Muslim-friendly'>('Female Students Only');
  const [selectedFacilities, setSelectedFacilities] = useState<string[]>([
    'High-speed WiFi',
    'Washing Machine',
    'Refrigerator',
    'Study Desk & Chair',
  ]);
  const [houseRules, setHouseRules] = useState<string>('Quiet hours after 11 PM\nNo smoking or vaping indoors\nClean kitchen after use');
  const [photos, setPhotos] = useState<string[]>([
    SAMPLE_PHOTO_PRESETS[0],
    SAMPLE_PHOTO_PRESETS[1],
  ]);
  const [customPhotoInput, setCustomPhotoInput] = useState('');
  const [description, setDescription] = useState('');
  const [sellerPhone, setSellerPhone] = useState(currentUser.phone || '');
  const [sellerWhatsapp, setSellerWhatsapp] = useState(currentUser.phone ? currentUser.phone.replace(/[^0-9]/g, '') : '');

  // Package & Payment
  const [selectedTier, setSelectedTier] = useState<RentalPackageTier>('featured');
  const [paymentMethod, setPaymentMethod] = useState<'DuitNow QR' | 'FPX Online Banking' | 'Campus Student E-Wallet'>('DuitNow QR');

  // Verification
  const [applyForVerification, setApplyForVerification] = useState(true);
  const [fullName, setFullName] = useState(currentUser.name || '');
  const [icOrStudentId, setIcOrStudentId] = useState(currentUser.studentId || '');
  const [relationshipToProperty, setRelationshipToProperty] = useState<'Owner' | 'Current Master Tenant' | 'Authorized Student Agent'>('Current Master Tenant');
  const [proofType, setProofType] = useState<'Tenancy Agreement' | 'Owner Authorization Letter' | 'Utility Bill Proof' | 'Student Identity Card'>('Tenancy Agreement');
  const [confirmedPermission, setConfirmedPermission] = useState(true);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdSuccess, setCreatedSuccess] = useState(false);

  if (!isOpen) return null;

  const toggleFacility = (facility: string) => {
    setSelectedFacilities(prev => 
      prev.includes(facility) ? prev.filter(f => f !== facility) : [...prev, facility]
    );
  };

  const handleAddPhotoPreset = (url: string) => {
    if (!photos.includes(url)) {
      setPhotos([...photos, url]);
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(photos.filter((_, idx) => idx !== index));
  };

  const handleAddCustomPhoto = () => {
    if (customPhotoInput.trim() && !photos.includes(customPhotoInput.trim())) {
      setPhotos([...photos, customPhotoInput.trim()]);
      setCustomPhotoInput('');
    }
  };

  const selectedPkg = packages.find(p => p.tier === selectedTier) || packages[0];

  const handleFinalSubmit = async () => {
    setIsSubmitting(true);
    try {
      const payload = {
        title,
        propertyType,
        location,
        distanceFromCampus: `${distanceMinutes * 80}m • ${distanceMinutes} mins to PSAS`,
        distanceMinutes: Number(distanceMinutes),
        monthlyRent: Number(monthlyRent),
        deposit: Number(deposit),
        totalRooms: Number(totalRooms),
        totalSlots: Number(totalSlots),
        availableSlots: Number(availableSlots),
        availableDate,
        facilities: selectedFacilities,
        houseRules: houseRules.split('\n').map(s => s.trim()).filter(Boolean),
        genderPreference,
        photos: photos.length > 0 ? photos : [SAMPLE_PHOTO_PRESETS[0]],
        description,
        sellerId: currentUser.id,
        sellerName: currentUser.name,
        sellerRole: 'Student Senior',
        sellerPhone,
        sellerWhatsapp: sellerWhatsapp.replace(/\D/g, ''),
        allowInAppChat: true,
        packageTier: selectedTier,
        paymentMethod,
        verificationData: applyForVerification ? {
          fullName,
          contactNumber: sellerPhone,
          icOrStudentId,
          relationshipToProperty,
          proofType,
          confirmedPermission,
        } : undefined,
      };

      await onCreateRental(payload);
      setCreatedSuccess(true);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFinish = () => {
    setCreatedSuccess(false);
    setStep(1);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 bg-gradient-to-r from-indigo-900 to-indigo-800 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-700 text-amber-300 flex items-center justify-center font-bold">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base">Advertise Premium Student Rental</h2>
              <p className="text-xs text-indigo-200">
                Step {step} of 4: {
                  step === 1 ? 'Property & Photos' :
                  step === 2 ? 'Pricing & Slots' :
                  step === 3 ? 'Select Package & Pay' :
                  'Safety Verification'
                }
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Pills */}
        <div className="flex border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 px-4 py-2 text-xs">
          {[
            { num: 1, label: 'Property' },
            { num: 2, label: 'Pricing & Slots' },
            { num: 3, label: 'Paid Package' },
            { num: 4, label: 'Verification' },
          ].map((s) => (
            <div
              key={s.num}
              className={`flex-1 text-center py-1 font-bold transition-all border-b-2 ${
                step === s.num
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : step > s.num
                  ? 'border-emerald-500 text-emerald-600'
                  : 'border-transparent text-slate-400'
              }`}
            >
              {step > s.num ? '✓ ' : ''}{s.label}
            </div>
          ))}
        </div>

        {createdSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900 dark:text-slate-100">
                Rental Listing Published!
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                Your property <strong>&quot;{title}&quot;</strong> has been published with the <strong>{selectedPkg.name}</strong> tier and is now visible to PSAS students!
              </p>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs text-left max-w-sm mx-auto space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Rent / Slots:</span>
                <span className="font-bold">RM {monthlyRent}/mo • {availableSlots}/{totalSlots} slots</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Tier:</span>
                <span className="font-bold text-indigo-600">{selectedPkg.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Verification:</span>
                <span className="text-emerald-600 font-bold">
                  {applyForVerification ? '✓ Verified Badge Attached' : 'Unverified (Available in My Listings)'}
                </span>
              </div>
            </div>

            <button
              onClick={handleFinish}
              className="w-full max-w-sm py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-lg cursor-pointer transition-colors"
            >
              View My Rental Listing
            </button>
          </div>
        ) : (
          <div className="p-5 sm:p-6 max-h-[68vh] overflow-y-auto space-y-5 text-xs">
            
            {/* STEP 1: Property Details */}
            {step === 1 && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-200">
                    Property Name / Listing Title <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Seri Behrang Student House - Single Room with Aircond"
                    className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">
                      Property Category <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={propertyType}
                      onChange={(e) => setPropertyType(e.target.value as RentalPropertyType)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    >
                      <option value="room">Room for Rent (Bilik Sewa)</option>
                      <option value="house">House for Rent (Rumah Sewa)</option>
                      <option value="apartment">Apartment / Condominium</option>
                      <option value="student_accommodation">Student Accommodation / Hostel</option>
                      <option value="shared_room">Shared Room (Twin / Quad Sharing)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">
                      Gender Preference
                    </label>
                    <select
                      value={genderPreference}
                      onChange={(e) => setGenderPreference(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    >
                      <option value="Female Students Only">Female Students Only</option>
                      <option value="Male Students Only">Male Students Only</option>
                      <option value="Muslim-friendly">Muslim-Friendly</option>
                      <option value="Mixed / Any">Mixed / Any</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">
                      Location / Neighborhood <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Taman Behrang 2020, Behrang Stesen"
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">
                      Distance to PSAS (Minutes walk/ride): {distanceMinutes} mins
                    </label>
                    <input
                      type="range"
                      min={1}
                      max={20}
                      value={distanceMinutes}
                      onChange={(e) => setDistanceMinutes(Number(e.target.value))}
                      className="w-full"
                    />
                    <div className="flex justify-between text-[10px] text-slate-400">
                      <span>1 min (Walking)</span>
                      <span>10 mins</span>
                      <span>20 mins</span>
                    </div>
                  </div>
                </div>

                {/* Photos Selector */}
                <div className="space-y-2">
                  <label className="font-bold text-slate-700 dark:text-slate-200">
                    Property Photos ({photos.length} selected)
                  </label>
                  
                  {/* Photo thumbnails */}
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {photos.map((url, idx) => (
                      <div key={idx} className="relative w-20 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0">
                        <img src={url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        <button
                          type="button"
                          onClick={() => handleRemovePhoto(idx)}
                          className="absolute top-1 right-1 p-0.5 bg-black/70 rounded-full text-white hover:bg-rose-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Preset quick picks */}
                  <div className="space-y-1">
                    <span className="text-[11px] text-slate-400">Quick-add sample property photos:</span>
                    <div className="flex gap-2 overflow-x-auto">
                      {SAMPLE_PHOTO_PRESETS.map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleAddPhotoPreset(preset)}
                          className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg text-[10px] border border-slate-200 dark:border-slate-700 whitespace-nowrap"
                        >
                          Photo #{idx + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-200">
                    Property Description
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                    placeholder="Describe room condition, furnishings, study atmosphere, and proximity to grocery stores or food stalls..."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>
            )}

            {/* STEP 2: Pricing, Slots & Facilities */}
            {step === 2 && (
              <div className="space-y-4">
                
                {/* Pricing & Deposit */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">
                      Monthly Rental Price (RM) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-slate-400">RM</span>
                      <input
                        type="number"
                        min={50}
                        max={5000}
                        value={monthlyRent}
                        onChange={(e) => setMonthlyRent(e.target.value === '' ? '' : Number(e.target.value))}
                        placeholder="350"
                        className="w-full pl-10 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-black text-sm text-indigo-600"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">
                      Deposit Amount (RM) <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-slate-400">RM</span>
                      <input
                        type="number"
                        min={0}
                        max={10000}
                        value={deposit}
                        onChange={(e) => setDeposit(e.target.value === '' ? '' : Number(e.target.value))}
                        placeholder="350"
                        className="w-full pl-10 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-sm"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Rental Availability Slots (Requirement 4) */}
                <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/60 space-y-3">
                  <div className="font-bold text-xs text-indigo-900 dark:text-indigo-200">
                    Rental Availability Slots (Occupancy Tracker)
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 dark:text-slate-300">Total Rooms</label>
                      <input
                        type="number"
                        min={1}
                        max={20}
                        value={totalRooms}
                        onChange={(e) => setTotalRooms(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-900 border rounded-xl"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-600 dark:text-slate-300">Total Capacity Slots</label>
                      <input
                        type="number"
                        min={1}
                        max={50}
                        value={totalSlots}
                        onChange={(e) => setTotalSlots(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-900 border rounded-xl"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-indigo-700 dark:text-indigo-300">Available Slots</label>
                      <input
                        type="number"
                        min={0}
                        max={totalSlots}
                        value={availableSlots}
                        onChange={(e) => setAvailableSlots(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-indigo-400 rounded-xl font-bold"
                      />
                    </div>
                  </div>

                  <div className="text-[11px] text-indigo-900/80 dark:text-indigo-300">
                    {availableSlots === 0 ? (
                      <span className="font-bold text-rose-600">
                        Will be automatically displayed as &quot;Fully Occupied&quot;
                      </span>
                    ) : (
                      <span>
                        Current listing badge: <strong>{availableSlots}/{totalSlots} Slots Available</strong>
                      </span>
                    )}
                  </div>
                </div>

                {/* Available Date */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-200">
                    Available Date / Move-in Timeline
                  </label>
                  <input
                    type="text"
                    value={availableDate}
                    onChange={(e) => setAvailableDate(e.target.value)}
                    placeholder="e.g. Available Immediately or 1 Nov 2026"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                {/* Facilities Checklist */}
                <div className="space-y-2">
                  <label className="font-bold text-slate-700 dark:text-slate-200">
                    Facilities & Amenities Provided ({selectedFacilities.length} selected)
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {COMMON_FACILITIES.map((facility) => {
                      const active = selectedFacilities.includes(facility);
                      return (
                        <button
                          key={facility}
                          type="button"
                          onClick={() => toggleFacility(facility)}
                          className={`p-2 rounded-xl text-left border transition-all flex items-center justify-between cursor-pointer ${
                            active
                              ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200 font-bold'
                              : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          <span className="truncate">{facility}</span>
                          {active && <Check className="w-3.5 h-3.5 text-indigo-600 shrink-0 ml-1" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* House Rules */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-200">
                    House Rules (One per line)
                  </label>
                  <textarea
                    value={houseRules}
                    onChange={(e) => setHouseRules(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                {/* Contact Phone & WhatsApp */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">Phone Call Number</label>
                    <input
                      type="text"
                      value={sellerPhone}
                      onChange={(e) => setSellerPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 dark:text-slate-200">WhatsApp (e.g. 60174829103)</label>
                    <input
                      type="text"
                      value={sellerWhatsapp}
                      onChange={(e) => setSellerWhatsapp(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>
                </div>

              </div>
            )}

            {/* STEP 3: Select Package & Checkout */}
            {step === 3 && (
              <div className="space-y-5">
                
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800 text-[11px] text-amber-900 dark:text-amber-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>
                    To advertise a rental property, select an advertising package. 100% of listing fees support Campus Corner student development programs.
                  </span>
                </div>

                {/* Packages Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {packages.map((pkg) => {
                    const isSelected = selectedTier === pkg.tier;
                    return (
                      <div
                        key={pkg.tier}
                        onClick={() => setSelectedTier(pkg.tier)}
                        className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'border-indigo-600 bg-indigo-50/40 dark:bg-indigo-950/40 shadow-md scale-[1.02]'
                            : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800">
                              {pkg.badgeLabel}
                            </span>
                            {isSelected && <Check className="w-4 h-4 text-indigo-600 stroke-[3]" />}
                          </div>
                          <div>
                            <div className="font-bold text-xs">{pkg.name}</div>
                            <div className="text-xl font-black text-indigo-600 dark:text-indigo-400">
                              RM {pkg.priceRM}
                            </div>
                          </div>
                          <p className="text-[10px] text-slate-500 leading-tight">
                            {pkg.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Payment Methods */}
                <div className="space-y-2">
                  <label className="font-bold text-slate-700 dark:text-slate-200">
                    Payment Method
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'DuitNow QR', icon: QrCode, label: 'DuitNow QR' },
                      { id: 'Campus Student E-Wallet', icon: Wallet, label: 'Student Wallet' },
                      { id: 'FPX Online Banking', icon: CreditCard, label: 'FPX Banking' },
                    ].map((method) => (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setPaymentMethod(method.id as any)}
                        className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                          paymentMethod === method.id
                            ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 font-bold text-indigo-900 dark:text-indigo-200'
                            : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        <method.icon className="w-5 h-5 mx-auto mb-1" />
                        <span className="text-[11px] block">{method.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 flex justify-between items-center">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Total Listing Package Fee:</span>
                    <strong className="text-xl font-black text-indigo-600">RM {selectedPkg.priceRM}.00</strong>
                  </div>
                  <span className="text-[11px] text-emerald-600 font-bold">
                    ✓ Valid for 30 days active listing
                  </span>
                </div>

              </div>
            )}

            {/* STEP 4: Verified Seller System */}
            {step === 4 && (
              <div className="space-y-4">
                
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-xs text-emerald-900 dark:text-emerald-200">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Verified Rental Application (Recommended)</span>
                  </div>
                  <p className="text-[11px] text-emerald-950/80 dark:text-emerald-300 leading-relaxed">
                    Paying for a listing does not make it verified. Submit basic proof of authorization to earn the <strong>✓ VERIFIED RENTAL</strong> badge and build trust with student tenants.
                  </p>
                </div>

                <label className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={applyForVerification}
                    onChange={(e) => setApplyForVerification(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600"
                  />
                  <span>Apply for Verified Seller status with this listing</span>
                </label>

                {applyForVerification && (
                  <div className="space-y-3 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Full Name</label>
                        <input
                          type="text"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          className="w-full px-3 py-2 bg-white dark:bg-slate-900 border rounded-xl"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">IC or Student Matric ID</label>
                        <input
                          type="text"
                          value={icOrStudentId}
                          onChange={(e) => setIcOrStudentId(e.target.value)}
                          className="w-full px-3 py-2 bg-white dark:bg-slate-900 border rounded-xl"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Relationship to Property</label>
                        <select
                          value={relationshipToProperty}
                          onChange={(e) => setRelationshipToProperty(e.target.value as any)}
                          className="w-full px-3 py-2 bg-white dark:bg-slate-900 border rounded-xl"
                        >
                          <option value="Current Master Tenant">Current Master Tenant (Senior Student)</option>
                          <option value="Owner">Registered Property Owner / Landlord</option>
                          <option value="Authorized Student Agent">Authorized Student Agent</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Proof Document Type</label>
                        <select
                          value={proofType}
                          onChange={(e) => setProofType(e.target.value as any)}
                          className="w-full px-3 py-2 bg-white dark:bg-slate-900 border rounded-xl"
                        >
                          <option value="Tenancy Agreement">Tenancy Agreement with Landlord</option>
                          <option value="Owner Authorization Letter">Owner Authorization Letter</option>
                          <option value="Utility Bill Proof">TNB/Water Utility Bill in Address</option>
                          <option value="Student Identity Card">PSAS Matric Card</option>
                        </select>
                      </div>
                    </div>

                    <label className="flex items-start gap-2 pt-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={confirmedPermission}
                        onChange={(e) => setConfirmedPermission(e.target.checked)}
                        className="mt-0.5 rounded border-slate-300 text-emerald-600"
                        required
                      />
                      <span className="text-[11px] text-slate-600 dark:text-slate-300">
                        I hereby declare that I have explicit permission from the property owner to advertise this student rental accommodation.
                      </span>
                    </label>
                  </div>
                )}

              </div>
            )}

            {/* Bottom Step Navigation Bar */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={() => setStep((step - 1) as any)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
              ) : (
                <div />
              )}

              {step < 4 ? (
                <button
                  type="button"
                  onClick={() => {
                    if (step === 1 && !title.trim()) {
                      alert('Please provide a listing title.');
                      return;
                    }
                    if (step === 2 && !monthlyRent) {
                      alert('Please specify the monthly rental.');
                      return;
                    }
                    setStep((step + 1) as any);
                  }}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <span>Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleFinalSubmit}
                  disabled={isSubmitting}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg disabled:opacity-50"
                >
                  <span>{isSubmitting ? 'Publishing Listing...' : `Pay RM${selectedPkg.priceRM} & Publish`}</span>
                  <Check className="w-4 h-4" />
                </button>
              )}
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
