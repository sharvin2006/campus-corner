import React, { useState, useMemo } from 'react';
import { 
  Home, 
  Search, 
  Filter, 
  Sparkles, 
  ShieldCheck, 
  AlertTriangle, 
  Plus, 
  DollarSign, 
  Users, 
  Check, 
  Calendar, 
  MapPin, 
  Clock, 
  MessageSquare, 
  Phone, 
  Eye, 
  Flag, 
  TrendingUp, 
  CreditCard, 
  ChevronRight, 
  ShieldAlert, 
  RefreshCw, 
  ExternalLink,
  BookOpen,
  SlidersHorizontal,
  Lock,
  Tag
} from 'lucide-react';
import { 
  RentalListing, 
  RentalPackageConfig, 
  RentalPackageTier, 
  RentalPaymentTransaction, 
  RentalPropertyType, 
  RentalRevenueStats, 
  RentalVerificationDetails, 
  User 
} from '../../types';
import { RentalDetailModal } from './RentalDetailModal';
import { RentalCheckoutModal } from './RentalCheckoutModal';
import { RentalVerificationModal } from './RentalVerificationModal';
import { RentalReportModal } from './RentalReportModal';
import { AddRentalModal } from './AddRentalModal';

interface CampusRentalsViewProps {
  currentUser: User;
  onStartChat?: (sellerId: string, sellerName: string, initialMessage?: string) => void;
}

export const CampusRentalsView: React.FC<CampusRentalsViewProps> = ({
  currentUser,
  onStartChat,
}) => {
  // Navigation sub-tab
  const [activeSubTab, setActiveSubTab] = useState<'browse' | 'my_listings' | 'admin_revenue' | 'safety_guide'>('browse');

  // Rentals State from API or mock fallback
  const [listings, setListings] = useState<RentalListing[]>([]);
  const [packages, setPackages] = useState<RentalPackageConfig[]>([]);
  const [transactions, setTransactions] = useState<RentalPaymentTransaction[]>([]);
  const [revenueStats, setRevenueStats] = useState<RentalRevenueStats>({
    totalRevenueRM: 285.00,
    paidListingsCount: 24,
    activePremiumCount: 7,
    activeFeaturedCount: 9,
    activeBasicCount: 8,
    expiredListingsCount: 14,
    verifiedSellersCount: 18,
    pendingVerificationsCount: 2,
    reportedListingsCount: 1,
  });

  const [isLoading, setIsLoading] = useState(true);

  // Modals state
  const [selectedRentalForDetail, setSelectedRentalForDetail] = useState<RentalListing | null>(null);
  const [selectedRentalForCheckout, setSelectedRentalForCheckout] = useState<RentalListing | null>(null);
  const [selectedRentalForVerification, setSelectedRentalForVerification] = useState<RentalListing | null>(null);
  const [selectedRentalForReport, setSelectedRentalForReport] = useState<RentalListing | null>(null);
  const [isAddRentalModalOpen, setIsAddRentalModalOpen] = useState(false);
  const [isRenewModalOpen, setIsRenewModalOpen] = useState(false);
  const [rentalToRenew, setRentalToRenew] = useState<RentalListing | null>(null);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedGender, setSelectedGender] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('all');
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [hideFullyOccupied, setHideFullyOccupied] = useState(false);
  const [sortBy, setSortBy] = useState<'recommended' | 'price_low' | 'price_high' | 'distance'>('recommended');

  // Admin editable package prices state
  const [editablePrices, setEditablePrices] = useState({
    basic: 5,
    featured: 10,
    premium: 15,
  });
  const [priceSaveSuccess, setPriceSaveSuccess] = useState(false);

  // Fetch initial rentals data from backend API
  const fetchRentalsData = async () => {
    try {
      const res = await fetch('/api/rentals');
      if (res.ok) {
        const data = await res.json();
        setListings(data.listings || []);
        setPackages(data.packages || []);
        setTransactions(data.transactions || []);
        if (data.stats) setRevenueStats(data.stats);
        if (data.packages) {
          const b = data.packages.find((p: any) => p.tier === 'basic')?.priceRM || 5;
          const f = data.packages.find((p: any) => p.tier === 'featured')?.priceRM || 10;
          const p = data.packages.find((p: any) => p.tier === 'premium')?.priceRM || 15;
          setEditablePrices({ basic: b, featured: f, premium: p });
        }
      }
    } catch (err) {
      console.warn('API not available, using local defaults', err);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchRentalsData();
  }, []);

  // Filtered Listings
  const filteredListings = useMemo(() => {
    return listings.filter(item => {
      // Search
      const matchesSearch = 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.facilities.some(f => f.toLowerCase().includes(searchQuery.toLowerCase())) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      // Property type
      if (selectedType !== 'all' && item.propertyType !== selectedType) return false;

      // Gender preference
      if (selectedGender !== 'all' && item.genderPreference !== selectedGender) return false;

      // Verified
      if (verifiedOnly && !item.isVerifiedRental) return false;

      // Hide Fully Occupied
      if (hideFullyOccupied && (item.availableSlots === 0 || item.status === 'fully_occupied')) {
        return false;
      }

      // Price range
      if (selectedPriceRange === 'under_200' && item.monthlyRent >= 200) return false;
      if (selectedPriceRange === '200_350' && (item.monthlyRent < 200 || item.monthlyRent > 350)) return false;
      if (selectedPriceRange === 'above_350' && item.monthlyRent <= 350) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'recommended') {
        // Premium first, then Featured, then Basic
        const score = (item: RentalListing) => {
          let s = 0;
          if (item.packageTier === 'premium') s += 100;
          if (item.packageTier === 'featured') s += 50;
          if (item.isVerifiedRental) s += 25;
          return s;
        };
        return score(b) - score(a);
      }
      if (sortBy === 'price_low') return a.monthlyRent - b.monthlyRent;
      if (sortBy === 'price_high') return b.monthlyRent - a.monthlyRent;
      if (sortBy === 'distance') return a.distanceMinutes - b.distanceMinutes;
      return 0;
    });
  }, [listings, searchQuery, selectedType, selectedGender, verifiedOnly, hideFullyOccupied, selectedPriceRange, sortBy]);

  // Recommended Listings Spotlight (Premium Tier)
  const recommendedListings = useMemo(() => {
    return listings.filter(l => l.packageTier === 'premium' && l.status === 'active');
  }, [listings]);

  // User's own listings
  const myListings = useMemo(() => {
    return listings.filter(l => l.sellerId === currentUser.id || l.sellerId === 'usr_me');
  }, [listings, currentUser]);

  // Handlers for Slots update (Requirement 4)
  const handleUpdateSlots = async (rentalId: string, newSlots: number) => {
    try {
      const res = await fetch(`/api/rentals/${rentalId}/update-slots`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ availableSlots: newSlots }),
      });
      if (res.ok) {
        const data = await res.json();
        setListings(prev => prev.map(item => item.id === rentalId ? data.listing : item));
      }
    } catch (err) {
      console.error(err);
      // Local fallback
      setListings(prev => prev.map(item => {
        if (item.id === rentalId) {
          const updatedSlots = Math.max(0, Math.min(item.totalSlots, newSlots));
          return {
            ...item,
            availableSlots: updatedSlots,
            status: updatedSlots === 0 ? 'fully_occupied' : 'active',
          };
        }
        return item;
      }));
    }
  };

  // Handler for Create Rental
  const handleCreateRental = async (rentalData: any) => {
    try {
      const res = await fetch('/api/rentals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rentalData),
      });
      if (res.ok) {
        const data = await res.json();
        setListings(prev => [data.listing, ...prev]);
        if (data.transaction) {
          setTransactions(prev => [data.transaction, ...prev]);
        }
        fetchRentalsData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handler for Submit Verification
  const handleSubmitVerification = async (rentalId: string, details: RentalVerificationDetails) => {
    try {
      const res = await fetch(`/api/rentals/${rentalId}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ verificationData: details, autoApprove: true }),
      });
      if (res.ok) {
        const data = await res.json();
        setListings(prev => prev.map(item => item.id === rentalId ? data.listing : item));
        fetchRentalsData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handler for Report Listing (Requirement 6)
  const handleSubmitReport = async (rentalId: string, reason: any, details: string) => {
    try {
      const res = await fetch(`/api/rentals/${rentalId}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reporterId: currentUser.id,
          reporterName: currentUser.name,
          reason,
          details,
        }),
      });
      if (res.ok) {
        fetchRentalsData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handler for Renew Listing (Requirement 8)
  const handleConfirmRenew = async (tier: RentalPackageTier, paymentMethod: any) => {
    if (!rentalToRenew) return;
    try {
      const res = await fetch(`/api/rentals/${rentalToRenew.id}/renew`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packageTier: tier, paymentMethod }),
      });
      if (res.ok) {
        const data = await res.json();
        setListings(prev => prev.map(item => item.id === rentalToRenew.id ? data.listing : item));
        if (data.transaction) {
          setTransactions(prev => [data.transaction, ...prev]);
        }
        fetchRentalsData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Admin Save Package Prices (Requirement 2 & 7)
  const handleSavePackagePrices = async () => {
    const updatedPackages = packages.map(pkg => ({
      ...pkg,
      priceRM: editablePrices[pkg.tier] || pkg.priceRM,
    }));
    try {
      const res = await fetch('/api/rentals/admin/packages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packages: updatedPackages }),
      });
      if (res.ok) {
        setPackages(updatedPackages);
        setPriceSaveSuccess(true);
        setTimeout(() => setPriceSaveSuccess(false), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Admin Moderation Action (Requirement 6)
  const handleAdminModeration = async (rentalId: string, action: string) => {
    try {
      const res = await fetch('/api/rentals/admin/moderation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rentalId, action }),
      });
      if (res.ok) {
        fetchRentalsData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 text-white p-6 sm:p-8 border border-indigo-800/50 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-md">
                <Sparkles className="w-3.5 h-3.5 fill-current" />
                ⭐ Premium Rentals Hub
              </span>
              <span className="px-2.5 py-1 rounded-full bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 text-xs font-medium">
                PSAS & Behrang Area
              </span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
              Student Rooms, Houses & Accommodations
            </h1>
            
            <p className="text-xs sm:text-sm text-indigo-200/90 leading-relaxed">
              Find verified student accommodation near campus or advertise your available room to thousands of polytechnic students. Built-in occupancy tracking and safety verification.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsAddRentalModalOpen(true)}
              className="px-5 py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-lg shadow-amber-400/20 flex items-center gap-2 cursor-pointer transition-transform hover:scale-105"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Advertise a Rental</span>
            </button>

            <button
              onClick={() => setActiveSubTab('admin_revenue')}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors"
            >
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>Revenue & Admin</span>
            </button>
          </div>
        </div>

        {/* Global Student Safety Warning Banner (Requirement 6) */}
        <div className="mt-6 pt-4 border-t border-indigo-800/60 flex items-center justify-between text-xs text-amber-200 bg-amber-500/10 -mx-6 sm:-mx-8 -mb-6 sm:-mb-8 px-6 sm:px-8 py-3 rounded-b-3xl">
          <div className="flex items-center gap-2 font-semibold">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Crucial Student Safety Notice:</strong> &ldquo;Never transfer money directly to a rental provider before confirming the property and rental agreement.&rdquo;
            </span>
          </div>
          <button
            onClick={() => setActiveSubTab('safety_guide')}
            className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold text-amber-300 hover:underline"
          >
            <span>Read Tenant Safety Guide</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        <button
          onClick={() => setActiveSubTab('browse')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeSubTab === 'browse'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
          }`}
        >
          <Search className="w-4 h-4" />
          <span>Browse Rentals ({listings.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('my_listings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeSubTab === 'my_listings'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>My Listings & Slots ({myListings.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('admin_revenue')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeSubTab === 'admin_revenue'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-500" />
          <span>Revenue & Package Settings ⭐</span>
          <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] rounded-full font-black">
            RM {revenueStats.totalRevenueRM.toFixed(0)}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('safety_guide')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
            activeSubTab === 'safety_guide'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
          }`}
        >
          <BookOpen className="w-4 h-4 text-rose-500" />
          <span>Student Tenancy Guide</span>
        </button>
      </div>

      {/* SUB-TAB 1: BROWSE RENTALS */}
      {activeSubTab === 'browse' && (
        <div className="space-y-6">
          
          {/* Recommended Rentals Spotlight Carousel (Requirement 5) */}
          {recommendedListings.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center font-black text-xs shadow-sm">
                    ⭐
                  </div>
                  <div>
                    <h2 className="font-black text-sm text-slate-900 dark:text-slate-100">
                      Recommended Rentals Spotlight
                    </h2>
                    <p className="text-[11px] text-slate-500">
                      Verified & Premium student accommodations nearest to campus
                    </p>
                  </div>
                </div>
                <span className="text-xs text-amber-700 dark:text-amber-400 font-bold bg-amber-50 dark:bg-amber-950/60 px-2.5 py-1 rounded-full border border-amber-200 dark:border-amber-800">
                  ⭐ Top Visibility Tier
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendedListings.map((rec) => (
                  <div
                    key={rec.id}
                    onClick={() => setSelectedRentalForDetail(rec)}
                    className="relative group bg-white dark:bg-slate-900 rounded-3xl p-4 border-2 border-amber-300 dark:border-amber-500/50 shadow-lg hover:shadow-xl transition-all cursor-pointer flex flex-col sm:flex-row gap-4"
                  >
                    <div className="relative sm:w-48 aspect-[4/3] rounded-2xl overflow-hidden shrink-0 bg-slate-950">
                      <img
                        src={rec.photos[0]}
                        alt={rec.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-[10px] shadow">
                        ⭐ PREMIUM
                      </span>
                      {rec.isVerifiedRental && (
                        <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-full bg-emerald-600 text-white font-bold text-[10px] shadow flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" />
                          VERIFIED
                        </span>
                      )}
                    </div>

                    <div className="flex-1 flex flex-col justify-between space-y-2">
                      <div>
                        <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                          <span className="capitalize font-semibold text-indigo-600 dark:text-indigo-400">
                            {rec.propertyType.replace('_', ' ')}
                          </span>
                          <span className="font-medium text-emerald-600 dark:text-emerald-400">
                            {rec.distanceFromCampus}
                          </span>
                        </div>
                        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 line-clamp-1 group-hover:text-indigo-600 transition-colors">
                          {rec.title}
                        </h3>
                        <p className="text-xs text-slate-500 line-clamp-2 mt-1">
                          {rec.description}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div>
                          <div className="text-[10px] text-slate-400">Monthly Rent</div>
                          <div className="text-base font-black text-indigo-600 dark:text-indigo-400">
                            RM {rec.monthlyRent} <span className="text-[10px] font-normal text-slate-400">/ mo</span>
                          </div>
                        </div>

                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          rec.availableSlots === 0 
                            ? 'bg-slate-200 text-slate-700' 
                            : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                        }`}>
                          {rec.availableSlots === 0 ? 'Fully Occupied' : `${rec.availableSlots}/${rec.totalSlots} Slots Left`}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Search & Multi-Filters Toolbar */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
            
            {/* Search Bar */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search by neighborhood (Taman Behrang 2020, Harmoni), WiFi, aircond, single room..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              />
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
              
              <div className="flex flex-wrap items-center gap-2">
                {/* Property Type Dropdown */}
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  <option value="all">All Properties</option>
                  <option value="room">Rooms for Rent</option>
                  <option value="house">Houses for Rent</option>
                  <option value="apartment">Apartments / Condos</option>
                  <option value="student_accommodation">Student Accommodation</option>
                  <option value="shared_room">Shared Rooms</option>
                </select>

                {/* Price Filter */}
                <select
                  value={selectedPriceRange}
                  onChange={(e) => setSelectedPriceRange(e.target.value)}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  <option value="all">All Prices</option>
                  <option value="under_200">Under RM200</option>
                  <option value="200_350">RM200 - RM350</option>
                  <option value="above_350">Above RM350</option>
                </select>

                {/* Gender Preference */}
                <select
                  value={selectedGender}
                  onChange={(e) => setSelectedGender(e.target.value)}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  <option value="all">All Genders</option>
                  <option value="Female Students Only">Female Only</option>
                  <option value="Male Students Only">Male Only</option>
                  <option value="Muslim-friendly">Muslim-Friendly</option>
                  <option value="Mixed / Any">Mixed</option>
                </select>

                {/* Verified Only Toggle */}
                <button
                  onClick={() => setVerifiedOnly(!verifiedOnly)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    verifiedOnly
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-700 dark:text-emerald-300 shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Verified Only</span>
                </button>

                {/* Hide Fully Occupied Toggle */}
                <button
                  onClick={() => setHideFullyOccupied(!hideFullyOccupied)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    hideFullyOccupied
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-700 dark:text-indigo-300 shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span>Hide Fully Occupied</span>
                </button>
              </div>

              {/* Sorting */}
              <div className="flex items-center gap-2">
                <span className="text-slate-400 text-xs">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  <option value="recommended">Featured & Recommended</option>
                  <option value="price_low">Price: Low to High</option>
                  <option value="price_high">Price: High to Low</option>
                  <option value="distance">Nearest to Campus</option>
                </select>
              </div>

            </div>

          </div>

          {/* Listings Grid */}
          {filteredListings.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
                <Home className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-200 text-base">
                No matching student rental listings found
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Try adjusting your filters, clearing search terms, or be the first to advertise a rental property near PSAS.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedType('all');
                  setSelectedGender('all');
                  setVerifiedOnly(false);
                  setHideFullyOccupied(false);
                  setSelectedPriceRange('all');
                }}
                className="px-4 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredListings.map((listing) => {
                const isOccupied = listing.availableSlots === 0 || listing.status === 'fully_occupied';
                const isPremium = listing.packageTier === 'premium';
                const isFeatured = listing.packageTier === 'featured';

                return (
                  <div
                    key={listing.id}
                    className={`group bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border transition-all duration-300 hover:shadow-xl flex flex-col justify-between ${
                      isPremium
                        ? 'border-amber-300 dark:border-amber-500/60 shadow-md ring-1 ring-amber-300/50'
                        : isFeatured
                        ? 'border-indigo-200 dark:border-indigo-800 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    <div>
                      {/* Image Thumbnail Container */}
                      <div 
                        onClick={() => setSelectedRentalForDetail(listing)}
                        className="relative aspect-[16/10] w-full overflow-hidden bg-slate-950 cursor-pointer"
                      >
                        <img
                          src={listing.photos[0]}
                          alt={listing.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />

                        {/* Badges on Thumbnail */}
                        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 z-10">
                          {isPremium && (
                            <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black shadow-md">
                              ⭐ PREMIUM
                            </span>
                          )}
                          {listing.isVerifiedRental ? (
                            <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-bold shadow-md">
                              <ShieldCheck className="w-3 h-3" />
                              ✓ VERIFIED RENTAL
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm text-slate-300 text-[10px] font-medium">
                              Unverified
                            </span>
                          )}
                          {isFeatured && (
                            <span className="px-2 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-bold shadow">
                              FEATURED
                            </span>
                          )}
                        </div>

                        {/* Occupancy Status Overlay */}
                        <div className="absolute bottom-3 right-3 z-10">
                          {isOccupied ? (
                            <span className="px-2.5 py-1 rounded-full bg-slate-900/90 backdrop-blur-sm text-white text-[10px] font-black uppercase tracking-wider">
                              Fully Occupied
                            </span>
                          ) : (
                            <span className="px-2.5 py-1 rounded-full bg-emerald-600/95 backdrop-blur-sm text-white text-[10px] font-black shadow">
                              {listing.availableSlots}/{listing.totalSlots} Slots Available
                            </span>
                          )}
                        </div>

                        {/* Property Type Badge bottom left */}
                        <span className="absolute bottom-3 left-3 px-2 py-0.5 rounded-lg bg-black/70 backdrop-blur-sm text-white text-[10px] font-semibold uppercase tracking-wider">
                          {listing.propertyType.replace('_', ' ')}
                        </span>
                      </div>

                      {/* Content Info */}
                      <div className="p-4 sm:p-5 space-y-3">
                        
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="text-indigo-600 dark:text-indigo-400 font-bold">
                              {listing.genderPreference}
                            </span>
                            <span className="text-slate-400 flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {listing.daysRemaining}d left
                            </span>
                          </div>

                          <h3 
                            onClick={() => setSelectedRentalForDetail(listing)}
                            className="font-bold text-sm text-slate-900 dark:text-slate-100 line-clamp-1 group-hover:text-indigo-600 transition-colors cursor-pointer"
                          >
                            {listing.title}
                          </h3>

                          <div className="flex items-center gap-1 text-xs text-slate-500">
                            <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                            <span className="truncate">{listing.location}</span>
                          </div>
                          
                          <div className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
                            {listing.distanceFromCampus}
                          </div>
                        </div>

                        {/* Facilities tags preview */}
                        <div className="flex flex-wrap gap-1">
                          {listing.facilities.slice(0, 3).map((f, i) => (
                            <span
                              key={i}
                              className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-600 dark:text-slate-400"
                            >
                              {f}
                            </span>
                          ))}
                          {listing.facilities.length > 3 && (
                            <span className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] text-slate-400">
                              +{listing.facilities.length - 3}
                            </span>
                          )}
                        </div>

                        {/* Price & Deposit Bar */}
                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                          <div>
                            <div className="text-xl font-black text-indigo-600 dark:text-indigo-400">
                              RM {listing.monthlyRent}
                              <span className="text-xs font-normal text-slate-400"> / mo</span>
                            </div>
                            <div className="text-[10px] text-slate-400">
                              Deposit: RM {listing.deposit}
                            </div>
                          </div>

                          <div className="text-right text-[11px]">
                            <span className="text-slate-400 block">Rooms</span>
                            <span className="font-bold text-slate-700 dark:text-slate-300">
                              {listing.totalRooms} Rooms
                            </span>
                          </div>
                        </div>

                      </div>
                    </div>

                    {/* Bottom Action Footer */}
                    <div className="p-4 pt-0 flex items-center gap-2">
                      <button
                        onClick={() => setSelectedRentalForDetail(listing)}
                        className="flex-1 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 font-bold text-xs rounded-xl cursor-pointer transition-colors text-center"
                      >
                        View Details
                      </button>

                      <button
                        onClick={() => {
                          const text = encodeURIComponent(`Hi ${listing.sellerName}, I found your rental listing "${listing.title}" on Campus Corner.`);
                          window.open(`https://wa.me/${listing.sellerWhatsapp}?text=${text}`, '_blank');
                        }}
                        className="p-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl cursor-pointer transition-colors shadow-sm"
                        title="Direct WhatsApp"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => setSelectedRentalForReport(listing)}
                        className="p-2 text-slate-400 hover:text-rose-600 rounded-xl cursor-pointer transition-colors"
                        title="Report Listing"
                      >
                        <Flag className="w-4 h-4" />
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* SUB-TAB 2: MY LISTINGS & SLOTS MANAGEMENT (Requirement 4 & 8) */}
      {activeSubTab === 'my_listings' && (
        <div className="space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-lg font-black text-slate-900 dark:text-slate-100">
                My Advertised Rental Properties
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Manage room availability slots in real-time, renew active listings, and verify seller permissions.
              </p>
            </div>

            <button
              onClick={() => setIsAddRentalModalOpen(true)}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>List New Property</span>
            </button>
          </div>

          {myListings.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Home className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="font-bold text-base text-slate-800 dark:text-slate-200">
                You haven&apos;t published any rental listings yet
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Got a spare room or house near PSAS? Choose a Premium Rental Listing package to reach student tenants immediately.
              </p>
              <button
                onClick={() => setIsAddRentalModalOpen(true)}
                className="px-5 py-2.5 bg-indigo-600 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Create First Rental Listing
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {myListings.map((item) => {
                const isOccupied = item.availableSlots === 0 || item.status === 'fully_occupied';
                const isExpiringSoon = item.daysRemaining <= 5;

                return (
                  <div
                    key={item.id}
                    className="p-5 sm:p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      
                      {/* Property overview */}
                      <div className="flex items-start gap-4">
                        <img
                          src={item.photos[0]}
                          alt={item.title}
                          className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shrink-0 bg-slate-950"
                          referrerPolicy="no-referrer"
                        />
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 text-[10px] font-bold">
                              {item.packageTier.toUpperCase()} TIER
                            </span>
                            {item.isVerifiedRental ? (
                              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 text-[10px] font-bold flex items-center gap-1">
                                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                                Verified Seller
                              </span>
                            ) : (
                              <button
                                onClick={() => setSelectedRentalForVerification(item)}
                                className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold hover:bg-amber-200 cursor-pointer"
                              >
                                + Get Verified Badge
                              </button>
                            )}
                          </div>

                          <h3 className="font-bold text-base text-slate-900 dark:text-slate-100">
                            {item.title}
                          </h3>
                          <div className="text-xs text-slate-500">
                            {item.location} • RM{item.monthlyRent}/month
                          </div>
                          
                          <div className="text-[11px] text-slate-400">
                            Expires on {item.expiresAt} ({item.daysRemaining} days remaining)
                          </div>
                        </div>
                      </div>

                      {/* Expiration & Renewal Action (Requirement 8) */}
                      <div className="flex flex-col sm:items-end gap-2 shrink-0">
                        {isExpiringSoon ? (
                          <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold animate-pulse">
                            ⚠️ Expiring in {item.daysRemaining} days
                          </span>
                        ) : (
                          <span className="px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 text-xs font-semibold">
                            Active Listing ({item.daysRemaining}d)
                          </span>
                        )}

                        <button
                          onClick={() => {
                            setRentalToRenew(item);
                            setIsRenewModalOpen(true);
                          }}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-sm cursor-pointer transition-colors"
                        >
                          Renew Listing (30 Days)
                        </button>
                      </div>

                    </div>

                    {/* Requirement 4: Rental Availability Slots Controller */}
                    <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-4">
                      
                      <div className="space-y-1 text-center sm:text-left">
                        <div className="flex items-center gap-2 font-bold text-xs text-slate-800 dark:text-slate-200 justify-center sm:justify-start">
                          <Users className="w-4 h-4 text-indigo-600" />
                          <span>Update Room / Slot Availability:</span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          Students see this live badge. When slots reach 0, listing automatically switches to &ldquo;Fully Occupied&rdquo;.
                        </p>
                      </div>

                      {/* Interactive Slot Increment/Decrement */}
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => handleUpdateSlots(item.id, item.availableSlots - 1)}
                          disabled={item.availableSlots <= 0}
                          className="w-8 h-8 rounded-xl bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 font-bold text-base flex items-center justify-center cursor-pointer disabled:opacity-30"
                        >
                          -
                        </button>

                        <div className="text-center min-w-[100px]">
                          <span className={`text-sm font-black px-3 py-1 rounded-full ${
                            isOccupied
                              ? 'bg-slate-700 text-white'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          }`}>
                            {isOccupied ? 'Fully Occupied' : `${item.availableSlots} / ${item.totalSlots} Slots`}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleUpdateSlots(item.id, item.availableSlots + 1)}
                          disabled={item.availableSlots >= item.totalSlots}
                          className="w-8 h-8 rounded-xl bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 font-bold text-base flex items-center justify-center cursor-pointer disabled:opacity-30"
                        >
                          +
                        </button>
                      </div>

                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                      <span>Total views: {item.viewCount} • Inquiries: {item.inquiriesCount}</span>
                      <button
                        onClick={() => setSelectedRentalForDetail(item)}
                        className="text-indigo-600 hover:underline font-bold"
                      >
                        Preview as Student Tenant →
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* SUB-TAB 3: CAMPUS CORNER REVENUE & ADMIN PORTAL (Requirement 2 & 7) */}
      {activeSubTab === 'admin_revenue' && (
        <div className="space-y-6">
          
          {/* Revenue Top Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="p-5 bg-gradient-to-br from-indigo-900 to-indigo-950 text-white rounded-3xl border border-indigo-800 shadow-md">
              <div className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-amber-400" />
                <span>Total Rental Revenue</span>
              </div>
              <div className="text-3xl font-black mt-2 text-amber-300">
                RM {revenueStats.totalRevenueRM.toFixed(2)}
              </div>
              <div className="text-[10px] text-indigo-300 mt-1">
                From {revenueStats.paidListingsCount} paid listing packages
              </div>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Active Premium Listings</span>
              </div>
              <div className="text-3xl font-black mt-2 text-slate-900 dark:text-slate-100">
                {revenueStats.activePremiumCount}
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                +{revenueStats.activeFeaturedCount} Featured • +{revenueStats.activeBasicCount} Basic
              </div>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified Sellers</span>
              </div>
              <div className="text-3xl font-black mt-2 text-emerald-600">
                {revenueStats.verifiedSellersCount}
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                Identity & property authorization checked
              </div>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                <Flag className="w-4 h-4 text-rose-500" />
                <span>Safety Reports Pending</span>
              </div>
              <div className="text-3xl font-black mt-2 text-rose-600">
                {revenueStats.reportedListingsCount}
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                Scam & suspicious listings to moderate
              </div>
            </div>

          </div>

          {/* Admin Editable Package Pricing Section (Requirement 2 & 7) */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-black text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Tag className="w-5 h-5 text-indigo-600" />
                  <span>Rental Listing Package Pricing (Administrator Config)</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Exact package prices are fully editable by the administrator. Updates apply immediately to the checkout portal.
                </p>
              </div>

              {priceSaveSuccess && (
                <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                  <Check className="w-4 h-4" /> Package Prices Saved!
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              
              {/* Basic Package */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="font-bold text-xs text-slate-700 dark:text-slate-300">Basic Rental Listing</div>
                <div className="text-[11px] text-slate-400">30-day standard search visibility</div>
                <div className="flex items-center gap-2 pt-2">
                  <span className="font-bold text-xs text-slate-500">RM</span>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={editablePrices.basic}
                    onChange={(e) => setEditablePrices({ ...editablePrices, basic: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border rounded-xl font-black text-indigo-600"
                  />
                </div>
              </div>

              {/* Featured Package */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="font-bold text-xs text-slate-700 dark:text-slate-300">Featured Rental Listing</div>
                <div className="text-[11px] text-slate-400">30-day featured border & badge</div>
                <div className="flex items-center gap-2 pt-2">
                  <span className="font-bold text-xs text-slate-500">RM</span>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={editablePrices.featured}
                    onChange={(e) => setEditablePrices({ ...editablePrices, featured: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border rounded-xl font-black text-indigo-600"
                  />
                </div>
              </div>

              {/* Premium Package */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="font-bold text-xs text-slate-700 dark:text-slate-300">Premium / Recommended</div>
                <div className="text-[11px] text-slate-400">30-day recommended top spotlight</div>
                <div className="flex items-center gap-2 pt-2">
                  <span className="font-bold text-xs text-slate-500">RM</span>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    value={editablePrices.premium}
                    onChange={(e) => setEditablePrices({ ...editablePrices, premium: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border rounded-xl font-black text-indigo-600"
                  />
                </div>
              </div>

            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={handleSavePackagePrices}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl cursor-pointer shadow-md transition-colors"
              >
                Save Package Prices
              </button>
            </div>
          </div>

          {/* Student Reports Moderation Table (Requirement 6) */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
            <h3 className="font-black text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <span>Reported Rental Listings & Safety Moderation</span>
            </h3>

            <div className="space-y-3">
              {listings.filter(l => (l.reports && l.reports.length > 0) || l.reportCount > 0).length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 bg-slate-50 dark:bg-slate-800/50 rounded-2xl">
                  ✓ No reported or suspicious rental listings at this time.
                </div>
              ) : (
                listings
                  .filter(l => (l.reports && l.reports.length > 0) || l.reportCount > 0)
                  .map(repListing => (
                    <div
                      key={repListing.id}
                      className="p-4 bg-rose-50/60 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-rose-700 dark:text-rose-300">
                            {repListing.title}
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-rose-200 dark:bg-rose-900 text-rose-800 dark:text-rose-200 text-[10px] font-bold">
                            {repListing.reportCount} Reports
                          </span>
                        </div>
                        <div className="text-slate-500">
                          Seller: {repListing.sellerName} • Tel: {repListing.sellerPhone}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleAdminModeration(repListing.id, 'dismiss_reports')}
                          className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer"
                        >
                          Dismiss Reports
                        </button>
                        <button
                          onClick={() => handleAdminModeration(repListing.id, 'suspend')}
                          className="px-3 py-1.5 bg-amber-500 text-white font-bold rounded-xl cursor-pointer"
                        >
                          Suspend
                        </button>
                        <button
                          onClick={() => handleAdminModeration(repListing.id, 'remove')}
                          className="px-3 py-1.5 bg-rose-600 text-white font-bold rounded-xl cursor-pointer"
                        >
                          Remove Listing
                        </button>
                      </div>
                    </div>
                  ))
              )}
            </div>
          </div>

          {/* Recent Revenue Transactions Table */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
            <h3 className="font-black text-base text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-indigo-600" />
              <span>Rental Listing Fee Transactions (Revenue Ledger)</span>
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                    <th className="py-2.5 font-bold">Ref / Time</th>
                    <th className="py-2.5 font-bold">Property Title</th>
                    <th className="py-2.5 font-bold">Seller Name</th>
                    <th className="py-2.5 font-bold">Package</th>
                    <th className="py-2.5 font-bold">Method</th>
                    <th className="py-2.5 font-bold text-right">Amount (RM)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {transactions.map((tx) => (
                    <tr key={tx.id} className="text-slate-700 dark:text-slate-300">
                      <td className="py-2.5 font-mono text-[11px] text-slate-400">
                        {tx.transactionRef}<br />
                        <span className="text-[10px] text-slate-500">{tx.timestamp}</span>
                      </td>
                      <td className="py-2.5 font-semibold text-slate-900 dark:text-slate-100 max-w-xs truncate">
                        {tx.rentalTitle}
                      </td>
                      <td className="py-2.5">{tx.sellerName}</td>
                      <td className="py-2.5">
                        <span className="px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold">
                          {tx.packageName}
                        </span>
                      </td>
                      <td className="py-2.5 text-slate-500">{tx.paymentMethod}</td>
                      <td className="py-2.5 font-black text-emerald-600 text-right">
                        RM {tx.amountRM}.00
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* SUB-TAB 4: STUDENT SAFETY & TENANCY GUIDE (Requirement 6) */}
      {activeSubTab === 'safety_guide' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 space-y-6 shadow-sm">
          
          <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-4">
            <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold uppercase">
              Student Tenant Safety & Legal Guide
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100">
              How to Rent Safely Around Polytechnic Campus
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Guidance prepared by Campus Corner in collaboration with the PSAS Commerce Dept to protect students from rental scams and unfair tenancy terms.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-700 dark:text-slate-300">
            
            <div className="p-5 bg-rose-50/70 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-900/50 space-y-3">
              <h3 className="font-bold text-sm text-rose-800 dark:text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>5 Red Flags of Student Rental Scams</span>
              </h3>
              <ul className="space-y-2 list-disc list-inside text-slate-600 dark:text-slate-300">
                <li><strong>Advance Online Transfer Demands:</strong> Seller refuses in-person viewing and insists on an upfront &ldquo;booking deposit&rdquo; before seeing the keys.</li>
                <li><strong>Unusually Low Pricing:</strong> Luxury aircond master room advertised for RM100/mo when market average is RM350+.</li>
                <li><strong>Absent Landlord with Remote Excuses:</strong> Claims to be out of the country and will courier the keys only after full payment.</li>
                <li><strong>No Written Tenancy Contract:</strong> Demands cash payment without providing a signed receipt or formal rental agreement.</li>
                <li><strong>Unverified Contact Numbers:</strong> Refuses phone calls and only communicates via disposable messaging accounts.</li>
              </ul>
            </div>

            <div className="p-5 bg-emerald-50/70 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-800/50 space-y-3">
              <h3 className="font-bold text-sm text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Standard Tenancy Checklist for PSAS Students</span>
              </h3>
              <ul className="space-y-2 list-disc list-inside text-slate-600 dark:text-slate-300">
                <li><strong>Physical Inspection:</strong> Always bring a friend or senior student along when visiting the house or room for viewing.</li>
                <li><strong>Verify Utilities Inclusions:</strong> Confirm whether water, electricity (aircond metering), and WiFi are included or split separately.</li>
                <li><strong>Deposit Standards:</strong> Typical student deposits in Behrang are 1 Month Security Deposit + 0.5 Month Utility Deposit (not exceeding 2+1).</li>
                <li><strong>Inspect Water & Electrical Fixtures:</strong> Test water heater pressure, aircond cooling, and socket points before moving in.</li>
                <li><strong>Housemate Compatibility:</strong> Confirm study hour expectations, quiet hours, and visitor policies with current tenants.</li>
              </ul>
            </div>

          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-2xl border border-indigo-200 dark:border-indigo-800 text-xs text-indigo-950 dark:text-indigo-200">
            <strong>Campus Legal Assistance:</strong> Encountering an unreasonable landlord or deposit retention dispute? Contact the Hal Ehwal Pelajar (HEP) Student Welfare Office at <code>05-456 3244</code> for mediation support.
          </div>

        </div>
      )}

      {/* MODALS */}

      {/* Rental Detail Modal */}
      <RentalDetailModal
        rental={selectedRentalForDetail}
        onClose={() => setSelectedRentalForDetail(null)}
        currentUser={currentUser}
        onStartChat={onStartChat}
        onOpenReportModal={(r) => setSelectedRentalForReport(r)}
      />

      {/* Add Rental Modal */}
      <AddRentalModal
        isOpen={isAddRentalModalOpen}
        onClose={() => setIsAddRentalModalOpen(false)}
        currentUser={currentUser}
        packages={packages}
        onCreateRental={handleCreateRental}
      />

      {/* Verification Modal */}
      <RentalVerificationModal
        isOpen={Boolean(selectedRentalForVerification)}
        onClose={() => setSelectedRentalForVerification(null)}
        rental={selectedRentalForVerification}
        currentUser={currentUser}
        onSubmitVerification={handleSubmitVerification}
      />

      {/* Report Modal */}
      <RentalReportModal
        isOpen={Boolean(selectedRentalForReport)}
        onClose={() => setSelectedRentalForReport(null)}
        rental={selectedRentalForReport}
        onSubmitReport={handleSubmitReport}
      />

      {/* Renew Modal */}
      {isRenewModalOpen && rentalToRenew && (
        <RentalCheckoutModal
          isOpen={isRenewModalOpen}
          onClose={() => {
            setIsRenewModalOpen(false);
            setRentalToRenew(null);
          }}
          packages={packages}
          selectedTier={rentalToRenew.packageTier}
          onSelectTier={() => {}}
          onConfirmPayment={handleConfirmRenew}
          currentUser={currentUser}
          isRenewal={true}
          rentalTitle={rentalToRenew.title}
        />
      )}

    </div>
  );
};
