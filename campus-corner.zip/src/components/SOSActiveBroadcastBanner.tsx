import React, { useState } from 'react';
import { 
  AlertTriangle, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  ChevronRight, 
  X, 
  Info, 
  Radio, 
  PhoneCall 
} from 'lucide-react';
import { CampusSOSAlert } from '../types';

interface SOSActiveBroadcastBannerProps {
  alerts: CampusSOSAlert[];
  onOpenSOSView: (alertId?: string) => void;
}

export const SOSActiveBroadcastBanner: React.FC<SOSActiveBroadcastBannerProps> = ({
  alerts,
  onOpenSOSView,
}) => {
  const [isDismissed, setIsDismissed] = useState<boolean>(false);

  // Filter for currently active alerts
  const activeAlerts = alerts.filter((a) => a.status === 'active');

  if (activeAlerts.length === 0 || isDismissed) {
    return null;
  }

  const latestAlert = activeAlerts[0];

  return (
    <div 
      id="campus_sos_broadcast_banner"
      className="bg-gradient-to-r from-red-700 via-rose-700 to-red-800 text-white shadow-lg border-b-2 border-red-400/50 px-4 py-3 sm:py-3.5 animate-slide-down"
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        
        {/* Left Indicator & Info */}
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0 animate-pulse">
            <AlertTriangle className="w-5 h-5 text-white" />
          </div>

          <div className="space-y-0.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-black text-xs uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-red-200 animate-ping" />
                🚨 CAMPUS SOS ALERT
              </span>
              {latestAlert.isDemo && (
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  Demo Alert — Not A Real Emergency
                </span>
              )}
              <span className="text-[11px] text-red-200 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {latestAlert.timestamp}
              </span>
            </div>

            <p className="text-xs font-semibold text-white/95 leading-snug">
              &quot;An emergency has been reported near your location.&quot; • <span className="font-bold text-amber-200">{latestAlert.category}</span> at <span className="underline decoration-red-300">{latestAlert.locationName}</span>
            </p>

            <p className="text-[11px] text-red-100/90 font-medium">
              ⚠️ <span className="font-semibold">Safety Notice:</span> &quot;Stay safe. Avoid the area if necessary and contact the appropriate emergency service or campus authority.&quot;
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 self-end md:self-center shrink-0">
          <button
            onClick={() => onOpenSOSView(latestAlert.id)}
            className="px-3.5 py-1.5 bg-white hover:bg-red-50 text-red-700 font-black text-xs rounded-xl shadow-xs transition-transform active:scale-95 flex items-center gap-1.5 cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>VIEW LOCATION & GUIDE</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsDismissed(true)}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
            title="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
