import React, { useState } from 'react';
import { 
  X, 
  Check, 
  Crown, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight, 
  Zap, 
  Building, 
  TrendingUp, 
  CheckCircle2, 
  QrCode, 
  CreditCard, 
  Wallet, 
  Layers,
  HelpCircle,
  Clock,
  Award
} from 'lucide-react';
import { User, SubscriptionTier, BillingCycle, SubscriptionPlanConfig } from '../types';
import { SUBSCRIPTION_PLANS } from '../data/mockData';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onUpgradeSuccess: (updatedUser: User) => void;
  defaultTier?: SubscriptionTier;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUpgradeSuccess,
  defaultTier = 'premium'
}) => {
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier>(
    (currentUser.subscriptionTier as SubscriptionTier) || defaultTier
  );
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('semester');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'DuitNow QR' | 'Campus Student E-Wallet' | 'FPX Online Banking'>('Campus Student E-Wallet');
  const [step, setStep] = useState<'select' | 'checkout' | 'success'>('select');
  const [successInfo, setSuccessInfo] = useState<{ planName: string; ref: string; price: number } | null>(null);

  if (!isOpen) return null;

  const currentPlan = SUBSCRIPTION_PLANS.find(p => p.tier === selectedTier) || SUBSCRIPTION_PLANS[1];

  const getTierPrice = (plan: SubscriptionPlanConfig) => {
    if (plan.tier === 'free') return 0;
    if (billingCycle === 'monthly') return plan.monthlyPriceRM;
    return plan.semesterPriceRM;
  };

  const getMonthlyEquivalent = (plan: SubscriptionPlanConfig) => {
    if (plan.tier === 'free') return 0;
    if (billingCycle === 'monthly') return plan.monthlyPriceRM;
    return Math.round((plan.semesterPriceRM / 6) * 100) / 100;
  };

  const handleProceedToCheckout = () => {
    if (selectedTier === 'free') {
      // Free plan requires no payment step
      executeUpgrade('Free');
    } else {
      setStep('checkout');
    }
  };

  const executeUpgrade = async (selectedPayment: string) => {
    setIsProcessing(true);
    try {
      const response = await fetch('/api/subscriptions/upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          tier: selectedTier,
          billingCycle,
          paymentMethod: selectedPayment,
          studentMatric: currentUser.studentId || 'N/A',
          department: currentUser.department || 'General',
          course: (currentUser as any).diplomaCourse || currentUser.course || 'General',
          semester: currentUser.semester || 1,
          userName: currentUser.name || 'Student Subscriber',
        }),
      });

      const data = await response.json();
      if (data.success) {
        const updatedUser: User = {
          ...currentUser,
          subscriptionTier: selectedTier,
          subscriptionPlanName: currentPlan.name,
          subscriptionBillingCycle: billingCycle,
          subscriptionExpiresAt: data.subscription.endDate,
          subscriptionStatus: 'active',
          subscriptionAutoRenew: true,
        };

        setSuccessInfo({
          planName: currentPlan.name,
          ref: data.subscription.transactionRef,
          price: data.subscription.pricePaidRM,
        });
        setStep('success');
        onUpgradeSuccess(updatedUser);
      }
    } catch (err) {
      console.error('Failed to upgrade subscription:', err);
      // Fallback local update
      const updatedUser: User = {
        ...currentUser,
        subscriptionTier: selectedTier,
        subscriptionPlanName: currentPlan.name,
        subscriptionBillingCycle: billingCycle,
        subscriptionExpiresAt: '2027-02-28',
        subscriptionStatus: 'active',
        subscriptionAutoRenew: true,
      };
      setSuccessInfo({
        planName: currentPlan.name,
        ref: `SUB-FALLBACK-${Date.now().toString().slice(-6)}`,
        price: getTierPrice(currentPlan),
      });
      setStep('success');
      onUpgradeSuccess(updatedUser);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="subscription_modal_container"
        className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200/80 my-8 transition-all"
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-900 text-white p-6 sm:p-8">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5 mb-2">
            <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
              <Crown className="w-3 h-3 text-slate-950 fill-slate-950" />
              Polytechnic Seller Plans
            </span>
            <span className="text-xs text-indigo-300 font-medium">
              Politeknik Sultan Azlan Shah (PSAS)
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Supercharge Your Campus Sales & Rentals
          </h2>
          <p className="text-slate-300 text-sm mt-1.5 max-w-2xl">
            Choose the plan tailored for student budgets. Unlock higher listing limits, top search ranking, direct buyer inquiries, and Gemini AI price valuations.
          </p>

          {/* Billing Cycle Switcher */}
          {step === 'select' && (
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <div className="bg-white/10 p-1 rounded-xl flex items-center gap-1 border border-white/15">
                <button
                  type="button"
                  onClick={() => setBillingCycle('semester')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    billingCycle === 'semester'
                      ? 'bg-amber-400 text-slate-950 shadow-md font-black'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Semester Pass (6 Months)
                  <span className="ml-1.5 bg-emerald-700 text-white text-[9px] px-1.5 py-0.2 rounded-full">
                    SAVE 38%
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setBillingCycle('monthly')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    billingCycle === 'monthly'
                      ? 'bg-white text-slate-900 shadow-md font-black'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Monthly Pay
                </button>
              </div>
              <span className="text-xs text-amber-300 font-medium flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Affordable student pricing from only RM 3.00/month
              </span>
            </div>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8">
          {step === 'select' && (
            <div>
              {/* Current Status banner if user already has a plan */}
              {currentUser.subscriptionTier && currentUser.subscriptionTier !== 'free' && (
                <div className="mb-6 bg-indigo-50/80 border border-indigo-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-indigo-700 uppercase tracking-wider">
                        Current Active Plan
                      </div>
                      <div className="text-sm font-bold text-slate-900">
                        {currentUser.subscriptionPlanName || 'Premium Active Seller'} ({currentUser.subscriptionBillingCycle || 'semester'} cycle)
                      </div>
                      <div className="text-xs text-slate-500">
                        Valid until {currentUser.subscriptionExpiresAt || 'Feb 2027'} • Auto-renewal active
                      </div>
                    </div>
                  </div>
                  <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Active Subscriber
                  </span>
                </div>
              )}

              {/* 3 Tier Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {SUBSCRIPTION_PLANS.map((plan) => {
                  const isSelected = selectedTier === plan.tier;
                  const isCurrent = currentUser.subscriptionTier === plan.tier;
                  const price = getTierPrice(plan);
                  const monthlyEq = getMonthlyEquivalent(plan);

                  return (
                    <div
                      key={plan.tier}
                      id={`plan_card_${plan.tier}`}
                      onClick={() => setSelectedTier(plan.tier)}
                      className={`relative rounded-2xl p-5 sm:p-6 transition-all cursor-pointer border flex flex-col justify-between ${
                        isSelected
                          ? 'border-indigo-600 ring-2 ring-indigo-600/30 bg-indigo-50/20 shadow-lg scale-[1.02]'
                          : 'border-slate-200/90 hover:border-indigo-300 hover:bg-slate-50/60 shadow-xs'
                      }`}
                    >
                      {/* Popular / Recommended Badge */}
                      {plan.recommended && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-[10px] font-black uppercase tracking-wider px-3 py-0.5 rounded-full shadow-md flex items-center gap-1">
                          <Crown className="w-3 h-3" />
                          Most Popular at PSAS
                        </div>
                      )}

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md ${
                            plan.tier === 'free' ? 'bg-slate-100 text-slate-700' :
                            plan.tier === 'premium' ? 'bg-indigo-100 text-indigo-800' :
                            'bg-purple-100 text-purple-800'
                          }`}>
                            {plan.badgeLabel}
                          </span>
                          {isCurrent && (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                              Your Plan
                            </span>
                          )}
                        </div>

                        <h3 className="text-xl font-black text-slate-900">
                          {plan.name}
                        </h3>
                        <p className="text-xs text-slate-500 mt-1 min-h-[34px]">
                          {plan.tagline}
                        </p>

                        {/* Price Block */}
                        <div className="mt-4 mb-4 pb-4 border-b border-slate-100">
                          <div className="flex items-baseline gap-1">
                            <span className="text-3xl font-black text-slate-900 tracking-tight">
                              RM {price.toFixed(2)}
                            </span>
                            <span className="text-xs text-slate-500 font-medium">
                              /{billingCycle === 'monthly' ? 'month' : 'semester (6 mos)'}
                            </span>
                          </div>
                          {billingCycle === 'semester' && plan.tier !== 'free' && (
                            <div className="text-[11px] font-semibold text-emerald-600 mt-1">
                              Equivalent to RM {monthlyEq.toFixed(2)}/mo
                            </div>
                          )}
                          {plan.tier === 'free' && (
                            <div className="text-[11px] font-medium text-slate-400 mt-1">
                              Permanently free for PSAS students
                            </div>
                          )}
                        </div>

                        {/* Key Quotas highlight */}
                        <div className="space-y-2 mb-5 text-xs text-slate-700 bg-slate-50/80 p-3 rounded-xl border border-slate-100">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-500">Marketplace Items:</span>
                            <span className="font-bold text-slate-900">
                              {plan.maxMarketplaceListings === -1 ? 'Unlimited' : `${plan.maxMarketplaceListings} listings`}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-500">Hostel & Room Rentals:</span>
                            <span className="font-bold text-slate-900">
                              {plan.maxRentalListings === -1 ? 'Unlimited' : `${plan.maxRentalListings} listings`}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-500">Search Ranking:</span>
                            <span className="font-bold text-indigo-700">
                              {plan.searchBoostMultiplier}x Visibility Boost
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-500">Review Queue:</span>
                            <span className="font-bold text-slate-900">
                              {plan.verificationTurnaround}
                            </span>
                          </div>
                        </div>

                        {/* Feature Checklist */}
                        <div className="space-y-2.5 mb-6">
                          {plan.features.map((feat, idx) => (
                            <div key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{feat}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Select Button */}
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedTier(plan.tier);
                          handleProceedToCheckout();
                        }}
                        className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          isCurrent
                            ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                            : isSelected
                            ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/20'
                            : 'bg-slate-900 hover:bg-indigo-600 text-white'
                        }`}
                      >
                        {isCurrent ? 'Current Plan (Renew)' : `Select ${plan.name}`}
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Bottom Assurance Note */}
              <div className="mt-8 bg-slate-50 rounded-2xl p-4 border border-slate-200/70 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>
                    <strong>Student Friendly Guarantee:</strong> Politeknik subsidized pricing. Cancel or pause subscription anytime before next semester with zero cancellation fees.
                  </span>
                </div>
                <div className="flex items-center gap-2 font-bold text-slate-700 shrink-0">
                  <span>DuitNow QR</span> • <span>Touch n Go</span> • <span>FPX Banking</span>
                </div>
              </div>
            </div>
          )}

          {step === 'checkout' && (
            <div className="max-w-xl mx-auto py-2">
              <div className="text-center mb-6">
                <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto mb-3">
                  <CreditCard className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-black text-slate-900">
                  Review & Complete Subscription
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Politeknik Sultan Azlan Shah (PSAS) Secure Student Checkout
                </p>
              </div>

              {/* Order Summary Box */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200/80 mb-6 space-y-3">
                <div className="flex justify-between items-center text-sm font-bold text-slate-900">
                  <span>{currentPlan.name} ({currentPlan.badgeLabel})</span>
                  <span className="text-indigo-600 text-base">RM {getTierPrice(currentPlan).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Billing Period:</span>
                  <span className="font-semibold text-slate-800">
                    {billingCycle === 'monthly' ? '1 Month Recurring' : '1 Semester (6 Months Pass)'}
                  </span>
                </div>
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Student Subscriber:</span>
                  <span className="font-semibold text-slate-800">
                    {currentUser.name ? `${currentUser.name} (${currentUser.studentId || 'ID not set'})` : 'Student (Profile Not Set)'}
                  </span>
                </div>
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Department & Course:</span>
                  <span className="font-semibold text-slate-800">
                    {currentUser.department || 'Not specified'}
                  </span>
                </div>
                <div className="border-t border-slate-200 pt-3 flex justify-between items-center text-base font-black text-slate-900">
                  <span>Total Amount Payable:</span>
                  <span className="text-xl text-indigo-700">RM {getTierPrice(currentPlan).toFixed(2)}</span>
                </div>
              </div>

              {/* Payment Gateway Selection */}
              <div className="space-y-3 mb-6">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Select Student Payment Method:
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Campus Student E-Wallet')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      paymentMethod === 'Campus Student E-Wallet'
                        ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Wallet className="w-5 h-5 text-indigo-600 mb-1.5" />
                    <div className="text-xs font-bold text-slate-900">Student E-Wallet</div>
                    <div className="text-[10px] text-slate-500">Touch n Go / GrabPay</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('DuitNow QR')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      paymentMethod === 'DuitNow QR'
                        ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <QrCode className="w-5 h-5 text-rose-600 mb-1.5" />
                    <div className="text-xs font-bold text-slate-900">DuitNow QR</div>
                    <div className="text-[10px] text-slate-500">Instant scan all banks</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('FPX Online Banking')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      paymentMethod === 'FPX Online Banking'
                        ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Building className="w-5 h-5 text-emerald-600 mb-1.5" />
                    <div className="text-xs font-bold text-slate-900">FPX Online</div>
                    <div className="text-[10px] text-slate-500">Maybank, CIMB, Bank Islam</div>
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep('select')}
                  className="flex-1 py-3 px-4 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Back to Plans
                </button>
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={() => executeUpgrade(paymentMethod)}
                  className="flex-2 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black shadow-md shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Processing Verification...
                    </>
                  ) : (
                    <>
                      Confirm & Pay RM {getTierPrice(currentPlan).toFixed(2)}
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {step === 'success' && successInfo && (
            <div className="max-w-md mx-auto py-6 text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4 animate-in zoom-in-50 duration-300">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-black text-slate-900">
                Subscription Activated!
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                You are now subscribed to <strong className="text-indigo-600">{successInfo.planName}</strong>
              </p>

              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 my-5 text-left text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Transaction Ref:</span>
                  <span className="font-mono font-bold text-slate-800">{successInfo.ref}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Plan Tier:</span>
                  <span className="font-bold text-indigo-700 uppercase">{selectedTier}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Amount Paid:</span>
                  <span className="font-bold text-slate-900">RM {successInfo.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Benefits Unlocked:</span>
                  <span className="font-bold text-emerald-600">Active Instantly Across Campus</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setStep('select');
                  onClose();
                }}
                className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
              >
                Continue to Campus Corner
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
