import React, { useState, useEffect } from 'react';
import { CampusLinkLogo } from './CampusLinkLogo';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, CheckCircle2, Laptop, Smartphone, Sparkles } from 'lucide-react';

interface CampusLinkSplashScreenProps {
  onComplete: () => void;
  appName?: string;
}

export const CampusLinkSplashScreen: React.FC<CampusLinkSplashScreenProps> = ({
  onComplete,
}) => {
  const [progress, setProgress] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  
  // Layout mode override: 'auto' (responsive: landscape on laptop, portrait on mobile) or explicit
  const [viewMode, setViewMode] = useState<'auto' | 'landscape' | 'portrait'>('auto');

  useEffect(() => {
    // Smooth progress loading from 0% all the way to 100%
    const startTime = Date.now();
    const duration = 2800; // ~2.8 seconds for smooth realistic load

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const nextProgress = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(nextProgress);

      if (nextProgress >= 100) {
        clearInterval(interval);
        setIsFinished(true);
        // Small pause at 100% so user sees completion before entering
        setTimeout(() => {
          onComplete();
        }, 500);
      }
    }, 30);

    return () => clearInterval(interval);
  }, [onComplete]);

  // Milestone labels matching loading progression
  const getStageLabel = () => {
    if (progress < 25) return 'Initializing Campus Link Core...';
    if (progress < 55) return 'Connecting student services & marketplace...';
    if (progress < 85) return 'Syncing campus community network...';
    if (progress < 100) return 'Finalizing student workspace...';
    return 'Ready! Entering campus community...';
  };

  return (
    <AnimatePresence>
      <motion.div
        id="campus-link-splash-screen"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0, scale: 0.98 }}
        transition={{ duration: 0.4 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/95 sm:bg-slate-950/85 backdrop-blur-md p-3 sm:p-6 overflow-y-auto select-none"
      >
        {/* Top Controls Bar: View mode toggle & Skip */}
        <div className="fixed top-4 right-4 sm:top-6 sm:right-6 z-20 flex items-center gap-2">
          {/* View mode toggle (handy for previewing mobile vs laptop layout on any screen) */}
          <div className="hidden sm:flex items-center bg-slate-800/80 backdrop-blur-md border border-slate-700/60 rounded-full p-1 text-xs text-slate-300">
            <button
              type="button"
              onClick={() => setViewMode('auto')}
              className={`px-2.5 py-1 rounded-full font-medium transition-all ${
                viewMode === 'auto' ? 'bg-blue-600 text-white shadow-xs' : 'hover:text-white'
              }`}
              title="Responsive: Landscape for laptop, Portrait for mobile"
            >
              Auto Responsive
            </button>
            <button
              type="button"
              onClick={() => setViewMode('landscape')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full font-medium transition-all ${
                viewMode === 'landscape' ? 'bg-blue-600 text-white shadow-xs' : 'hover:text-white'
              }`}
              title="Force Laptop Landscape layout"
            >
              <Laptop className="w-3.5 h-3.5" />
              <span>Laptop</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('portrait')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full font-medium transition-all ${
                viewMode === 'portrait' ? 'bg-blue-600 text-white shadow-xs' : 'hover:text-white'
              }`}
              title="Force Mobile Portrait layout"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Mobile</span>
            </button>
          </div>

          {/* Skip Button */}
          <button
            id="splash-skip-btn"
            type="button"
            onClick={onComplete}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-md border border-white/15 transition-colors cursor-pointer shadow-sm"
          >
            <span>Skip</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* ========================================================================= */}
        {/* RESPONSIVE CONTAINER:                                                     */}
        {/* - On Mobile: Portrait Layout (matching Screenshot 2026-09-22 101423.png)  */}
        {/* - On Laptop: Landscape Layout (Widescreen Dual-Column Layout)             */}
        {/* ========================================================================= */}

        {/* 1. LAPTOP LANDSCAPE LAYOUT (Visible when viewMode === 'landscape' OR viewMode === 'auto' on md+ screens) */}
        <div
          className={`w-full max-w-4xl lg:max-w-5xl bg-white dark:bg-slate-900 rounded-3xl lg:rounded-4xl shadow-[0_25px_70px_-15px_rgba(0,110,230,0.35)] border border-blue-100/90 dark:border-slate-800 p-8 lg:p-12 relative overflow-hidden ${
            viewMode === 'portrait'
              ? 'hidden'
              : viewMode === 'landscape'
              ? 'block'
              : 'hidden md:block'
          }`}
        >
          {/* Ambient Decorative Glow */}
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-gradient-to-br from-blue-100/70 via-cyan-50/40 to-transparent dark:from-blue-900/20 dark:to-transparent rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-80 h-80 bg-gradient-to-tr from-sky-100/50 to-transparent dark:from-sky-950/20 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 lg:gap-14">
            
            {/* LEFT COLUMN: Large High-Resolution Brand Emblem & Identity */}
            <div className="w-full md:w-[46%] flex flex-col items-center justify-center text-center md:border-r border-slate-100 dark:border-slate-800 md:pr-8 lg:pr-12">
              {/* Badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 text-[#0080f0] border border-blue-200/60 dark:border-blue-800/60 text-[11px] font-bold tracking-wider uppercase mb-2">
                <Sparkles className="w-3 h-3 text-[#0080f0]" />
                <span>EST. 2026 • OFFICIAL PLATFORM</span>
              </div>

              {/* The Vector Emblem */}
              <div className="w-48 h-40 sm:w-56 sm:h-44 lg:w-64 lg:h-48 flex items-center justify-center py-2">
                <CampusLinkLogo variant="emblem" size="100%" />
              </div>

              {/* Brand Typography */}
              <div className="mt-1 w-full max-w-xs flex flex-col items-center">
                {/* CAMPUS LINK */}
                <div className="flex items-center text-2xl lg:text-3xl font-black tracking-tight leading-none">
                  <span className="text-[#0c1e38] dark:text-slate-100">CAMPUS</span>
                  <span className="text-[#0080f0] ml-2">LINK</span>
                </div>

                {/* — TECHNOLOGIES — */}
                <div className="flex items-center justify-center gap-2.5 w-full mt-2">
                  <div className="h-[1.5px] flex-1 bg-gradient-to-r from-transparent to-[#0080f0]" />
                  <span className="text-[11px] font-extrabold text-[#0c1e38] dark:text-slate-200 tracking-[0.28em] uppercase">
                    TECHNOLOGIES
                  </span>
                  <div className="h-[1.5px] flex-1 bg-gradient-to-l from-transparent to-[#0080f0]" />
                </div>

                {/* SDN. BHD */}
                <div className="mt-1.5 text-[10px] font-extrabold text-[#0080f0] tracking-[0.24em] uppercase">
                  SDN. BHD
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN: Slogan, Loading Progress & Connect Status */}
            <div className="w-full md:w-[54%] flex flex-col justify-center space-y-6 md:pl-2">
              
              {/* Slogan with Capital 'S' in Students and 'S' in Success */}
              <div className="space-y-1 text-left">
                <div className="text-3xl lg:text-4xl font-black tracking-tight leading-[1.15]">
                  <span className="text-[#0080f0]">Made</span>{' '}
                  <span className="text-[#0c1e38] dark:text-slate-100">for Students</span>
                </div>
                <div className="text-3xl lg:text-4xl font-black tracking-tight leading-[1.15]">
                  <span className="text-[#0080f0]">Built</span>{' '}
                  <span className="text-[#0c1e38] dark:text-slate-100">for Success</span>
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 font-medium pt-2">
                  All-in-one digital ecosystem connecting campus marketplace, academic schedules, events, and student communities.
                </p>
              </div>

              {/* Progress & Status Card */}
              <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-5 border border-slate-200/70 dark:border-slate-700/60 space-y-3">
                <div className="flex items-center justify-between text-sm font-bold">
                  <div className="flex items-center gap-2 text-[#0c1e38] dark:text-slate-200">
                    {isFinished ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <span className="relative flex h-2.5 w-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-600"></span>
                      </span>
                    )}
                    <span>Loading...</span>
                  </div>
                  <span className="font-mono text-blue-600 dark:text-blue-400 font-extrabold text-base">
                    {progress}%
                  </span>
                </div>

                {/* Progress Bar Track */}
                <div className="w-full h-3.5 bg-slate-200 dark:bg-slate-700 rounded-full p-0.5 overflow-hidden shadow-inner">
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-[#0066e0] via-[#0096f2] to-[#00d4ff] shadow-sm"
                    style={{ width: `${progress}%` }}
                    initial={{ width: '0%' }}
                    animate={{ width: `${progress}%` }}
                    transition={{ ease: 'easeOut', duration: 0.1 }}
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="font-medium text-slate-600 dark:text-slate-300">
                    {getStageLabel()}
                  </span>
                  <span>Please wait...</span>
                </div>
              </div>

              {/* Prompt Description & Fast Enter Action */}
              <div className="flex items-center justify-between pt-1">
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs leading-relaxed">
                  Please wait while we connect you to your campus community
                </p>
                <button
                  type="button"
                  onClick={onComplete}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-md shadow-blue-500/20 cursor-pointer hover:translate-x-0.5"
                >
                  <span>{isFinished ? 'Enter Campus' : 'Enter Portal'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>

          </div>
        </div>

        {/* 2. MOBILE PORTRAIT LAYOUT (Visible when viewMode === 'portrait' OR viewMode === 'auto' on < md screens) */}
        <div
          className={`w-full max-w-[400px] min-h-[92vh] sm:min-h-[780px] sm:max-h-[860px] bg-white dark:bg-slate-900 flex flex-col justify-between items-center px-6 py-9 sm:py-11 rounded-[38px] shadow-[0_25px_70px_-15px_rgba(0,110,230,0.35)] border border-slate-200/90 dark:border-slate-800 relative overflow-hidden select-none ${
            viewMode === 'landscape'
              ? 'hidden'
              : viewMode === 'portrait'
              ? 'flex'
              : 'flex md:hidden'
          }`}
        >
          {/* Top Subtle Ambient Glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-gradient-to-b from-blue-100/70 dark:from-blue-900/30 to-transparent rounded-full blur-3xl pointer-events-none" />

          {/* 1. TOP SECTION: Corporate Vector Emblem & Brand Typography */}
          <div className="flex flex-col items-center text-center mt-3 sm:mt-5 w-full z-10">
            {/* The Emblem */}
            <div className="w-44 h-36 flex items-center justify-center">
              <CampusLinkLogo variant="emblem" size={175} />
            </div>

            {/* Typography Lockup */}
            <div className="flex flex-col items-center mt-1 w-full">
              {/* — TECHNOLOGIES — with sleek divider lines */}
              <div className="flex items-center justify-center gap-3 w-full max-w-[240px] my-1">
                <div className="h-[1.5px] flex-1 bg-gradient-to-r from-transparent via-[#0096f2]/60 to-[#0096f2]" />
                <span className="text-[11px] font-extrabold tracking-[0.28em] text-[#132c52] dark:text-slate-200 uppercase">
                  TECHNOLOGIES
                </span>
                <div className="h-[1.5px] flex-1 bg-gradient-to-l from-transparent via-[#0096f2]/60 to-[#0096f2]" />
              </div>

              {/* CAMPUS LINK */}
              <div className="flex items-center justify-center text-[28px] font-black tracking-tight leading-none mt-1">
                <span className="text-[#0e213d] dark:text-white tracking-wide">CAMPUS</span>
                <span className="text-[#008bf2] ml-2 tracking-wide">LINK</span>
              </div>

              {/* — EST. 2026 — */}
              <div className="flex items-center justify-center gap-3 w-full max-w-[170px] mt-2">
                <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-[#008bf2]/50" />
                <span className="text-[10px] font-bold text-[#008bf2] tracking-[0.22em] uppercase">
                  EST. 2026
                </span>
                <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-[#008bf2]/50" />
              </div>
            </div>
          </div>

          {/* 2. MIDDLE SECTION: The Signature Tagline */}
          {/* Explicit User Requirement: The word s in students and s in success is capital letters */}
          <div className="flex flex-col items-center text-center my-6 z-10">
            <div className="text-[26px] sm:text-[28px] leading-[1.25] tracking-tight font-extrabold">
              <div>
                <span className="text-[#008df2]">Made</span>{' '}
                <span className="text-[#0e213d] dark:text-slate-100">for Students</span>
              </div>
              <div className="mt-1">
                <span className="text-[#008df2]">Built</span>{' '}
                <span className="text-[#0e213d] dark:text-slate-100">for Success</span>
              </div>
            </div>
          </div>

          {/* 3. BOTTOM SECTION: Loading Indicator and Status */}
          <div className="flex flex-col items-center text-center w-full mb-4 z-10">
            {/* Loading text with status */}
            <div className="flex items-center gap-1.5 text-base font-bold text-[#0e213d] dark:text-slate-200">
              {isFinished ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 animate-bounce" />
                  <span>Ready! Entering campus...</span>
                </>
              ) : (
                <span>Loading... {progress}%</span>
              )}
            </div>

            {/* Prompt description */}
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1.5 max-w-[270px] leading-relaxed">
              Please wait while we connect you to your campus community
            </p>

            {/* Progress Bar Track: loads from first (0%) to the end (100%) */}
            <div className="w-full max-w-[280px] h-3.5 bg-slate-100 dark:bg-slate-800 rounded-full p-0.5 mt-5 border border-slate-200/80 dark:border-slate-700 shadow-inner overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-[#006ae8] via-[#009bf2] to-[#00c8ff] shadow-sm"
                style={{ width: `${progress}%` }}
                initial={{ width: '0%' }}
                animate={{ width: `${progress}%` }}
                transition={{ ease: 'easeOut', duration: 0.1 }}
              />
            </div>

            {/* Stage sublabel */}
            <div className="text-[11px] font-medium text-slate-400 dark:text-slate-500 mt-2">
              {getStageLabel()}
            </div>

            {/* Subtle bottom trademark */}
            <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-5 tracking-wide">
              Campus Link Technologies Sdn. Bhd.
            </div>
          </div>

        </div>

      </motion.div>
    </AnimatePresence>
  );
};

export default CampusLinkSplashScreen;
