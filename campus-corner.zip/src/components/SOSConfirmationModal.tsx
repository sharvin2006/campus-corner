import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  X, 
  MapPin, 
  ShieldAlert, 
  PhoneCall, 
  CheckCircle2, 
  EyeOff, 
  Clock, 
  Users, 
  Radio, 
  Volume2, 
  Car, 
  Flame, 
  HeartPulse, 
  HelpCircle 
} from 'lucide-react';
import { EmergencyCategory, User, EmergencyContact } from '../types';

interface SOSConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmSOS: (data: {
    category: EmergencyCategory;
    description: string;
    locationName: string;
    coordinates?: { latitude: number; longitude: number; accuracy?: number };
    isAnonymous: boolean;
    isDemo: boolean;
    notifyContacts: boolean;
    notifyAuthorities: boolean;
  }) => void;
  currentUser: User;
  isDemoMode: boolean;
}

const CATEGORIES: { label: EmergencyCategory; icon: any; color: string; desc: string }[] = [
  { label: 'Accident', icon: Car, color: 'text-amber-600 bg-amber-50 border-amber-200', desc: 'Vehicle / campus road collision' },
  { label: 'Medical Emergency', icon: HeartPulse, color: 'text-rose-600 bg-rose-50 border-rose-200', desc: 'Injury, fainting, or acute illness' },
  { label: 'Fire', icon: Flame, color: 'text-orange-600 bg-orange-50 border-orange-200', desc: 'Smoke, electrical spark or fire' },
  { label: 'Safety Emergency', icon: ShieldAlert, color: 'text-red-600 bg-red-50 border-red-200', desc: 'Threat, harassment, or unsafe perimeter' },
  { label: 'Other Emergency', icon: HelpCircle, color: 'text-purple-600 bg-purple-50 border-purple-200', desc: 'General urgent campus assistance' },
];

const CAMPUS_PRESET_LOCATIONS = [
  'PSAS Main Library Lobby & Entrance',
  'Commerce Department Block B (JKA/JPH)',
  'Student Centre Pavilion & Cafeteria',
  'Kamsis Residential Block C / Carpark',
  'Engineering Workshop Complex (JKE/JKM)',
  'Main Campus Gate & Security Post',
];

export const SOSConfirmationModal: React.FC<SOSConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirmSOS,
  currentUser,
  isDemoMode: initialDemoMode,
}) => {
  const [countdown, setCountdown] = useState<number>(4);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<EmergencyCategory>('Other Emergency');
  const [customDescription, setCustomDescription] = useState<string>('');
  const [selectedLocation, setSelectedLocation] = useState<string>('PSAS Main Library Lobby & Entrance');
  const [coords, setCoords] = useState<{ latitude: number; longitude: number; accuracy?: number } | undefined>();
  const [locatingStatus, setLocatingStatus] = useState<'idle' | 'locating' | 'success' | 'failed'>('idle');
  const [isAnonymous, setIsAnonymous] = useState<boolean>(currentUser.sosPreferences?.anonymousAlerts || false);
  const [isDemo, setIsDemo] = useState<boolean>(true); // Default to safe demo mode
  const [notifyContacts, setNotifyContacts] = useState<boolean>(currentUser.sosPreferences?.autoNotifySelectedContacts ?? true);
  const [notifyAuthorities, setNotifyAuthorities] = useState<boolean>(true);

  // Auto GPS location fetching when modal opens
  useEffect(() => {
    if (isOpen) {
      setCountdown(4);
      setIsPaused(false);
      setIsDemo(initialDemoMode);

      if ('geolocation' in navigator) {
        setLocatingStatus('locating');
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            setCoords({
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
              accuracy: Math.round(pos.coords.accuracy),
            });
            setLocatingStatus('success');
          },
          () => {
            setLocatingStatus('failed');
          },
          { enableHighAccuracy: true, timeout: 4000 }
        );
      }
    }
  }, [isOpen, initialDemoMode]);

  // Countdown timer effect
  useEffect(() => {
    if (!isOpen || isPaused) return;

    if (countdown <= 0) {
      handleFinalSend();
      return;
    }

    const timer = setTimeout(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [isOpen, countdown, isPaused]);

  if (!isOpen) return null;

  const handleFinalSend = () => {
    onConfirmSOS({
      category: selectedCategory,
      description: customDescription,
      locationName: selectedLocation,
      coordinates: coords,
      isAnonymous,
      isDemo,
      notifyContacts,
      notifyAuthorities,
    });
  };

  const activeContactsCount = currentUser.emergencyContacts?.filter((c) => c.autoNotify).length || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div 
        id="sos_confirmation_dialog"
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border-2 border-red-500/30 overflow-hidden text-slate-900 dark:text-slate-100 flex flex-col max-h-[90vh]"
      >
        {/* Top Emergency Bar */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-xs animate-pulse">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-wide uppercase">Send SOS Alert?</h2>
                {isDemo && (
                  <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                    Demo Mode
                  </span>
                )}
              </div>
              <p className="text-xs text-red-100 font-medium">
                Fast broadcast to campus responders & emergency contacts
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/20 hover:bg-black/40 flex items-center justify-center transition-colors text-white cursor-pointer"
            title="Cancel"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 text-xs">
          
          {/* Countdown & Dispatch Notice */}
          <div className="bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 rounded-2xl p-4 text-center space-y-3">
            <div className="flex items-center justify-center gap-2 text-red-700 dark:text-red-400 font-bold text-sm">
              <Radio className="w-4 h-4 animate-ping" />
              <span>
                {countdown > 0 
                  ? `Auto-sending in ${countdown}s (Tap below to send immediately)` 
                  : 'Broadcasting emergency signal...'}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-red-200 dark:bg-red-900/50 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-red-600 h-full transition-all duration-1000 ease-linear rounded-full"
                style={{ width: `${((4 - countdown) / 4) * 100}%` }}
              />
            </div>

            <p className="text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
              &quot;An emergency alert will be shared with nearby Campus Corner users and your selected emergency contacts.&quot;
            </p>
          </div>

          {/* Emergency Category Selector */}
          <div className="space-y-2">
            <label className="font-bold text-slate-800 dark:text-slate-200 block text-xs">
              Select Emergency Category:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {CATEGORIES.map((cat) => {
                const IconComponent = cat.icon;
                const isSelected = selectedCategory === cat.label;
                return (
                  <button
                    key={cat.label}
                    type="button"
                    onClick={() => {
                      setSelectedCategory(cat.label);
                      setIsPaused(true); // User is fine-tuning
                    }}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? `${cat.color} font-bold ring-2 ring-red-500 shadow-xs scale-[1.01]`
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                    }`}
                  >
                    <div className="p-1.5 rounded-lg bg-white dark:bg-slate-900 shadow-2xs shrink-0">
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs truncate">{cat.label}</div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{cat.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Location Selection & GPS */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-red-500" />
                <span>Incident Location:</span>
              </label>
              {locatingStatus === 'success' && coords && (
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> GPS Acquired (±{coords.accuracy}m)
                </span>
              )}
            </div>

            <select
              value={selectedLocation}
              onChange={(e) => {
                setSelectedLocation(e.target.value);
                setIsPaused(true);
              }}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-black font-semibold focus:ring-2 focus:ring-red-500 focus:outline-none"
            >
              {CAMPUS_PRESET_LOCATIONS.map((loc) => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </div>

          {/* Optional Short Description */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-700 dark:text-slate-300 text-xs">
              Optional Short Description:
            </label>
            <input
              type="text"
              placeholder="e.g., Injured leg, need campus medic urgently"
              value={customDescription}
              onChange={(e) => {
                setCustomDescription(e.target.value);
                setIsPaused(true);
              }}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-black font-semibold placeholder-slate-500 focus:ring-2 focus:ring-red-500 focus:outline-none"
            />
          </div>

          {/* Privacy & Recipient Controls */}
          <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-3 border border-slate-200 dark:border-slate-700 space-y-2.5">
            <div className="font-bold text-slate-800 dark:text-slate-200 text-xs">
              Safety & Privacy Controls
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <EyeOff className="w-3.5 h-3.5 text-slate-400" />
                <span>Send as Anonymous Student</span>
              </span>
              <input
                type="checkbox"
                checked={isAnonymous}
                onChange={(e) => setIsAnonymous(e.target.checked)}
                className="w-4 h-4 text-red-600 rounded focus:ring-red-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-slate-400" />
                <span>Notify {activeContactsCount} Saved Emergency Contact(s)</span>
              </span>
              <input
                type="checkbox"
                checked={notifyContacts}
                onChange={(e) => setNotifyContacts(e.target.checked)}
                className="w-4 h-4 text-red-600 rounded focus:ring-red-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between border-t border-slate-200/80 dark:border-slate-700 pt-2">
              <span className="text-slate-700 dark:text-slate-200 font-semibold flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-amber-500" />
                <span>Demo / Prototype Simulation Mode</span>
              </span>
              <input
                type="checkbox"
                checked={isDemo}
                onChange={(e) => setIsDemo(e.target.checked)}
                className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500 cursor-pointer"
              />
            </div>
          </div>

        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-slate-100 dark:bg-slate-800/90 border-t border-slate-200 dark:border-slate-700 flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 px-4 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors cursor-pointer text-center"
          >
            CANCEL
          </button>

          <button
            type="button"
            onClick={handleFinalSend}
            className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs shadow-lg shadow-red-600/30 transition-all cursor-pointer flex items-center justify-center gap-2 hover:scale-[1.02]"
          >
            <AlertTriangle className="w-4 h-4 animate-bounce" />
            <span>SEND SOS NOW</span>
          </button>
        </div>

      </div>
    </div>
  );
};
